#!/usr/bin/env python3
"""
Forensic Master-Analyzer
========================

An autonomous forensic investigator. Not a checklist: every flagged event is
followed through to a concrete conclusion ("brute force SUCCEEDED from 10.0.0.5
at 13:04:12" — not "check for a successful 4624").

Modules:
    - Memory Forensics (Volatility3)    VAD anomalies, rootkits, hidden
                                         procs, lsass access, dormant
                                         sockets, PE carving.
    - Crash Dump Analyzer               MEMORY.DMP, Minidumps, WER,
                                         user-mode CrashDumps.
    - Event Log Investigator            Brute-force follow-through,
                                         service classification, 4688
                                         parent-child anomaly, log-clear
                                         correlation.
    - Registry Artifacts                Amcache, Shimcache, UserAssist.
    - Autoruns                          HKLM Run keys, Winlogon.
    - Scheduled Tasks                   C:\\Windows\\System32\\Tasks XML.
    - Prefetch                          Execution history.
    - Process-Tree Anomaly (live)       Parent-child rule engine.
    - MFT Triage                        Filesystem execution evidence.
    - Correlation Engine                Cross-source IoAs.
    - Finding Normalizer                Dedup, whitelist, decay.
    - HTML Report                       Top Critical + Investigator
                                         Conclusions.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import importlib
import io
import json
import logging
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import textwrap
import time
import xml.etree.ElementTree as ET
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import (Any, Callable, Dict, Iterable, List, Optional,
                    Set, Tuple, Union)

TOOL_NAME = "Forensic Master-Analyzer"
TOOL_VERSION = "5.0.0"

# --- Deferred-work manifest (what v3.0 does NOT yet ship) ------------
# SRUM DB parsing: requires an ESE/JET reader; bundled as stub only.
# PyInstaller single-exe: external build step, not part of this file.
# Unit tests: require a sample artifact corpus.
# Fleet mode / SIEM push: requires a central server.
# evtx_dump replacement for python-evtx: requires external binary.
# Kernel-callback rootkit detection (modern SSDT-replacement): needs
#   memory image + custom Volatility symbols.


def _now_utc() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(d: dt.datetime) -> str:
    return d.isoformat(timespec="seconds").replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# Dependency bootstrap.
# ---------------------------------------------------------------------------

REQUIRED_PACKAGES: Dict[str, str] = {
    "psutil":     "psutil",
    "pefile":     "pefile",
    "Evtx":       "python-evtx",
    "Registry":   "python-registry",
    "volatility3": "volatility3",
}

# Optional: installed if present, skipped silently otherwise.
OPTIONAL_PACKAGES: Dict[str, str] = {
    "dissect.esedb": "dissect.esedb",   # SRUM body parse
    "yara":          "yara-python",     # stronger YARA
}


def _pip_install(pip_name: str) -> bool:
    cmd = [sys.executable, "-m", "pip", "install",
           "--disable-pip-version-check", "--no-input", "--quiet", pip_name]
    try:
        subprocess.check_call(cmd)
        return True
    except subprocess.CalledProcessError:
        return False


def bootstrap_dependencies() -> Dict[str, bool]:
    status: Dict[str, bool] = {}
    for import_name, pip_name in REQUIRED_PACKAGES.items():
        try:
            importlib.import_module(import_name)
            status[import_name] = True
            continue
        except ImportError:
            pass
        print(f"[bootstrap] Installing missing dependency: {pip_name}")
        ok = _pip_install(pip_name)
        if ok:
            try:
                importlib.invalidate_caches()
                importlib.import_module(import_name)
                status[import_name] = True
                continue
            except ImportError:
                pass
        status[import_name] = False
    # Best-effort install of optional packages (no-op if they fail)
    for import_name, pip_name in OPTIONAL_PACKAGES.items():
        try:
            importlib.import_module(import_name)
            status[import_name] = True
        except ImportError:
            try:
                if _pip_install(pip_name):
                    importlib.invalidate_caches()
                    importlib.import_module(import_name)
                    status[import_name] = True
            except Exception:
                status[import_name] = False
    return status


# ---------------------------------------------------------------------------
# Logger.
# ---------------------------------------------------------------------------

def make_logger(name: str, verbose: bool) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
            "%H:%M:%S"))
        logger.addHandler(handler)
    return logger


# ---------------------------------------------------------------------------
# Finding data model.
# ---------------------------------------------------------------------------

SEV_INFO, SEV_LOW, SEV_MED, SEV_HIGH, SEV_CRIT = 1, 2, 3, 4, 5
SEV_LABEL = {1: "Informational", 2: "Low", 3: "Medium",
             4: "High", 5: "Critical"}
SEV_COLOR = {1: "#6c7a89", 2: "#16a085", 3: "#f39c12",
             4: "#e67e22", 5: "#c0392b"}


@dataclass
class Finding:
    source: str
    category: str
    title: str
    severity: int
    conclusion: str             # investigator conclusion (definite, not advisory)
    description: str            # the underlying technical reasoning
    evidence: Dict[str, Any] = field(default_factory=dict)
    correlated: List[Dict[str, Any]] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    timestamp: Optional[str] = None
    confidence: str = "high"    # low / medium / high

    def dedup_key(self) -> Tuple[str, ...]:
        ev = self.evidence or {}
        keys = ("image_path", "process", "service_name", "src_ip",
                "target_user", "name")
        for k in keys:
            if ev.get(k):
                return (self.source, self.category, str(ev[k]).lower())
        return (self.source, self.category, self.title)

    def anchor_id(self) -> str:
        """Stable HTML anchor derived from a fingerprint of the
        finding. Used by the Findings Index / Attack Indicators to
        link to the full card."""
        payload = f"{self.source}|{self.category}|{self.title}|" \
                  f"{self.timestamp or ''}"
        return "f-" + hashlib.md5(
            payload.encode("utf-8")).hexdigest()[:10]

    def compute_confidence(self) -> Tuple[int, List[str]]:
        """Return (0..100, reasons[]). Confidence increases with
        corroborating evidence (hashes, YARA, Authenticode, cross-
        source correlation) and decreases for self-referential /
        heuristic-only findings."""
        reasons: List[str] = []
        score = 45   # baseline
        ev = self.evidence or {}

        if ev.get("sha256"):
            score += 10
            reasons.append("SHA256 computed for the artifact")
        auth = ev.get("authenticode") or {}
        if isinstance(auth, dict):
            status = (auth.get("status") or "").lower()
            if status == "hashmismatch":
                score += 15
                reasons.append(
                    "Authenticode HashMismatch — binary tampered")
            elif status in ("notsigned", "unknownerror"):
                score += 5
                reasons.append(
                    "Authenticode NotSigned — no vendor attribution")
            elif status == "valid" and self.category.startswith(
                    "persistence"):
                score -= 10
                reasons.append(
                    "Valid Authenticode — vendor-signed artifact")
        if ev.get("yara"):
            score += 15
            rule_names = [m.get("rule") for m in ev["yara"]
                          if isinstance(m, dict)]
            reasons.append(
                f"YARA match: {', '.join(rule_names)[:80]}")
        if self.correlated:
            score += min(10, len(self.correlated))
            reasons.append(
                f"{len(self.correlated)} correlated event(s)")
        if self.source == "correlation":
            score += 10
            reasons.append("Cross-source correlation engine finding")
        if self.source == "sigma":
            score += 5
            reasons.append("Sigma-rule match")
        if self.source == "ioc":
            score += 20
            reasons.append("Operator-supplied IoC match")
        if "likely-benign" in self.tags:
            score -= 25
            reasons.append("Likely-benign annotation applied")
        if "keyboard-typos" in self.tags:
            score -= 20
            reasons.append("Benign keyboard-typo pattern")
        if ev.get("occurrences", 1) and isinstance(
                ev.get("occurrences"), int) and ev["occurrences"] > 1:
            score += min(10, ev["occurrences"])
            reasons.append(f"{ev['occurrences']}x occurrences")

        return max(0, min(100, score)), reasons

    def deep_analysis(self) -> Dict[str, Any]:
        """Aggregates the per-finding deep-dive structure that the
        report renders as a collapsible panel: kill-chain, impact,
        MITRE detail, confidence, hunting queries, remediation."""
        confidence, conf_reasons = self.compute_confidence()
        pb = kill_chain_for_finding(self)
        mitre = []
        for t in self.tags or []:
            if not isinstance(t, str):
                continue
            if re.match(r"^T\d{4}", t):
                meta = MITRE_TECHNIQUES.get(
                    t, {"name": "?", "tactic": "?"})
                mitre.append({
                    "id": t, "name": meta["name"],
                    "tactic": meta["tactic"],
                    "url": mitre_url(t),
                })
        queries = hunting_for_category(self.category)
        return {
            "confidence": confidence,
            "confidence_reasons": conf_reasons,
            "kill_chain_phase": pb.get("phase"),
            "impact": pb.get("impact"),
            "immediate_actions": pb.get("immediate") or [],
            "hardening": pb.get("hardening") or [],
            "mitre": mitre,
            "queries": queries,
        }

    def malicious_quote(self) -> Optional[Dict[str, str]]:
        """Return the 'smoking gun' for this finding — the exact
        string, path, command, or value that constitutes the
        malicious behavior. Rendered prominently at the top of
        each finding card so the analyst sees what is malicious
        at a glance.
        Returns {label, value, context} or None."""
        ev = self.evidence or {}
        cat = self.category or ""

        def _val(keys, default="?"):
            for k in keys:
                v = ev.get(k)
                if v not in (None, "", "-", []):
                    return v
            return default

        # PowerShell script block obfuscation
        if cat == "execution.ps_obfuscated":
            excerpt = ev.get("script_block_excerpt")
            if excerpt:
                patterns = (ev.get("strong_hits")
                            or ev.get("weak_hits") or [])
                return {
                    "label": "PowerShell script block content",
                    "value": str(excerpt)[:600],
                    "context": (f"Patterns matched: "
                                 f"{', '.join(str(p) for p in patterns[:4])}"),
                }
        # Service installation
        if cat.startswith("persistence.service"):
            return {
                "label": "Service image path",
                "value": str(_val(("image_path", "ImagePath",
                                    "ServiceFileName")))[:500],
                "context": (f"Service: "
                             f"{_val(('service_name', 'ServiceName'))}  "
                             f"Verdict: {_val(('verdict',), '')}"),
            }
        # Scheduled task
        if cat.startswith("persistence.schtask"):
            cmds = ev.get("commands") or ev.get("TaskContent") or ""
            if isinstance(cmds, list):
                cmds = " ".join(str(c) for c in cmds)
            return {
                "label": "Scheduled task action",
                "value": str(cmds)[:500] or str(
                    _val(("path", "TaskName"))),
                "context": (f"Task: {_val(('path','TaskName'))}  "
                             f"Author: {_val(('author',''))}"),
            }
        # Autorun / IFEO / Winlogon
        if (cat.startswith("persistence.run")
                or cat.startswith("persistence.ifeo")
                or cat.startswith("persistence.winlogon")
                or cat.startswith("persistence.appinit")):
            return {
                "label": "Autorun value",
                "value": str(_val(("value",)))[:500],
                "context": (f"Key: {_val(('hive',))}  "
                             f"Name: {_val(('name',))}"),
            }
        # COM hijack
        if cat == "persistence.com_hijack":
            return {
                "label": "COM InprocServer32 override",
                "value": str(_val(("path",)))[:500],
                "context": f"CLSID: {_val(('clsid',))}  "
                           f"Server: {_val(('server',))}",
            }
        # WMI persistence
        if cat == "persistence.wmi_subscription":
            return {
                "label": "WMI event consumer action",
                "value": str(_val(("CommandLineTemplate",
                                    "ExecutablePath",
                                    "ScriptText")))[:500],
                "context": f"Name: {_val(('Name',))}  "
                           f"Class: {_val(('__CLASS',))}",
            }
        # Process creation 4688 anomaly
        if cat.startswith("exec."):
            ev_inner = ev.get("event") or ev
            return {
                "label": "4688 command line",
                "value": str(ev_inner.get("cmdline")
                             or ev.get("CommandLine")
                             or ev.get("cmdline"))[:500],
                "context": (f"Parent: "
                             f"{ev.get('parent') or ev_inner.get('ParentProcessName','?')}  "
                             f"Child: "
                             f"{ev.get('child') or ev_inner.get('NewProcessName','?')}"),
            }
        # Live process-tree
        if self.source == "live":
            cmd = ev.get("cmdline") or []
            if isinstance(cmd, list):
                cmd = " ".join(str(c) for c in cmd)
            return {
                "label": "Running command",
                "value": str(cmd or ev.get("exe", "?"))[:500],
                "context": (f"Name: {ev.get('name','?')}  "
                             f"PID: {ev.get('pid','?')}  "
                             f"Parent: {ev.get('parent_name','?')}"),
            }
        # Brute force
        if cat == "auth.bruteforce":
            srcs = ev.get("src_ips") or ["(not recorded)"]
            if isinstance(srcs, list):
                srcs = ", ".join(str(s) for s in srcs)
            return {
                "label": "Brute-force cluster",
                "value": (f"Target: '{ev.get('target_user','?')}' "
                           f"   Source(s): {srcs}"),
                "context": (f"{ev.get('burst_count','?')} failed "
                             f"attempts in "
                             f"{ev.get('span_seconds','?')}s "
                             f"(logon types: "
                             f"{', '.join(ev.get('logon_types') or [])})"
                             f"  Success after burst: "
                             f"{ev.get('success_after_burst')}"),
            }
        # Password spray
        if cat == "auth.password_spray":
            users = ev.get("unique_users") or []
            return {
                "label": "Password spray source",
                "value": f"From: {ev.get('src_ip','?')}",
                "context": (f"{ev.get('total_attempts','?')} attempts "
                             f"across {len(users)} users: "
                             f"{', '.join(users[:10])}"),
            }
        # Kerberos attacks
        if cat == "kerberos.kerberoast":
            return {
                "label": "Kerberoasting pattern",
                "value": (f"Requester: '{ev.get('requester','?')}' "
                           f"— {ev.get('spn_count','?')} RC4 SPN "
                           f"requests"),
                "context": "Target SPNs: "
                           + ", ".join(str(s) for s in
                                        (ev.get('spn_sample') or [])[:6]),
            }
        if cat == "kerberos.asrep_roast":
            return {
                "label": "AS-REP roastable account",
                "value": str(_val(("TargetUserName",))),
                "context": (f"PreAuthType=0 from IP "
                             f"{_val(('IpAddress',))}"),
            }
        # Credential access
        if cat.startswith("credential.lsass"):
            handle = ev.get("handle") or {}
            return {
                "label": "LSASS handle acquired",
                "value": (f"Source: "
                           f"{handle.get('SourceImage') or handle.get('ProcessName') or ev.get('SourceImage','?')}"
                           f"  Granted: "
                           f"{handle.get('GrantedAccess','?') or ev.get('GrantedAccess','?')}"),
                "context": "VM_READ on lsass.exe — credential dumping "
                           "primitive",
            }
        if cat == "credential.runas":
            return {
                "label": "Explicit-credential logon (4648)",
                "value": (f"{_val(('ProcessName',))} -> "
                           f"{_val(('TargetUserName',))}@"
                           f"{_val(('TargetDomainName',))}"),
                "context": f"Subject: "
                           f"{_val(('SubjectUserName',))}  "
                           f"IP: {_val(('IpAddress',))}",
            }
        if cat == "credential.dpapi":
            return {
                "label": "DPAPI master-key operation",
                "value": _val(("SubjectUserName", "subject")),
                "context": f"Target: {_val(('TargetUserName',))}  "
                           f"MasterKeyId: "
                           f"{_val(('MasterKeyId',))}",
            }
        if cat == "credential.saved_admin":
            return {
                "label": "Saved admin credential",
                "value": f"User: {ev.get('user','?')}  "
                         f"Target: {ev.get('target','?')}",
                "context": f"Type: {ev.get('type','?')}  "
                           f"Persistence: "
                           f"{ev.get('persistence','?')}",
            }
        if cat == "credential.gpp_cpassword":
            paths = ev.get("paths") or []
            return {
                "label": "SYSVOL Groups.xml cpassword exposure",
                "value": "\n".join(str(p) for p in paths[:5]),
                "context": ("cpassword is decryptable with Microsoft-"
                             "published key (MS14-025)"),
            }
        if cat == "credential.extraction_tool":
            live = ev.get("live") or []
            disk = ev.get("prefetch") or []
            return {
                "label": "Credential-dumping tool",
                "value": ", ".join(
                    (p.get('name','?') if isinstance(p, dict)
                     else str(p))
                    for p in live[:5]) or "(on disk via prefetch)",
                "context": (f"Prefetch evidence: "
                             f"{', '.join(str(d) for d in disk[:3])}"),
            }
        # Malware carving
        if cat == "malware.carved_pe":
            return {
                "label": "Carved PE artifact",
                "value": str(_val(("path",))),
                "context": (f"sha256: "
                             f"{(ev.get('sha256') or '')[:32]}...  "
                             f"size: {ev.get('size','?')} bytes"),
            }
        # Memory VAD injection
        if cat.startswith("vad."):
            return {
                "label": "Injected memory region",
                "value": (f"{ev.get('process','?')} "
                           f"(PID {ev.get('pid','?')})"),
                "context": f"Protection: {ev.get('protection','?')}",
            }
        # Rootkit / hidden proc
        if cat.startswith("rootkit"):
            return {
                "label": "Rootkit indicator",
                "value": str(_val(("module", "path", "name")))[:300],
                "context": f"Record: "
                           f"{str(ev.get('record') or '')[:180]}",
            }
        # Lateral movement
        if cat.startswith("lateral"):
            return {
                "label": "Lateral-movement pattern",
                "value": (f"{ev.get('target_user','?')}@"
                           f"{ev.get('src_ip','?')} -> "
                           f"service '{ev.get('service_name','?')}'"),
                "context": (f"Delta: "
                             f"{ev.get('delta_seconds','?')}s between "
                             "Type-3 logon and service install"),
            }
        # C2 / network
        if cat.startswith("network.c2") or cat.startswith("c2."):
            return {
                "label": "C2-candidate endpoint",
                "value": (f"{ev.get('laddr','?')} -> "
                           f"{ev.get('raddr', ev.get('ForeignAddr','?'))}"),
                "context": (f"Process: "
                             f"{ev.get('process') or ev.get('Owner','?')}  "
                             f"Status: {ev.get('status','?')}"),
            }
        if cat.startswith("network."):
            return {
                "label": "Network listener / connection",
                "value": (f"Local: {ev.get('laddr','?')}   "
                           f"Remote: {ev.get('raddr','(listen)')}"),
                "context": (f"Process: {ev.get('process','?')}  "
                             f"Proto: {ev.get('proto','?')}"),
            }
        # Defender tampering
        if cat.startswith("defender.exclusion"):
            return {
                "label": "Defender exclusion",
                "value": str(ev.get("exclusion", "?")),
                "context": "This path/process is excluded from AV "
                           "scanning",
            }
        if cat.startswith("defender."):
            tamper = []
            for k in ("DisableRealtimeMonitoring",
                      "DisableScriptScanning", "AntivirusEnabled",
                      "RealTimeProtectionEnabled",
                      "IsTamperProtected", "DisableAntiSpyware"):
                if k in ev:
                    tamper.append(f"{k} = {ev[k]}")
            return {
                "label": "Defender state",
                "value": ", ".join(tamper) or str(ev)[:200],
                "context": "Weakened defensive posture",
            }
        # ETW tampering
        if cat.startswith("etw."):
            return {
                "label": "ETW / logging state",
                "value": f"{list(ev.items())[0] if ev else 'disabled'}",
                "context": "Logging reduced / disabled",
            }
        # Log clearing
        if cat == "log.cleared" or cat == "log.service_shutdown":
            return {
                "label": "Log tampering event",
                "value": (f"Actor: "
                           f"{ev.get('suspected_actor') or ev.get('SubjectUserName','?')}"),
                "context": (f"Time: "
                             f"{ev.get('TimeCreated') or ev.get('time','?')}"),
            }
        if cat == "log.audit_policy_change":
            return {
                "label": "Audit policy change",
                "value": str(_val(("AuditPolicyChanges",)))[:300],
                "context": f"By: {_val(('SubjectUserName',))}",
            }
        # Account operations
        if cat.startswith("account."):
            return {
                "label": EVENT_CATALOG.get(
                    ev.get("EventID"),
                    {}).get("name", "Account operation"),
                "value": (f"{_val(('SubjectUserName',))} acted on "
                           f"{_val(('TargetUserName',))}"),
                "context": f"Event: {ev.get('EventID','?')}",
            }
        # Correlations
        if self.source == "correlation":
            return {
                "label": "Correlated attack chain",
                "value": str(ev)[:400],
                "context": "Cross-source correlation",
            }
        # Darknet
        if cat.startswith("darknet."):
            urls = (ev.get("sample_urls") or ev.get("urls")
                    or ev.get("records") or [])
            val = ", ".join(str(u) for u in urls[:4]) \
                if urls else str(ev)[:300]
            return {
                "label": "Darknet / exfil indicator",
                "value": val,
                "context": ("Tor / paste-site / anonymous upload / "
                             "stealer-drop"),
            }
        # Browser download
        if cat.startswith("delivery.browser"):
            return {
                "label": "Browser-delivered artifact",
                "value": str(_val(("target_path", "url",
                                    "source_url")))[:400],
                "context": f"Browser: {_val(('brand',))}  "
                           f"Time: {_val(('start',))}",
            }
        # MFT / file drop
        if cat.startswith("filesystem"):
            return {
                "label": "Dropper file",
                "value": str(_val(("name", "path")))[:300],
                "context": f"Created: {_val(('si_created',))}",
            }
        # Sigma rule matches
        if self.source == "sigma":
            rule_ev = ev.get("event") or {}
            return {
                "label": "Sigma rule match",
                "value": f"Rule: {ev.get('rule_id','?')}  "
                         f"Level: {ev.get('rule_level','?')}",
                "context": (f"Event: "
                             f"{rule_ev.get('EventID','?')}  "
                             f"Target: "
                             f"{rule_ev.get('TargetUserName') or rule_ev.get('NewProcessName','?')}"),
            }
        # IoC feed match
        if self.source == "ioc":
            return {
                "label": f"IoC match ({ev.get('ioc_kind','?')})",
                "value": str(ev.get("ioc_value", "?")),
                "context": (f"Matched finding: "
                             f"{ev.get('matched_finding_title','?')}"),
            }
        # Dump crash
        if cat.startswith("dump."):
            exc = ev.get("exception") or {}
            return {
                "label": "Crash dump",
                "value": (f"Process: {ev.get('process_name','?')}  "
                           f"Code: "
                           f"{exc.get('code_name', ev.get('exception_code','?'))}"),
                "context": f"Faulting module: "
                           f"{ev.get('faulting_module','?')}  "
                           f"At: {ev.get('timestamp','?')}",
            }
        # USB
        if cat.startswith("usb."):
            return None   # Summary item, no specific malicious quote
        # Discovery
        if cat.startswith("discovery."):
            return {
                "label": "Discovery / recon burst",
                "value": (f"Subject: "
                           f"{ev.get('subject', _val(('SubjectUserName',)))}  "
                           f"Queries: "
                           f"{ev.get('burst_queries', ev.get('count','?'))}"),
                "context": (f"Distinct targets: "
                             f"{ev.get('distinct_targets','?')}  "
                             f"Span: "
                             f"{ev.get('span_seconds','?')}s"),
            }
        # Driver / BYOVD
        if cat.startswith("driver."):
            return {
                "label": "Driver artifact",
                "value": str(_val(("PathName", "Path")))[:260],
                "context": (f"Name: {_val(('Name',))}  "
                             f"Signer: {_val(('Signer',))}  "
                             f"Status: {_val(('Status',))}"),
            }
        # NTDS
        if cat.startswith("credential.asrep_roastable") \
                or cat.startswith("credential.passwd_notreqd") \
                or cat.startswith("ntds."):
            users = ev.get("users") or []
            return {
                "label": "NTDS.dit account list",
                "value": ", ".join(str(u) for u in users[:10]),
                "context": f"Total: {ev.get('total', len(users))} "
                           "matching accounts",
            }
        return None

    def forensic_references(self) -> Dict[str, Any]:
        """Curated subset of evidence that points at *where* the
        artifact lives on disk / in the registry / in the logs.
        Renders as the 'Forensic References' panel in the report."""
        ev = self.evidence or {}
        out: Dict[str, Any] = {}

        # Location(s) on disk
        paths: List[str] = []
        for k in ("path", "image_path", "ImagePath",
                  "ImageLoaded", "TargetImage", "SourceImage",
                  "NewProcessName", "ParentProcessName",
                  "exe", "source", "target", "faulting_module",
                  "ExecutablePath", "CommandLineTemplate"):
            v = ev.get(k)
            if isinstance(v, str) and v:
                paths.append(v[:260])
        if paths:
            out["File path(s)"] = paths[:4]

        # Registry keys referenced
        reg_keys: List[str] = []
        for k in ("hive", "key", "RegistryKey"):
            v = ev.get(k)
            if isinstance(v, str) and ("hklm" in v.lower()
                                        or "hkcu" in v.lower()
                                        or "\\" in v):
                reg_keys.append(v[:260])
        if reg_keys:
            out["Registry key(s)"] = reg_keys[:4]

        # Hashes
        if ev.get("sha256"):
            out["SHA256"] = ev["sha256"]
        if ev.get("md5"):
            out["MD5"] = ev["md5"]

        # Authenticode
        auth = ev.get("authenticode") or {}
        if isinstance(auth, dict) and (auth.get("status")
                                        or auth.get("signer")):
            out["Authenticode"] = (
                f"{auth.get('status','?')}  "
                f"/  signer: {auth.get('signer') or 'n/a'}")

        # Network endpoints
        ips: List[str] = []
        for k in ("IpAddress", "ForeignAddr", "src_ip", "DestinationIp",
                  "SourceIp"):
            v = ev.get(k)
            if isinstance(v, str) and v and v not in ("-", "::", "0.0.0.0"):
                ips.append(v)
        if ips:
            out["IP(s)"] = ips[:6]
        for k in ("QueryName", "url", "source_url", "host",
                  "raddr"):
            v = ev.get(k)
            if isinstance(v, str) and v:
                out.setdefault("URL / Domain", []).append(str(v)[:260])

        # Event log coordinates
        if ev.get("EventID"):
            out["Event log"] = (
                f"EID={ev.get('EventID')} "
                f"channel={ev.get('Channel') or ev.get('__source_log') or '?'}")

        # User identities
        for k in ("TargetUserName", "SubjectUserName", "username",
                  "target_user", "subject", "requester"):
            v = ev.get(k)
            if isinstance(v, str) and v and v != "-":
                out.setdefault("User(s)", []).append(v)

        # Process identities
        for k in ("PID", "pid", "ProcessId", "process"):
            v = ev.get(k)
            if v not in (None, "", "-") and "Process" not in out:
                out["Process"] = str(v)[:120]

        # Timestamps
        ts_fields: Dict[str, Any] = {}
        for k in ("TimeCreated", "timestamp", "first_seen",
                  "last_seen", "first", "last", "si_created",
                  "si_modified", "mtime", "UtcTime"):
            v = ev.get(k)
            if v:
                ts_fields[k] = str(v)[:40]
        if self.timestamp and not ts_fields:
            ts_fields["timestamp"] = str(self.timestamp)[:40]
        if ts_fields:
            out["Timestamp(s)"] = ts_fields

        # YARA hits
        yara = ev.get("yara")
        if yara:
            out["YARA matches"] = [m.get("rule") for m in yara
                                    if isinstance(m, dict)]

        return out

    def summary_evidence(self) -> Dict[str, Any]:
        """A compact, human-readable subset of evidence used for the
        HTML report. Full raw evidence stays available via the JSON
        export and the 'Raw data' toggle."""
        ev = dict(self.evidence or {})
        # Always strip the biggest noise sources.
        ev.pop("modules", None)         # minidump module list
        ev.pop("record", None)          # raw pool record
        ev.pop("Hexdump", None)
        ev.pop("handle", None)
        ev.pop("hexdump", None)
        # Per-category summarization
        if self.category == "dump.crash":
            keep = ("name", "type", "process_name", "faulting_module",
                    "timestamp", "size", "pid", "os", "thread_count")
            exc = ev.get("exception") or {}
            out = {k: ev[k] for k in keep if k in ev}
            if exc:
                out["exception_code"] = exc.get("code_name")
                out["exception_hex"] = exc.get("code_hex")
                out["exception_address"] = exc.get("address_hex")
            return out
        if self.category == "auth.bruteforce":
            keep = ("target_user", "burst_count", "total_failures_for_user",
                    "span_seconds", "first", "last", "src_ips",
                    "workstations", "logon_types",
                    "success_after_burst")
            return {k: ev[k] for k in keep if k in ev}
        if self.category == "persistence.service":
            keep = ("service_name", "image_path", "verdict",
                    "install_count", "first_install", "last_install")
            return {k: ev[k] for k in keep if k in ev}
        if self.source == "evtlog":
            # Strip the raw XML-derived bag; pull just a few identifiers
            keep_like = ("TimeCreated", "Computer", "Channel",
                         "TargetUserName", "SubjectUserName",
                         "IpAddress", "WorkstationName",
                         "LogonType", "ImagePath", "NewProcessName",
                         "ParentProcessName", "CommandLine",
                         "ServiceName", "TaskName")
            out = {k: v for k, v in ev.items() if k in keep_like and v}
            for k in ("event", "logon", "service"):
                sub = ev.get(k)
                if isinstance(sub, dict):
                    for kk, vv in sub.items():
                        if kk in keep_like and vv and kk not in out:
                            out[kk] = vv
            # Preserve scalars surfaced elsewhere (delta_seconds etc.)
            for k in ("delta_seconds", "src_ip", "target_user",
                      "service_name", "suspected_actor"):
                if k in ev:
                    out[k] = ev[k]
            return out
        if self.source == "memory":
            keep = ("process", "pid", "name", "protection",
                    "ForeignAddr", "ForeignPort", "LocalAddr",
                    "LocalPort", "Owner", "PID", "size", "sha256",
                    "path", "module", "symbol")
            return {k: ev[k] for k in keep if k in ev}
        # Default: cap list/string sizes for anything else.
        out: Dict[str, Any] = {}
        for k, v in ev.items():
            if isinstance(v, list):
                out[k] = (v[:3] +
                          [f"(+{len(v) - 3} more)"] if len(v) > 3 else v)
            elif isinstance(v, str) and len(v) > 400:
                out[k] = v[:400] + f"... (+{len(v) - 400} chars)"
            else:
                out[k] = v
        return out

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["severity_label"] = SEV_LABEL[self.severity]
        return d


# ---------------------------------------------------------------------------
# Whitelists & heuristics.
# ---------------------------------------------------------------------------

# Vendors whose signed services are treated as baseline-noise unless
# they load a binary from a suspicious directory.
KNOWN_VENDOR_PATTERNS = (
    "microsoft", "windows", "nvidia", "intel", "realtek", "amd ",
    "dell", "hp ", "hp inc", "lenovo", "apple", "adobe", "google",
    "copilot", "cowork", "claude", "anthropic",
    "hitmanpro", "sophos", "symantec", "mcafee", "kaspersky",
    "eset", "trend micro", "crowdstrike", "sentinelone", "carbon black",
    "cisco", "vmware", "oracle", "logitech", "synaptics", "dropbox",
    "spotify", "zoom", "slack", "teams", "onedrive", "wacom",
    "nordvpn", "expressvpn", "razer", "corsair", "asus", "acer",
    "docker", "jetbrains", "mozilla", "opera", "brave",
    "updater", "autoupdate",  # vendor updater services
)

STANDARD_SERVICE_ROOTS = (
    "c:\\windows\\system32",
    "c:\\windows\\syswow64",
    "c:\\windows\\microsoft.net",
    "c:\\program files\\",
    "c:\\program files (x86)\\",
    "c:\\programdata\\",
    "\\??\\c:\\windows\\system32",
    "\\systemroot\\system32",
    "\\systemroot\\system32\\drivers",
)

SUSPICIOUS_PATH_FRAGMENTS = (
    r"\temp\\",
    r"\appdata\local\temp\\",
    r"\appdata\roaming\\",
    r"\users\public\\",
    r"\programdata\\",
    r"\downloads\\",
    r"\recycle",
    r"\perflogs\\",
)

LOLBINS = {
    "rundll32.exe", "regsvr32.exe", "mshta.exe", "wmic.exe",
    "certutil.exe", "bitsadmin.exe", "installutil.exe", "msbuild.exe",
    "powershell.exe", "pwsh.exe", "cscript.exe", "wscript.exe",
    "cmd.exe", "curl.exe", "schtasks.exe", "at.exe", "sc.exe",
    "net.exe", "netsh.exe", "reg.exe", "psexec.exe",
}

OFFICE_APPS = {
    "winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe",
    "msaccess.exe", "mspub.exe", "visio.exe",
}

BROWSER_APPS = {
    "chrome.exe", "firefox.exe", "msedge.exe", "iexplore.exe",
    "opera.exe", "brave.exe",
}

ENCODED_CMD_PATTERNS = (
    "-enc ", "-encodedcommand", "-encoded", "-nop -w hidden",
    "iex(new-object net.webclient", "invoke-expression",
    "downloadstring(", "frombase64string(",
    "bypass -w 1", "-windowstyle hidden", "-executionpolicy bypass",
)

CREDENTIAL_TARGETS = {"lsass.exe"}


def _extract_image_path(raw: str) -> str:
    """Pull just the executable path out of an ImagePath/CommandLine
    that may be quoted and include arguments."""
    s = (raw or "").strip().lower()
    if s.startswith('"'):
        m = re.match(r'^"([^"]+)"', s)
        if m:
            return m.group(1)
    # Unquoted: take everything up to the first ' -' or ' /' flag or
    # whitespace before an argument. Windows exe paths don't contain
    # spaces outside Program Files, so take up to the first .exe/.dll.
    m = re.match(r'^(.+?\.(?:exe|dll|sys))\b', s)
    if m:
        return m.group(1)
    return s.split(" ", 1)[0]


def _path_is_suspicious(path: str) -> bool:
    p = _extract_image_path(path)
    return any(frag in p for frag in SUSPICIOUS_PATH_FRAGMENTS)


def _path_is_standard(path: str) -> bool:
    p = _extract_image_path(path)
    return any(p.startswith(r) for r in STANDARD_SERVICE_ROOTS)


def _is_known_vendor(text: str) -> bool:
    t = (text or "").lower()
    return any(pat in t for pat in KNOWN_VENDOR_PATTERNS)


def _has_encoded_cmd(text: str) -> bool:
    t = (text or "").lower()
    return any(pat in t for pat in ENCODED_CMD_PATTERNS)


def _extract_event_fields(eid: int,
                           ev: Dict[str, Any]) -> Dict[str, Any]:
    """Return a compact dict of forensically-relevant fields for this
    specific Event ID. Used by the report's Event Overview section to
    show actual values (username, IP, command line, ...) — not just a
    generic description of what the EID means.
    """
    out: Dict[str, Any] = {}
    tc = ev.get("TimeCreated") or ev.get("UtcTime")
    if tc:
        out["TimeCreated"] = str(tc)

    def _add(keys):
        for k in keys:
            v = ev.get(k)
            if v not in (None, "-", ""):
                out[k] = str(v)[:300]

    # Sysmon channel (we key as negative EID)
    if eid < 0:
        _add(("Image", "SourceImage", "TargetImage", "ParentImage",
              "CommandLine", "ParentCommandLine", "User", "QueryName",
              "QueryResults", "ImageLoaded", "Signed", "Signature",
              "GrantedAccess", "PipeName", "TargetFilename",
              "TargetObject", "Hashes", "Type"))
        return out

    # Security channel
    if eid == 4624:
        _add(("TargetUserName", "TargetDomainName", "LogonType",
              "IpAddress", "IpPort", "WorkstationName",
              "ProcessName", "AuthenticationPackageName",
              "LogonProcessName"))
    elif eid == 4625:
        _add(("TargetUserName", "TargetDomainName", "LogonType",
              "IpAddress", "IpPort", "WorkstationName",
              "FailureReason", "Status", "SubStatus",
              "ProcessName"))
    elif eid == 4634 or eid == 4647:
        _add(("TargetUserName", "TargetDomainName", "LogonType"))
    elif eid == 4648:
        _add(("SubjectUserName", "SubjectDomainName",
              "TargetUserName", "TargetDomainName", "TargetServerName",
              "ProcessName", "IpAddress"))
    elif eid == 4672:
        _add(("SubjectUserName", "SubjectDomainName",
              "PrivilegeList"))
    elif eid == 4688:
        _add(("NewProcessName", "ParentProcessName", "CommandLine",
              "SubjectUserName", "SubjectDomainName",
              "TokenElevationType", "MandatoryLabel"))
    elif eid == 4689:
        _add(("ProcessName", "SubjectUserName", "Status"))
    elif eid == 4697 or eid == 7045:
        _add(("ServiceName", "ImagePath", "ServiceFileName",
              "ServiceType", "ServiceAccount", "AccountName",
              "SubjectUserName", "StartType"))
    elif eid == 4698:
        _add(("TaskName", "SubjectUserName", "SubjectDomainName",
              "TaskContent"))
    elif eid == 4699 or eid == 4700 or eid == 4702:
        _add(("TaskName", "SubjectUserName", "TaskContent"))
    elif eid == 1102 or eid == 104:
        _add(("SubjectUserName", "SubjectDomainName",
              "UserSid", "UserName"))
    elif eid == 1100 or eid == 1101:
        _add(("Channel",))
    elif eid == 4719:
        _add(("SubjectUserName", "CategoryId", "SubcategoryId",
              "SubcategoryGuid", "AuditPolicyChanges"))
    elif eid == 4657:
        _add(("ObjectName", "ObjectValueName", "OldValue",
              "NewValue", "SubjectUserName"))
    elif eid in (4692, 4693):
        _add(("SubjectUserName", "SubjectDomainName", "MasterKeyId",
              "RecoveryKeyId", "RecoveryServer"))
    elif eid == 4740:
        _add(("TargetUserName", "TargetDomainName", "SubjectUserName",
              "TargetSid"))
    elif eid == 4767:
        _add(("TargetUserName", "SubjectUserName"))
    elif eid in (4720, 4722, 4723, 4724, 4725, 4726, 4738, 4781):
        _add(("TargetUserName", "TargetDomainName", "SubjectUserName",
              "UserAccountControl", "PasswordLastSet",
              "DisplayName", "HomeDirectory"))
    elif eid in (4727, 4728, 4732, 4733, 4756):
        _add(("TargetUserName", "TargetDomainName", "MemberName",
              "MemberSid", "SubjectUserName"))
    elif eid == 4768:
        _add(("TargetUserName", "TargetDomainName", "IpAddress",
              "IpPort", "PreAuthType", "TicketEncryptionType",
              "TicketOptions", "Status"))
    elif eid == 4769:
        _add(("TargetUserName", "TargetDomainName", "ServiceName",
              "ServiceSid", "IpAddress", "IpPort",
              "TicketEncryptionType", "TicketOptions", "Status"))
    elif eid == 4770:
        _add(("TargetUserName", "ServiceName",
              "TicketEncryptionType"))
    elif eid == 4771:
        _add(("TargetUserName", "IpAddress", "IpPort",
              "Status", "FailureCode"))
    elif eid == 4776:
        _add(("TargetUserName", "Workstation", "Status"))
    elif eid == 4798:
        _add(("SubjectUserName", "TargetUserName", "CallerProcessName"))
    elif eid == 4799:
        _add(("SubjectUserName", "TargetUserName", "TargetDomainName",
              "CallerProcessName"))
    elif eid == 5140 or eid == 5145:
        _add(("SubjectUserName", "IpAddress", "ShareName",
              "ShareLocalPath", "RelativeTargetName", "AccessMask"))
    elif eid == 4104:
        # PowerShell script block — keep short excerpt
        blob = ev.get("ScriptBlockText")
        if blob:
            out["ScriptBlockText"] = str(blob)[:500]
        _add(("ScriptBlockId", "Path", "MessageNumber",
              "MessageTotal"))
    elif eid == 4103:
        _add(("ContextInfo", "Payload", "UserId"))

    # Fallback fields if nothing above matched (or to supplement)
    if not out or len(out) <= 1:
        _add(("TargetUserName", "SubjectUserName", "IpAddress",
              "ProcessName", "NewProcessName", "ImagePath",
              "ObjectName", "ShareName", "CommandLine"))
    return out


# Admin-looking targets trigger suspicion in logon / group events.
_ADMIN_TARGET_HINTS = ("administrator", "administrators", "domain admins",
                       "enterprise admins", "schema admins",
                       "backup operators", "remote desktop users",
                       "account operators")


def _is_external_ip(ip: Optional[str]) -> bool:
    if not ip or ip in ("-", "127.0.0.1", "::1", "0.0.0.0"):
        return False
    priv_prefixes = (["10."] + [f"172.{i}." for i in range(16, 32)]
                     + ["192.168.", "169.254.", "fe80:"])
    if any(ip.startswith(p) for p in priv_prefixes):
        return False
    return True


def _event_is_suspicious(eid: int,
                          ev: Dict[str, Any]) -> Optional[str]:
    """Return a short reason string if the instance is suspicious,
    else None. Used by the report to highlight specific rows inside
    the Event Overview."""
    t = _parse_ts(ev.get("TimeCreated"))

    if eid == 4624:
        user = (ev.get("TargetUserName") or "").lower()
        lt = str(ev.get("LogonType") or "")
        ip = (ev.get("IpAddress") or "").strip()
        # SYSTEM / Service / Computer-$ accounts log on 24×7 by design.
        is_system = (
            user in ("system", "local service", "network service",
                     "anonymous logon", "-", "dwm", "umfd", "")
            or user.endswith("$")
            or user.startswith(("umfd-", "dwm-"))
            or lt in ("0", "5"))     # Type 0 (system), Type 5 (service)
        if is_system:
            return None
        if lt == "10" and _is_external_ip(ip):
            return f"RemoteInteractive (Type 10) from external IP {ip}"
        if lt == "3" and _is_external_ip(ip):
            return f"Network logon (Type 3) from external IP {ip}"
        if any(h == user for h in ("administrator", "admin", "root")):
            return f"Built-in admin account '{user}' logging on"
        # Off-hours only for interactive types
        if lt in ("2", "7", "11") and t and \
                (t.hour >= 22 or t.hour < 6):
            return f"Off-hours interactive logon ({t.hour:02d}:00) " \
                   f"by '{user}'"
    elif eid == 4625:
        user = (ev.get("TargetUserName") or "").lower()
        ip = (ev.get("IpAddress") or "").strip()
        # Only mark a failed logon as suspicious if the source is
        # external or the target is a built-in privileged account;
        # otherwise it's typical "user typed password wrong" noise
        # that the aggregate brute-force detector already handles.
        if _is_external_ip(ip):
            return f"Failed logon from external IP {ip}"
        if user in ("administrator", "admin", "root"):
            return f"Failed logon against built-in '{user}'"
        return None
    elif eid == 4648:
        caller = Path((ev.get("ProcessName") or "").lower()).name
        target = (ev.get("TargetUserName") or "").lower()
        benign = {"consent.exe", "runas.exe", "mmc.exe",
                  "taskmgr.exe", "userinit.exe", "credwiz.exe",
                  "explorer.exe", "wininit.exe", "winlogon.exe",
                  "lsass.exe", "services.exe", "svchost.exe",
                  "vmcompute.exe", "dllhost.exe", "runtimebroker.exe"}
        if any(target.startswith(p) for p in
               ("umfd-", "dwm-", "anonymous logon")):
            return None
        if caller and caller not in benign:
            return f"Explicit creds from non-standard caller '{caller}'"
        if any(h in target for h in _ADMIN_TARGET_HINTS):
            return f"Explicit creds targeting admin account '{target}'"
    elif eid == 4672:
        # 4672 fires for every admin logon. On admin workstations it
        # is high-volume routine noise; the aggregate detector already
        # flags privileged logons at the Low-severity level, which is
        # plenty. Don't mark individual 4672 as suspicious here.
        return None
    elif eid == 4688:
        new = Path((ev.get("NewProcessName") or "").lower()).name
        parent = Path((ev.get("ParentProcessName") or "").lower()).name
        cmd = (ev.get("CommandLine") or "").lower()
        if parent in OFFICE_APPS and new in LOLBINS:
            return f"Office '{parent}' spawned LOLBin '{new}'"
        if _has_encoded_cmd(cmd):
            return "Encoded / hidden PowerShell-style invocation"
        if parent == "lsass.exe":
            return "lsass.exe as parent (injection)"
    elif eid == 4697 or eid == 7045:
        path = (ev.get("ImagePath")
                or ev.get("ServiceFileName") or "").lower()
        if _has_encoded_cmd(path):
            return "Service launches encoded command"
        if _path_is_suspicious(path):
            return f"Service image in transient path"
    elif eid == 4698:
        content = (ev.get("TaskContent") or "").lower()
        if _has_encoded_cmd(content):
            return "Task action contains encoded command"
        if _path_is_suspicious(content):
            return "Task action in transient path"
    elif eid == 1102 or eid == 104:
        actor = (ev.get("SubjectUserName")
                 or ev.get("UserName") or "unknown")
        hour = f"{t.hour:02d}:{t.minute:02d}" if t else "?"
        return (f"Audit log cleared at {hour} by '{actor}' — "
                "privileged action with anti-forensic intent "
                "unless pre-authorized")
    elif eid == 1100:
        hour = t.hour if t else None
        if hour is not None and (hour >= 22 or hour < 6):
            return (f"Log service stopped at {hour:02d}:"
                    f"{t.minute:02d} (off-hours)")
        if hour is not None:
            return (f"Log service stopped at {hour:02d}:"
                    f"{t.minute:02d} — verify reboot pairing")
        return "Log service stopped"
    elif eid == 4719:
        actor = (ev.get("SubjectUserName") or "?")
        changes = str(ev.get("AuditPolicyChanges") or "")[:60]
        return (f"Audit policy modified by '{actor}'"
                + (f" (changes: {changes})" if changes else ""))
    elif eid in (4720, 4722, 4724, 4726, 4738):
        tgt = ev.get("TargetUserName") or "?"
        who = ev.get("SubjectUserName") or "?"
        name = EVENT_CATALOG.get(eid, {}).get('name', 'account op')
        return f"{name}: '{who}' acted on '{tgt}'"
    elif eid in (4728, 4732, 4756):
        grp = (ev.get("TargetUserName") or "").lower()
        member = ev.get("MemberName") or "?"
        if any(h in grp for h in _ADMIN_TARGET_HINTS):
            return (f"Member '{member}' added to privileged group "
                    f"'{grp}'")
    elif eid == 4740:
        tgt = ev.get("TargetUserName") or "?"
        caller = ev.get("SubjectUserName") or "?"
        return (f"Account '{tgt}' locked out (reported by '{caller}')"
                " — investigate source of failed logons")
    elif eid == 4768:
        if str(ev.get("PreAuthType") or "") == "0":
            u = ev.get("TargetUserName", "?")
            if not (u or "").endswith("$"):
                return f"AS-REQ without pre-auth for '{u}'"
    elif eid == 4769:
        etype = str(ev.get("TicketEncryptionType") or "").lower()
        spn = (ev.get("ServiceName") or "")
        if etype in ("0x17", "0x18", "rc4", "rc4-hmac") and \
                spn and not spn.endswith("$") and \
                spn.lower() != "krbtgt":
            return f"RC4 TGS for user-SPN '{spn}' (Kerberoast)"
    elif eid == 4771:
        status = str(ev.get("Status") or "").upper()
        if "0XC000006A" in status:
            return "Kerberos pre-auth failed (bad password)"
    elif eid == 4776:
        status = str(ev.get("Status") or "").upper()
        if status and status != "0X0":
            return f"NTLM validation status={status}"
    elif eid == 4692 or eid == 4693:
        u = (ev.get("SubjectUserName") or "").upper()
        if u and u not in ("SYSTEM", "LOCAL SERVICE",
                            "NETWORK SERVICE") and not u.endswith("$"):
            return f"DPAPI master key op by non-system '{u}'"
    elif eid == 4798 or eid == 4799:
        # We don't flag every single one; the burst detector does
        # aggregate flagging. Individual rows stay benign.
        return None
    elif eid == 5145:
        share = (ev.get("ShareName") or "").lower()
        obj = (ev.get("RelativeTargetName") or "").lower()
        if share in ("\\\\*\\admin$", "\\\\*\\ipc$") and any(
                p in obj for p in ("\\svcctl", "\\srvsvc",
                                    "\\winreg", "\\atsvc")):
            return f"Named-pipe lateral on {share} -> {obj}"
    elif eid == 4104:
        blob = (ev.get("ScriptBlockText") or "").lower()
        # Re-use the strong markers from the PS detector
        for p in EventLogAnalyzer._PS_MALICIOUS_ALONE \
                if hasattr(EventLogAnalyzer,
                            "_PS_MALICIOUS_ALONE") else ():
            if p in blob:
                return f"Script block contains '{p}'"
    return None


def correlate_event_instances(
        event_overview: Dict[int, Dict[str, Any]],
        findings: List["Finding"],
        window_minutes: int = 15) -> None:
    """
    For every suspicious event-instance captured in event_overview,
    cross-reference against the accumulated findings and attach
    anchor links to any finding that shares:
      * timestamp within `window_minutes`,
      * same user (Target/Subject),
      * same IP,
      * same process / binary basename,
      * same file path.
    Mutates the samples in-place by adding a `_correlations` list.
    """
    if not event_overview or not findings:
        return

    # Indexes over findings
    by_ts: List[Tuple[dt.datetime, str, str, int, str]] = []
    by_user: Dict[str, List[Tuple[str, str, int]]] = {}
    by_ip: Dict[str, List[Tuple[str, str, int]]] = {}
    by_proc: Dict[str, List[Tuple[str, str, int]]] = {}
    by_path: Dict[str, List[Tuple[str, str, int]]] = {}

    def _lower_stripped(v: Any) -> Optional[str]:
        if not isinstance(v, str) or not v or v == "-":
            return None
        return v.lower().strip()

    for f in findings:
        anchor = f.anchor_id()
        meta = (anchor, f.title, f.severity)
        # Timestamp
        ts = _parse_ts(f.timestamp) if f.timestamp else None
        if ts:
            by_ts.append((ts, anchor, f.title, f.severity, f.category))
        ev = f.evidence or {}
        # Users
        for k in ("TargetUserName", "SubjectUserName", "target_user",
                   "subject", "username", "user"):
            v = _lower_stripped(ev.get(k))
            if v and not v.endswith("$"):
                by_user.setdefault(v, []).append(meta)
        # IPs
        for k in ("IpAddress", "ForeignAddr", "src_ip", "DestinationIp"):
            v = _lower_stripped(ev.get(k))
            if v:
                by_ip.setdefault(v, []).append(meta)
        for v in (ev.get("src_ips") or []):
            if isinstance(v, str) and v:
                by_ip.setdefault(v.lower(), []).append(meta)
        # Process names (basename)
        for k in ("ProcessName", "NewProcessName", "ParentProcessName",
                   "process", "SourceImage", "TargetImage", "Image",
                   "exe", "image_path", "ImagePath"):
            v = _lower_stripped(ev.get(k))
            if v:
                base = os.path.basename(v)
                if base:
                    by_proc.setdefault(base, []).append(meta)
        # Paths
        for k in ("path", "image_path", "ImagePath",
                   "NewProcessName", "TargetImage", "SourceImage",
                   "exe", "ExecutablePath", "faulting_module"):
            v = _lower_stripped(ev.get(k))
            if v:
                by_path.setdefault(v, []).append(meta)

    window = dt.timedelta(minutes=window_minutes)

    for eid, stats in event_overview.items():
        for sample in (stats.get("suspicious_samples") or []):
            hits: List[Dict[str, Any]] = []
            seen: Set[str] = set()

            def _add(kind: str, meta: Tuple[str, str, int]) -> None:
                anchor, title, sev = meta
                if anchor in seen:
                    return
                seen.add(anchor)
                hits.append({
                    "anchor": anchor, "title": title,
                    "severity": sev, "kind": kind,
                })

            # Time-window match
            sts = _parse_ts(sample.get("TimeCreated"))
            if sts:
                for (ft, anchor, title, sev, cat) in by_ts:
                    if abs((ft - sts).total_seconds()) \
                            <= window.total_seconds():
                        _add(f"time±{window_minutes}m",
                             (anchor, title, sev))
            # User match
            for user_field in ("TargetUserName", "SubjectUserName"):
                u = _lower_stripped(sample.get(user_field))
                if u and u in by_user:
                    for m in by_user[u]:
                        _add(f"user='{u}'", m)
            # IP match
            ip = _lower_stripped(sample.get("IpAddress"))
            if ip and ip in by_ip:
                for m in by_ip[ip]:
                    _add(f"ip={ip}", m)
            # Process match
            for proc_field in ("ProcessName", "NewProcessName",
                                 "ParentProcessName", "Image",
                                 "SourceImage"):
                v = _lower_stripped(sample.get(proc_field))
                if v:
                    base = os.path.basename(v)
                    if base in by_proc:
                        for m in by_proc[base]:
                            _add(f"process={base}", m)
            # Path match
            for path_field in ("ImagePath", "NewProcessName",
                                 "image_path", "TargetImage",
                                 "SourceImage"):
                v = _lower_stripped(sample.get(path_field))
                if v and v in by_path:
                    for m in by_path[v]:
                        _add(f"path", m)

            # Cap the list to keep the report tidy
            sample["_correlations"] = hits[:6]


def _parse_ts(s: Optional[str]) -> Optional[dt.datetime]:
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(s)
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S.%f%z",
                "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%S.%f%z",
                "%Y-%m-%dT%H:%M:%S%z",
                "%Y-%m-%d %H:%M:%S"):
        try:
            d = dt.datetime.strptime(s, fmt)
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return d
        except ValueError:
            continue
    return None


def load_local_config() -> Dict[str, Any]:
    """Read fma-config.json from the script's directory. Used as a
    fallback when CLI flags / env vars are not set. Client installs
    ship with fma-config.sample.json — the client renames it and
    fills in their own VT/AbuseIPDB keys."""
    try:
        script_dir = Path(__file__).resolve().parent
    except NameError:
        return {}
    cfg_path = script_dir / "fma-config.json"
    try:
        if cfg_path.exists():
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except (OSError, PermissionError, json.JSONDecodeError):
        pass
    return {}


def _safe_exists(p: Optional[Path]) -> bool:
    """Path.exists() in Python 3.12+ raises PermissionError on access-
    denied paths (e.g. C:\\Windows\\appcompat\\Programs\\Amcache.hve).
    Wrap so we always get a clean boolean."""
    if p is None:
        return False
    try:
        return p.exists()
    except (OSError, PermissionError):
        return False


def _filetime_to_iso(raw: int) -> Optional[str]:
    if raw == 0:
        return None
    try:
        return (dt.datetime(1601, 1, 1, tzinfo=dt.timezone.utc) +
                dt.timedelta(microseconds=raw / 10)).isoformat()
    except (OverflowError, OSError):
        return None


# ---------------------------------------------------------------------------
# MITRE technique reference table (techniqueId -> name, tactic, URL).
# Expanded subset covering everything the analyzer emits.
# ---------------------------------------------------------------------------

MITRE_TECHNIQUES: Dict[str, Dict[str, str]] = {
    "T1003":     {"name": "OS Credential Dumping",
                   "tactic": "credential-access"},
    "T1003.001": {"name": "LSASS Memory",
                   "tactic": "credential-access"},
    "T1003.002": {"name": "Security Account Manager",
                   "tactic": "credential-access"},
    "T1003.004": {"name": "LSA Secrets",
                   "tactic": "credential-access"},
    "T1003.005": {"name": "Cached Domain Credentials",
                   "tactic": "credential-access"},
    "T1005":     {"name": "Data from Local System",
                   "tactic": "collection"},
    "T1014":     {"name": "Rootkit",
                   "tactic": "defense-evasion"},
    "T1018":     {"name": "Remote System Discovery",
                   "tactic": "discovery"},
    "T1021":     {"name": "Remote Services",
                   "tactic": "lateral-movement"},
    "T1021.001": {"name": "Remote Desktop Protocol",
                   "tactic": "lateral-movement"},
    "T1021.002": {"name": "SMB/Windows Admin Shares",
                   "tactic": "lateral-movement"},
    "T1027":     {"name": "Obfuscated Files or Information",
                   "tactic": "defense-evasion"},
    "T1027.006": {"name": "HTML Smuggling",
                   "tactic": "defense-evasion"},
    "T1036":     {"name": "Masquerading",
                   "tactic": "defense-evasion"},
    "T1053":     {"name": "Scheduled Task/Job",
                   "tactic": "persistence"},
    "T1053.005": {"name": "Scheduled Task",
                   "tactic": "persistence"},
    "T1055":     {"name": "Process Injection",
                   "tactic": "defense-evasion"},
    "T1055.012": {"name": "Process Hollowing",
                   "tactic": "defense-evasion"},
    "T1059":     {"name": "Command and Scripting Interpreter",
                   "tactic": "execution"},
    "T1059.001": {"name": "PowerShell",
                   "tactic": "execution"},
    "T1069":     {"name": "Permission Groups Discovery",
                   "tactic": "discovery"},
    "T1069.001": {"name": "Local Groups",
                   "tactic": "discovery"},
    "T1069.002": {"name": "Domain Groups",
                   "tactic": "discovery"},
    "T1070":     {"name": "Indicator Removal",
                   "tactic": "defense-evasion"},
    "T1070.001": {"name": "Clear Windows Event Logs",
                   "tactic": "defense-evasion"},
    "T1070.004": {"name": "File Deletion",
                   "tactic": "defense-evasion"},
    "T1071":     {"name": "Application Layer Protocol",
                   "tactic": "command-and-control"},
    "T1071.004": {"name": "DNS",
                   "tactic": "command-and-control"},
    "T1074":     {"name": "Data Staged",
                   "tactic": "collection"},
    "T1078":     {"name": "Valid Accounts",
                   "tactic": "initial-access"},
    "T1087":     {"name": "Account Discovery",
                   "tactic": "discovery"},
    "T1087.002": {"name": "Domain Account",
                   "tactic": "discovery"},
    "T1090":     {"name": "Proxy",
                   "tactic": "command-and-control"},
    "T1090.003": {"name": "Multi-hop Proxy (Tor)",
                   "tactic": "command-and-control"},
    "T1098":     {"name": "Account Manipulation",
                   "tactic": "persistence"},
    "T1105":     {"name": "Ingress Tool Transfer",
                   "tactic": "command-and-control"},
    "T1110":     {"name": "Brute Force",
                   "tactic": "credential-access"},
    "T1110.003": {"name": "Password Spraying",
                   "tactic": "credential-access"},
    "T1112":     {"name": "Modify Registry",
                   "tactic": "defense-evasion"},
    "T1134":     {"name": "Access Token Manipulation",
                   "tactic": "privilege-escalation"},
    "T1134.002": {"name": "Create Process with Token",
                   "tactic": "privilege-escalation"},
    "T1136":     {"name": "Create Account",
                   "tactic": "persistence"},
    "T1136.001": {"name": "Local Account",
                   "tactic": "persistence"},
    "T1189":     {"name": "Drive-by Compromise",
                   "tactic": "initial-access"},
    "T1197":     {"name": "BITS Jobs",
                   "tactic": "persistence"},
    "T1204":     {"name": "User Execution",
                   "tactic": "execution"},
    "T1204.002": {"name": "Malicious File",
                   "tactic": "execution"},
    "T1219":     {"name": "Remote Access Software",
                   "tactic": "command-and-control"},
    "T1490":     {"name": "Inhibit System Recovery",
                   "tactic": "impact"},
    "T1531":     {"name": "Account Access Removal",
                   "tactic": "impact"},
    "T1543":     {"name": "Create or Modify System Process",
                   "tactic": "persistence"},
    "T1543.003": {"name": "Windows Service",
                   "tactic": "persistence"},
    "T1546":     {"name": "Event Triggered Execution",
                   "tactic": "persistence"},
    "T1546.003": {"name": "WMI Event Subscription",
                   "tactic": "persistence"},
    "T1546.010": {"name": "AppInit DLLs",
                   "tactic": "persistence"},
    "T1546.012": {"name": "Image File Execution Options "
                           "Injection",
                   "tactic": "persistence"},
    "T1546.015": {"name": "Component Object Model Hijacking",
                   "tactic": "persistence"},
    "T1547":     {"name": "Boot or Logon Autostart Execution",
                   "tactic": "persistence"},
    "T1547.001": {"name": "Registry Run Keys / Startup Folder",
                   "tactic": "persistence"},
    "T1547.004": {"name": "Winlogon Helper DLL",
                   "tactic": "persistence"},
    "T1550":     {"name": "Use Alternate Authentication Material",
                   "tactic": "credential-access"},
    "T1550.002": {"name": "Pass the Hash",
                   "tactic": "credential-access"},
    "T1552":     {"name": "Unsecured Credentials",
                   "tactic": "credential-access"},
    "T1552.006": {"name": "Group Policy Preferences",
                   "tactic": "credential-access"},
    "T1555":     {"name": "Credentials from Password Stores",
                   "tactic": "credential-access"},
    "T1555.003": {"name": "Credentials from Web Browsers",
                   "tactic": "credential-access"},
    "T1555.004": {"name": "Windows Credential Manager / DPAPI",
                   "tactic": "credential-access"},
    "T1558":     {"name": "Steal or Forge Kerberos Tickets",
                   "tactic": "credential-access"},
    "T1558.003": {"name": "Kerberoasting",
                   "tactic": "credential-access"},
    "T1558.004": {"name": "AS-REP Roasting",
                   "tactic": "credential-access"},
    "T1562":     {"name": "Impair Defenses",
                   "tactic": "defense-evasion"},
    "T1562.001": {"name": "Disable or Modify Tools",
                   "tactic": "defense-evasion"},
    "T1562.002": {"name": "Disable Windows Event Logging",
                   "tactic": "defense-evasion"},
    "T1562.006": {"name": "Indicator Blocking",
                   "tactic": "defense-evasion"},
    "T1567":     {"name": "Exfiltration Over Web Service",
                   "tactic": "exfiltration"},
    "T1567.002": {"name": "Exfiltration to Cloud Storage",
                   "tactic": "exfiltration"},
    "T1568":     {"name": "Dynamic Resolution",
                   "tactic": "command-and-control"},
    "T1568.002": {"name": "Domain Generation Algorithms",
                   "tactic": "command-and-control"},
    "T1574":     {"name": "Hijack Execution Flow",
                   "tactic": "persistence"},
    "T1574.002": {"name": "DLL Side-Loading",
                   "tactic": "persistence"},
    "T1596":     {"name": "Search Open Technical Databases",
                   "tactic": "reconnaissance"},
}


def mitre_url(tid: str) -> str:
    base = tid.split(".")[0]
    if "." in tid:
        return f"https://attack.mitre.org/techniques/{base}/{tid.split('.', 1)[1]}/"
    return f"https://attack.mitre.org/techniques/{base}/"


# ---------------------------------------------------------------------------
# Hunting queries templates (Splunk / KQL Azure Sentinel / Elastic EQL).
# One template per finding-category.
# ---------------------------------------------------------------------------

HUNTING_QUERIES: Dict[str, Dict[str, str]] = {
    "credential.lsass_access": {
        "splunk": 'index=sysmon EventCode=10 TargetImage="*\\\\lsass.exe" '
                  'GrantedAccess IN ("0x1010","0x1410","0x1438","0x143a") '
                  '| stats count by SourceImage host',
        "kql": ('DeviceProcessEvents | where ProcessCommandLine has "lsass"\n'
                'or FileName =~ "lsass.exe"\n'
                '| where Timestamp > ago(30d)\n'
                '| project Timestamp, DeviceName, InitiatingProcessFileName,'
                ' ProcessCommandLine'),
        "eql": 'process where process.name : "lsass.exe" and '
                'process.parent.name != "wininit.exe"',
    },
    "persistence.service": {
        "splunk": 'index=windows (EventCode=7045 OR EventCode=4697) '
                  '| stats count by host ServiceName ImagePath '
                  '| sort -count',
        "kql": ('DeviceRegistryEvents | where RegistryKey has '
                '@"\\Services\\" and RegistryValueName == "ImagePath"\n'
                '| where Timestamp > ago(30d)'),
        "eql": 'registry where registry.path : "*\\\\Services\\\\*" and '
                'registry.value : "ImagePath"',
    },
    "auth.bruteforce": {
        "splunk": 'index=windows EventCode=4625 '
                  '| stats count dc(TargetUserName) as users by IpAddress '
                  '| where count > 20',
        "kql": ('SecurityEvent | where EventID == 4625\n'
                '| summarize count() by Account, IpAddress, bin(TimeGenerated, 1h)\n'
                '| where count_ > 10'),
        "eql": 'authentication where event.action : "logon-failed" and '
                'source.ip != null',
    },
    "kerberos.kerberoast": {
        "splunk": 'index=windows EventCode=4769 '
                  'TicketEncryptionType IN ("0x17","0x18") '
                  'ServiceName!="krbtgt" '
                  '| stats dc(ServiceName) as spns by TargetUserName '
                  '| where spns > 3',
        "kql": ('SecurityEvent | where EventID == 4769\n'
                '| where TicketEncryptionType in ("0x17","0x18")\n'
                '| where ServiceName != "krbtgt" and ServiceName !endswith "$"\n'
                '| summarize spns = dcount(ServiceName) by TargetUserName\n'
                '| where spns >= 3'),
    },
    "log.cleared": {
        "splunk": 'index=windows (EventCode=1102 OR EventCode=104)',
        "kql": 'SecurityEvent | where EventID == 1102',
    },
    "defender.av_disabled": {
        "splunk": 'index=windows EventCode=5001 '
                  'OR (EventCode=4657 '
                  'ObjectName="*Microsoft\\\\Windows Defender*")',
        "kql": ('DeviceRegistryEvents | where RegistryKey has '
                '"Windows Defender"\n'
                '| where RegistryValueName in ("DisableAntiSpyware",'
                '"DisableRealtimeMonitoring")\n'
                '| where RegistryValueData == 1'),
    },
    "persistence.wmi_subscription": {
        "splunk": 'index=sysmon (EventCode=19 OR EventCode=20 '
                  'OR EventCode=21) '
                  '| stats count by host Operation Consumer Filter',
        "kql": ('DeviceEvents | where ActionType in ('
                '"WmiBindEventFilterToConsumer",'
                '"WmiEventSubscription")'),
    },
    "darknet.tor_presence": {
        "splunk": 'index=dns query IN ("*torproject.org*",'
                  '"*tor2web*") OR (index=sysmon EventCode=1 '
                  '(Image="*tor.exe*" OR Image="*torbrowser*"))',
        "kql": ('DeviceNetworkEvents | where RemoteUrl has_any '
                '("torproject.org", "tor2web")'),
    },
    "darknet.stealer_drop": {
        "splunk": 'index=sysmon EventCode=11 TargetFilename IN '
                  '("*passwords.txt","*wallets.txt","*cookies.txt",'
                  '"*autofills.txt") '
                  '| stats dc(TargetFilename) as canonical by '
                  'host parent_folder '
                  '| where canonical >= 3',
        "kql": ('DeviceFileEvents | where FileName in (\n'
                '  "passwords.txt","wallets.txt","cookies.txt",'
                '"autofills.txt")\n'
                '| summarize drop_files = dcount(FileName) by '
                'DeviceName, FolderPath\n'
                '| where drop_files >= 3'),
    },
    "lateral.smb_service": {
        "splunk": 'index=windows EventCode=4624 LogonType=3 '
                  '| eventstats latest(_time) as logon_time by IpAddress '
                  '| join IpAddress [search index=windows EventCode=7045 '
                  '| eval svc_time=_time] '
                  '| where svc_time-logon_time < 120',
        "kql": ('let logons = SecurityEvent | where EventID == 4624 '
                'and LogonType == 3;\n'
                'let svc = Event | where EventID == 7045;\n'
                'logons | join kind=inner svc on Computer\n'
                '| where datetime_diff("second", svc.TimeGenerated,\n'
                '  logons.TimeGenerated) between (0 .. 120)'),
    },
}


def hunting_for_category(cat: str) -> Dict[str, str]:
    # Prefix match so sub-categories inherit parent queries.
    if cat in HUNTING_QUERIES:
        return HUNTING_QUERIES[cat]
    for prefix, q in HUNTING_QUERIES.items():
        if cat.startswith(prefix):
            return q
    # Default empty
    return {}


# ---------------------------------------------------------------------------
# Kill-chain / remediation playbook library.
# ---------------------------------------------------------------------------

KILL_CHAIN_PLAYBOOKS: Dict[str, Dict[str, Any]] = {
    # Credential access family
    "credential": {
        "phase": "Credential Access",
        "impact": (
            "Attacker obtained or accessed credential material. "
            "Every account whose token, hash, or ticket was "
            "resident on this host must be considered compromised."),
        "immediate": [
            "Force password reset on every account that logged on "
            "to this host in the last 30 days.",
            "Invalidate Kerberos tickets: rotate krbtgt password "
            "TWICE with a 10-hour gap (Microsoft-documented "
            "procedure).",
            "Revoke all refresh tokens for affected accounts in "
            "Entra/Azure AD (MSOL: Revoke-AzureADUserAllRefreshToken).",
            "Disable cached-logon for privileged accounts on "
            "workstations (GPO: \"Interactive logon: Number of "
            "previous logons to cache\" = 0 for admins).",
        ],
        "hardening": [
            "Enable Credential Guard on Windows 10/11.",
            "Enforce Protected Users group for domain admins.",
            "Remove LM-hash storage (NoLMHash=1).",
            "Set LMCompatibilityLevel to 5.",
        ],
    },
    "persistence": {
        "phase": "Persistence",
        "impact": (
            "Attacker-controlled code will re-execute after reboot, "
            "user logon, or on schedule. Survives normal cleanup; "
            "attacker can return to the host even if you remove "
            "the initial foothold."),
        "immediate": [
            "Remove the flagged autorun / service / task / WMI "
            "subscription after preservation.",
            "Reboot and re-run this analyzer to confirm the "
            "persistence does not return.",
            "Check every other host in the fleet for the same "
            "persistence fingerprint (hash / filename).",
        ],
        "hardening": [
            "Enable ASR rule: Block persistence through WMI event "
            "subscription.",
            "AppLocker / WDAC enforced mode.",
            "Restrict service installation to administrators group.",
        ],
    },
    "lateral": {
        "phase": "Lateral Movement",
        "impact": (
            "The attacker is moving between hosts. Incident scope "
            "is larger than a single endpoint — at minimum two "
            "hosts are compromised."),
        "immediate": [
            "Isolate all hosts in the chain (network off, not "
            "power off — preserve RAM).",
            "Identify the source host (the one that initiated "
            "the Type-3 logon) and triage IT as well.",
            "Reset credentials of the account used for lateral "
            "movement; block logon.",
        ],
        "hardening": [
            "Enforce SMB signing.",
            "Disable SMBv1.",
            "Tier model: admin accounts cannot log on to "
            "workstations.",
            "Enable LAPS for local admin passwords.",
        ],
    },
    "defense-evasion": {
        "phase": "Defense Evasion",
        "impact": (
            "Attacker weakened the defenses of this host — "
            "stopped logging, disabled AV, cleared logs, or "
            "changed audit policy. Blinds the SOC while the "
            "attacker performs noisier actions."),
        "immediate": [
            "Restart Event Log service + verify it is running "
            "(sc query EventLog).",
            "Re-enable Defender AV / RTP / behavior monitoring.",
            "Restore audit-policy baseline via GPO refresh.",
            "Treat any activity in the blind window as untrusted.",
        ],
        "hardening": [
            "Enable Tamper Protection for Defender.",
            "Forward event logs off-host in real time (WEC/ "
            "Sysmon → SIEM).",
            "Restrict SeSecurityPrivilege to a named admin group.",
        ],
    },
    "c2": {
        "phase": "Command & Control",
        "impact": (
            "Attacker has an established channel back to their "
            "infrastructure. Active interactive operator may be "
            "driving actions on this host right now."),
        "immediate": [
            "Block all outbound firewall traffic except to IT "
            "management IPs.",
            "Capture 60s of pcap if possible (pktmon) for later "
            "forensic review.",
            "Identify the owning process of the C2 socket; "
            "preserve, then terminate the process tree.",
        ],
        "hardening": [
            "Egress filtering from endpoints.",
            "DNS filtering (Umbrella / Cisco / cloudflare-gateway).",
            "Block outbound direct-IP traffic (force through "
            "proxy).",
        ],
    },
    "exfiltration": {
        "phase": "Exfiltration",
        "impact": (
            "Data likely already left the host. Legal / "
            "regulatory notification may be required."),
        "immediate": [
            "Estimate exfil volume from SRUM + network telemetry.",
            "Review DLP logs for the incident window.",
            "Preserve the host; evidence chain for legal.",
            "Notify legal/compliance if PII/PHI/PCI may have "
            "left.",
        ],
        "hardening": [
            "DLP policy coverage review.",
            "Block uploads to anonymous file-share and paste "
            "sites at proxy.",
            "Tor blocking at egress.",
        ],
    },
    "discovery": {
        "phase": "Discovery",
        "impact": (
            "Attacker is mapping the environment — users, "
            "groups, shares, hosts. Precedes lateral movement."),
        "immediate": [
            "Review access of the account that performed the "
            "enumeration; consider credential rotation.",
            "Audit domain-admin group membership for recent "
            "additions.",
        ],
        "hardening": [
            "Enable MS-DS Machine Account Quota = 0.",
            "Restrict anonymous LDAP enumeration.",
            "Enable LDAP signing + channel binding.",
        ],
    },
    "execution": {
        "phase": "Execution",
        "impact": (
            "Attacker code ran on this host. Depending on "
            "privilege level, downstream actions range from "
            "data theft to full system control."),
        "immediate": [
            "Preserve the process tree (list of parent-child "
            "PIDs) before killing anything.",
            "Kill the malicious process tree.",
            "Delete the dropper after hash capture.",
            "Sweep the fleet for the same hash / filename.",
        ],
        "hardening": [
            "AppLocker / WDAC enforced.",
            "Office macro policy: block all from internet.",
            "ASR: Block Office apps creating child processes.",
            "Constrained Language Mode for PowerShell.",
        ],
    },
    "initial-access": {
        "phase": "Initial Access",
        "impact": (
            "Entry point of the intrusion. Understanding it is "
            "critical to close the gap globally."),
        "immediate": [
            "Identify how the attacker got in (phishing? exploit? "
            "stolen cred?).",
            "Hunt for the same vector across all users / hosts.",
            "User awareness comms if phishing.",
        ],
        "hardening": [
            "MFA enforcement (Conditional Access / Okta / etc.).",
            "Phishing-resistant MFA (FIDO2).",
            "Perimeter patch level audit.",
            "Block LOLBin execution via proxy rules.",
        ],
    },
    "impact": {
        "phase": "Impact",
        "impact": (
            "Attacker has executed or is preparing destructive / "
            "availability-reducing actions."),
        "immediate": [
            "Activate DR / backup restoration plan.",
            "Legal counsel engagement for ransomware notification.",
            "Law enforcement notification per jurisdiction.",
        ],
        "hardening": [
            "Offline / immutable backups with regular restore "
            "testing.",
            "Recovery-console protected with separate credentials.",
        ],
    },
    "darknet": {
        "phase": "Exfiltration / Command & Control",
        "impact": (
            "Data likely being published or trafficked through "
            "anonymity networks. Recovery focus shifts from "
            "\"block exfiltration\" to \"minimize downstream "
            "damage\"."),
        "immediate": [
            "Block Tor / anonymity egress at perimeter.",
            "Notify stakeholders — data is probably already out.",
            "Credential rotation across all touched accounts.",
        ],
        "hardening": [
            "Egress anomaly detection (beaconing, DoH, Tor).",
            "DLP on sensitive repos.",
        ],
    },
}


def kill_chain_for_finding(finding: "Finding") -> Dict[str, Any]:
    """Return the playbook dict for a finding based on category
    prefix / tags."""
    cat = finding.category or ""
    for prefix, pb in KILL_CHAIN_PLAYBOOKS.items():
        if prefix in cat:
            return pb
    # Fallback via tags
    for tag in finding.tags or []:
        for prefix, pb in KILL_CHAIN_PLAYBOOKS.items():
            if prefix in tag.lower():
                return pb
    return {
        "phase": "General Observation",
        "impact": "Observation recorded for the analyst.",
        "immediate": ["Review the evidence inline."],
        "hardening": [],
    }


# ---------------------------------------------------------------------------
# File hashing, Authenticode, YARA. All best-effort; never raise.
# ---------------------------------------------------------------------------

_HASH_CACHE: Dict[str, Dict[str, str]] = {}


def hash_file(path: Union[str, Path],
              algorithms: Iterable[str] = ("sha256",)
              ) -> Dict[str, str]:
    """Returns {'sha256': '..', 'md5': '..'} or empty dict on failure."""
    p = Path(path)
    key = str(p.resolve()) if p.exists() else str(p)
    if key in _HASH_CACHE:
        return _HASH_CACHE[key]
    out: Dict[str, str] = {}
    if not p.exists() or not p.is_file():
        _HASH_CACHE[key] = out
        return out
    try:
        hashers = {a: hashlib.new(a) for a in algorithms}
        with open(p, "rb", buffering=64 * 1024) as fh:
            while True:
                chunk = fh.read(1024 * 1024)
                if not chunk:
                    break
                for h in hashers.values():
                    h.update(chunk)
        for name, h in hashers.items():
            out[name] = h.hexdigest()
    except (OSError, PermissionError):
        pass
    _HASH_CACHE[key] = out
    return out


_AUTHENTICODE_CACHE: Dict[str, Dict[str, Any]] = {}


def verify_authenticode(path: Union[str, Path],
                        logger: Optional[logging.Logger] = None
                        ) -> Dict[str, Any]:
    """
    Returns {'status': 'Valid'|'NotSigned'|'HashMismatch'|...,
             'signer': '...', 'issuer': '...'}.
    Uses PowerShell's Get-AuthenticodeSignature, which wraps the
    native WinVerifyTrust. Empty dict on failure.
    """
    p = Path(path)
    if not p.exists() or not p.is_file():
        return {}
    key = str(p.resolve())
    if key in _AUTHENTICODE_CACHE:
        return _AUTHENTICODE_CACHE[key]
    if os.name != "nt":
        return {}
    ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
    if not ps:
        return {}
    script = (
        f"$s = Get-AuthenticodeSignature -LiteralPath '{key}';"
        "$out = @{"
        "  Status = [string]$s.Status;"
        "  StatusMessage = [string]$s.StatusMessage;"
        "  SignerName = if ($s.SignerCertificate) "
        "                { $s.SignerCertificate.Subject } else { $null };"
        "  Issuer = if ($s.SignerCertificate) "
        "            { $s.SignerCertificate.Issuer } else { $null };"
        "  NotAfter = if ($s.SignerCertificate) "
        "              { $s.SignerCertificate.NotAfter.ToString('o') }"
        "              else { $null };"
        "};"
        "$out | ConvertTo-Json -Compress"
    )
    try:
        result = subprocess.run(
            [ps, "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=20)
        data = json.loads(result.stdout or "{}")
    except (subprocess.TimeoutExpired, OSError,
            json.JSONDecodeError):
        data = {}
    _AUTHENTICODE_CACHE[key] = data
    return data


# Bundled YARA ruleset: small, high-signal, no zero-days. Enough to
# flag obvious badness in carved PE buffers and script strings.
BUNDLED_YARA_RULES = r"""
rule FMA_Mimikatz {
    meta:
        author = "FMA"
        description = "Mimikatz string signatures"
    strings:
        $s1 = "sekurlsa::" ascii wide
        $s2 = "privilege::debug" ascii wide
        $s3 = "lsadump::sam" ascii wide
        $s4 = "kerberos::ptt" ascii wide
        $s5 = "mimikatz" ascii wide nocase
        $s6 = "gentilkiwi" ascii wide
    condition:
        2 of them
}

rule FMA_CobaltStrike_Beacon {
    meta:
        author = "FMA"
        description = "Cobalt Strike Beacon config markers"
    strings:
        $s1 = "beacon.dll" ascii wide
        $s2 = "%s (admin)" ascii wide
        $s3 = "ReflectiveLoader" ascii wide
        $s4 = { 69 68 69 68 69 6b }     // 'ihihik' sleep-mask tail
        $s5 = "start_thread" ascii
        $cs_conf = { 2e 2f 2e 2f 2e 2c 40 40 40 40 }  // CS config XOR
    condition:
        3 of ($s*) or $cs_conf
}

rule FMA_Meterpreter_Stager {
    meta:
        author = "FMA"
    strings:
        $s1 = "metsrv.dll" ascii wide
        $s2 = "stdapi_" ascii wide
        $s3 = "core_channel_" ascii wide
        $s4 = "ReflectiveLoader" ascii wide
        $s5 = { 60 BF AA C5 E2 5D }   // Meterpreter reflective loader tag
    condition:
        2 of them
}

rule FMA_PowerSploit_Keywords {
    meta:
        author = "FMA"
        description = "PowerSploit / offensive-PS command names"
    strings:
        $s1 = "Invoke-Mimikatz" ascii wide
        $s2 = "Invoke-Kerberoast" ascii wide
        $s3 = "Invoke-DCSync" ascii wide
        $s4 = "Get-GPPPassword" ascii wide
        $s5 = "Invoke-PSInject" ascii wide
        $s6 = "PowerSploit" ascii wide
    condition:
        // Require 2 hits to avoid FPs on documentation / help
        // strings / security-product signatures that mention
        // these function names.
        2 of them
}
/* FMA_Generic_UPX removed — UPX! + UPX0 strings appear in many
   legitimate packed installers and Microsoft Store apps,
   producing unreliable signal. If you need packed-PE detection,
   run it as a standalone pass against carved PEs, not against
   live memory. */

rule FMA_AMSI_Bypass {
    meta:
        author = "FMA"
    strings:
        $s1 = "amsiInitFailed" ascii wide
        $s2 = "AmsiUtils" ascii wide
        $s3 = "amsi.dll" ascii wide nocase
        $s4 = "AmsiScanBuffer" ascii wide
    condition:
        2 of them
}
"""


_YARA_RULES_OBJ = None
_YARA_RULES_CACHE_KEY = None


def _compile_yara_rules(extra_paths: Optional[List[Path]] = None):
    global _YARA_RULES_OBJ, _YARA_RULES_CACHE_KEY
    key = tuple(str(p) for p in (extra_paths or []))
    if _YARA_RULES_OBJ is not None and \
            _YARA_RULES_CACHE_KEY == key:
        return _YARA_RULES_OBJ
    _YARA_RULES_CACHE_KEY = key
    try:
        import yara
    except ImportError:
        _YARA_RULES_OBJ = False
        return False
    try:
        sources = {"bundled": BUNDLED_YARA_RULES}
        if extra_paths:
            for p in extra_paths:
                if p.exists():
                    sources[p.stem] = p.read_text(encoding="utf-8",
                                                   errors="ignore")
        _YARA_RULES_OBJ = yara.compile(sources=sources)
        return _YARA_RULES_OBJ
    except Exception:
        _YARA_RULES_OBJ = False
        return False


def yara_scan_buffer(data: bytes,
                     extra_paths: Optional[List[Path]] = None
                     ) -> List[Dict[str, Any]]:
    rules = _compile_yara_rules(extra_paths)
    if not rules:
        return []
    try:
        matches = rules.match(data=data)
    except Exception:
        return []
    return [{"rule": m.rule, "namespace": m.namespace,
             "tags": list(getattr(m, "tags", [])),
             "strings": [getattr(s, "identifier", "?")
                         for s in (getattr(m, "strings", []) or [])][:8]}
            for m in matches]


def yara_scan_file(path: Union[str, Path],
                   extra_paths: Optional[List[Path]] = None
                   ) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists() or not p.is_file():
        return []
    try:
        return yara_scan_buffer(p.read_bytes(), extra_paths)
    except (OSError, PermissionError, MemoryError):
        return []


# ---------------------------------------------------------------------------
# VirusTotal / AbuseIPDB / GeoIP enrichment clients.
# ---------------------------------------------------------------------------

class VirusTotalClient:
    """Minimal VT v3 client — hash reputation only. Respects free-
    tier rate limit (4/min) with a sliding window."""

    URL = "https://www.virustotal.com/api/v3/files/{hash}"

    def __init__(self, api_key: str, logger: logging.Logger):
        self.api_key = api_key
        self.logger = logger
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._window: List[float] = []

    def lookup(self, sha256: str) -> Dict[str, Any]:
        if not self.api_key or not sha256 or len(sha256) != 64:
            return {}
        if sha256 in self._cache:
            return self._cache[sha256]
        import urllib.request
        now = time.time()
        self._window = [t for t in self._window if now - t < 60]
        if len(self._window) >= 4:
            wait = 60 - (now - self._window[0]) + 1
            time.sleep(max(0, wait))
        self._window.append(time.time())
        req = urllib.request.Request(
            self.URL.format(hash=sha256),
            headers={"x-apikey": self.api_key})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            self.logger.debug("VT lookup %s failed: %s", sha256[:12],
                               exc)
            return {}
        attrs = data.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {}) or {}
        # Pull top detection labels for attribution
        detections: List[str] = []
        results = attrs.get("last_analysis_results", {}) or {}
        for engine, r in list(results.items())[:200]:
            if isinstance(r, dict) and r.get("category") \
                    in ("malicious", "suspicious"):
                label = r.get("result")
                if label:
                    detections.append(f"{engine}: {label}")
        # Popular threat classification (VT's consensus)
        popular_class = attrs.get("popular_threat_classification",
                                    {}) or {}
        out = {
            "malicious": stats.get("malicious", 0),
            "suspicious": stats.get("suspicious", 0),
            "harmless": stats.get("harmless", 0),
            "undetected": stats.get("undetected", 0),
            "first_submission_date":
                attrs.get("first_submission_date"),
            "last_analysis_date":
                attrs.get("last_analysis_date"),
            "names": (attrs.get("names") or [])[:5],
            "meaningful_name": attrs.get("meaningful_name"),
            "type_description": attrs.get("type_description"),
            "reputation": attrs.get("reputation"),
            "threat_label":
                popular_class.get("suggested_threat_label"),
            "threat_categories": [
                c.get("value") for c in
                popular_class.get("popular_threat_category",
                                   []) or []
            ][:5],
            "threat_families": [
                f.get("value") for f in
                popular_class.get("popular_threat_name",
                                   []) or []
            ][:5],
            "top_detections": detections[:10],
            "vt_url": f"https://www.virustotal.com/gui/file/"
                       f"{sha256}",
            "vt_api_url": f"https://www.virustotal.com/api/v3/"
                           f"files/{sha256}",
        }
        self._cache[sha256] = out
        return out


class AbuseIPDBClient:
    URL = "https://api.abuseipdb.com/api/v2/check"

    def __init__(self, api_key: str, logger: logging.Logger):
        self.api_key = api_key
        self.logger = logger
        self._cache: Dict[str, Dict[str, Any]] = {}

    def lookup(self, ip: str) -> Dict[str, Any]:
        if not self.api_key or not ip:
            return {}
        if ip in self._cache:
            return self._cache[ip]
        import urllib.request, urllib.parse
        url = f"{self.URL}?{urllib.parse.urlencode({'ipAddress': ip, 'maxAgeInDays': 90})}"
        req = urllib.request.Request(url, headers={
            "Key": self.api_key, "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            self.logger.debug("AbuseIPDB %s failed: %s", ip, exc)
            return {}
        d = (data or {}).get("data", {}) or {}
        out = {
            "abuse_score": d.get("abuseConfidenceScore", 0),
            "country": d.get("countryCode"),
            "isp": d.get("isp"),
            "domain": d.get("domain"),
            "total_reports": d.get("totalReports", 0),
            "last_reported": d.get("lastReportedAt"),
            "usage_type": d.get("usageType"),
        }
        self._cache[ip] = out
        return out


class GeoIPClient:
    """Wraps MaxMind GeoLite2-Country (and optionally City) mmdb.
    Works offline once the DB is on disk; free registration at
    maxmind.com."""

    def __init__(self, db_path: Optional[Path],
                 logger: logging.Logger):
        self.logger = logger
        self._reader = None
        if db_path and _safe_exists(db_path):
            try:
                import geoip2.database
                self._reader = geoip2.database.Reader(str(db_path))
                self.logger.info("GeoIP: loaded %s", db_path.name)
            except ImportError:
                self.logger.info(
                    "GeoIP: geoip2 library not installed")
            except Exception as exc:
                self.logger.debug("GeoIP load: %s", exc)

    def lookup(self, ip: str) -> Dict[str, Any]:
        if self._reader is None or not ip:
            return {}
        try:
            try:
                r = self._reader.city(ip)
                return {
                    "country": r.country.iso_code,
                    "country_name": r.country.name,
                    "city": r.city.name,
                    "lat": r.location.latitude,
                    "lon": r.location.longitude,
                }
            except Exception:
                r = self._reader.country(ip)
                return {"country": r.country.iso_code,
                        "country_name": r.country.name}
        except Exception:
            return {}


class ThreatIntelEnricher:
    """Runs VT / AbuseIPDB / GeoIP against every flagged hash and IP
    in the findings, and stitches the result into evidence."""

    def __init__(self, logger: logging.Logger,
                 vt_key: Optional[str] = None,
                 abuseipdb_key: Optional[str] = None,
                 geoip_db: Optional[Path] = None):
        self.logger = logger
        self.vt = VirusTotalClient(vt_key, logger) if vt_key \
            else None
        self.abuseipdb = AbuseIPDBClient(abuseipdb_key, logger) \
            if abuseipdb_key else None
        self.geoip = GeoIPClient(geoip_db, logger)

    def run(self, findings: List[Finding]) -> None:
        if not (self.vt or self.abuseipdb
                or self.geoip._reader):
            return
        self.logger.info("Threat-intel enrichment starting")
        hashes_seen: Set[str] = set()
        ips_seen: Set[str] = set()
        for f in findings:
            ev = f.evidence or {}
            intel: Dict[str, Any] = ev.get("threat_intel") or {}
            # Hash lookup
            h = ev.get("sha256")
            if self.vt and isinstance(h, str) and h \
                    and h not in hashes_seen:
                hashes_seen.add(h)
                vt = self.vt.lookup(h)
                if vt:
                    intel["virustotal"] = vt
                    if vt.get("malicious", 0) >= 5:
                        f.severity = max(f.severity, SEV_HIGH)
                        f.tags = list(f.tags or []) + ["vt-malicious"]
            # IP lookup + Geo
            for k in ("IpAddress", "ForeignAddr", "src_ip"):
                ip = ev.get(k)
                if not isinstance(ip, str) or not ip \
                        or ip in ("-", "::", "0.0.0.0"):
                    continue
                if ip in ips_seen:
                    continue
                ips_seen.add(ip)
                if self.abuseipdb:
                    a = self.abuseipdb.lookup(ip)
                    if a:
                        intel.setdefault(
                            "abuseipdb", {})[ip] = a
                        if a.get("abuse_score", 0) >= 50:
                            f.severity = max(f.severity,
                                              SEV_HIGH)
                            f.tags = list(f.tags or []) \
                                + ["abuseipdb-abusive"]
                g = self.geoip.lookup(ip)
                if g:
                    intel.setdefault("geoip", {})[ip] = g
            if intel:
                ev["threat_intel"] = intel
                f.evidence = ev
        self.logger.info(
            "Threat-intel enrichment complete (VT hashes=%d, "
            "IPs=%d)", len(hashes_seen), len(ips_seen))


# ---------------------------------------------------------------------------
# Baseline / delta mode.
# ---------------------------------------------------------------------------

class BaselineComparator:
    """Compare current findings against a previous JSON snapshot to
    highlight what is NEW since last run. Uses the finding dedup_key
    as the identity; anything not in the baseline becomes a NEW
    finding annotation."""

    def __init__(self, baseline_path: Optional[Path],
                 logger: logging.Logger):
        self.baseline_keys: Set[Tuple[str, ...]] = set()
        self.logger = logger
        if baseline_path and _safe_exists(baseline_path):
            try:
                data = json.loads(
                    baseline_path.read_text(encoding="utf-8"))
                for f in data.get("findings", []):
                    src = f.get("source", "")
                    cat = f.get("category", "")
                    title = f.get("title", "")
                    # Reconstruct dedup key best-effort
                    ev = f.get("evidence") or {}
                    for k in ("image_path", "process",
                               "service_name", "src_ip",
                               "target_user", "name"):
                        v = ev.get(k)
                        if v:
                            self.baseline_keys.add(
                                (src, cat, str(v).lower()))
                            break
                    else:
                        self.baseline_keys.add((src, cat, title))
                self.logger.info(
                    "Baseline loaded: %d prior findings",
                    len(self.baseline_keys))
            except Exception as exc:
                self.logger.warning("Baseline load failed: %s", exc)

    def annotate(self, findings: List[Finding]) -> Tuple[int, int]:
        if not self.baseline_keys:
            return (0, 0)
        new = 0
        persisting = 0
        for f in findings:
            if f.dedup_key() in self.baseline_keys:
                persisting += 1
                f.tags = list(f.tags or []) + ["known-since-baseline"]
            else:
                new += 1
                f.tags = list(f.tags or []) + ["NEW-since-baseline"]
        self.logger.info(
            "Baseline delta: %d NEW, %d persisting", new, persisting)
        return (new, persisting)


# ---------------------------------------------------------------------------
# Driver authenticode audit.
# ---------------------------------------------------------------------------

class DriverAuditAnalyzer:
    """
    Enumerate loaded kernel drivers and verify their Authenticode
    state. Unsigned / revoked / user-dir drivers are strong BYOVD
    (Bring Your Own Vulnerable Driver) indicators.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.drivers: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.drivers, self.findings
        ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not ps:
            return self.drivers, self.findings
        script = r"""
$ErrorActionPreference = 'SilentlyContinue'
$rows = @()
Get-CimInstance Win32_SystemDriver | ForEach-Object {
    $path = $_.PathName -replace '^\\\??\\', ''
    $sig  = Get-AuthenticodeSignature -LiteralPath $path
    $rows += [pscustomobject]@{
        Name = $_.Name
        DisplayName = $_.DisplayName
        State = $_.State
        PathName = $path
        Signer = if ($sig.SignerCertificate) {
            $sig.SignerCertificate.Subject } else { $null }
        Status = [string]$sig.Status
        StatusMessage = [string]$sig.StatusMessage
    }
}
$rows | ConvertTo-Json -Depth 3 -Compress
"""
        try:
            r = subprocess.run(
                [ps, "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=180)
            data = json.loads((r.stdout or "").strip() or "[]")
        except Exception as exc:
            self.logger.debug("Driver audit PS failed: %s", exc)
            return self.drivers, self.findings
        if isinstance(data, dict):
            data = [data]
        self.drivers = data
        for d in data:
            status = (d.get("Status") or "").lower()
            path = (d.get("PathName") or "").lower()
            if status and status not in ("valid", ""):
                sev = SEV_HIGH if "hashmismatch" in status \
                    else SEV_MED
                self.findings.append(Finding(
                    source="driver",
                    category="driver.unsigned_or_mismatch",
                    title=f"Driver Authenticode = {d.get('Status')}: "
                          f"{d.get('Name','?')}",
                    severity=sev,
                    conclusion=(
                        f"Kernel driver '{d.get('Name')}' at "
                        f"'{d.get('PathName')}' has Authenticode "
                        f"status '{d.get('Status')}' — "
                        f"{d.get('StatusMessage','')}. Unsigned / "
                        "hash-mismatch kernel drivers on Windows 10+ "
                        "are rare and usually BYOVD rootkits "
                        "(exploit a signed vulnerable driver to "
                        "gain kernel code exec)."),
                    description="Driver Authenticode verification.",
                    evidence=d, tags=["T1014", "BYOVD", "driver"]))
            elif path and "\\users\\" in path:
                self.findings.append(Finding(
                    source="driver",
                    category="driver.user_path_loaded",
                    title=f"Driver loaded from user path: "
                          f"{d.get('Name','?')}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Driver '{d.get('Name')}' is loaded from "
                        f"'{d.get('PathName')}' — a user-writable "
                        "path. Legitimate drivers live under "
                        "System32\\drivers. User-path drivers are "
                        "a classic BYOVD or rootkit indicator."),
                    description="Driver loaded from user-writable "
                                "location.",
                    evidence=d, tags=["T1014", "BYOVD"]))
        self.logger.info(
            "Drivers: %d audited, %d findings",
            len(self.drivers), len(self.findings))
        return self.drivers, self.findings


# ---------------------------------------------------------------------------
# NTDS.dit offline analyzer (requires dissect.esedb).
# ---------------------------------------------------------------------------

class NTDSAnalyzer:
    """
    Offline ntds.dit analysis — counts, finds dormant admins, weak
    accounts, AS-REP-roastable accounts. Does NOT decrypt NT/LM
    hashes (that's a follow-up task for secretsdump with the
    SYSTEM boot key); this tool inventories the attack-surface
    metadata.
    """

    def __init__(self, ntds_path: Optional[Path],
                 logger: logging.Logger):
        self.ntds_path = ntds_path
        self.logger = logger
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if not self.ntds_path or not _safe_exists(self.ntds_path):
            return self.state, self.findings
        try:
            from dissect.esedb import EseDB
        except ImportError:
            self.logger.info(
                "NTDS analysis skipped — dissect.esedb not "
                "installed")
            return self.state, self.findings
        try:
            with open(self.ntds_path, "rb") as fh:
                db = EseDB(fh)
                self._parse(db)
        except Exception as exc:
            self.logger.warning("NTDS parse failed: %s", exc)
        self._analyze()
        self.logger.info(
            "NTDS: %d users, %d computers, %d findings",
            self.state.get("user_count", 0),
            self.state.get("computer_count", 0),
            len(self.findings))
        return self.state, self.findings

    def _parse(self, db) -> None:
        users: List[Dict[str, Any]] = []
        computers = 0
        try:
            t = db.table("datatable")
            for row in t.records():
                try:
                    obj_cls = row.get("sAMAccountType")
                except Exception:
                    continue
                if obj_cls is None:
                    continue
                # 0x30000000 = user, 0x30000001 = trust, 0x30000002 =
                # normal computer; subset only
                if obj_cls & 0xF0000000 != 0x30000000:
                    continue
                try:
                    sam = row.get("sAMAccountName")
                    uac = row.get("userAccountControl") or 0
                    pwd_last = row.get("pwdLastSet")
                    last_logon = row.get("lastLogonTimestamp")
                except Exception:
                    continue
                if not sam:
                    continue
                if str(sam).endswith("$"):
                    computers += 1
                    continue
                users.append({
                    "sam": str(sam),
                    "uac": int(uac or 0),
                    "pwd_last": (_filetime_to_iso(pwd_last)
                                  if pwd_last else None),
                    "last_logon": (_filetime_to_iso(last_logon)
                                    if last_logon else None),
                })
                if len(users) > 5000:
                    break
        except Exception as exc:
            self.logger.debug("NTDS datatable: %s", exc)
        self.state = {
            "user_count": len(users),
            "computer_count": computers,
            "users": users[:1500],
        }

    def _analyze(self) -> None:
        users = self.state.get("users") or []
        # UAC flags
        UF_DONT_REQUIRE_PREAUTH = 0x400000
        UF_PASSWD_NOTREQD       = 0x0020
        UF_DONT_EXPIRE_PASSWD   = 0x10000
        UF_ACCOUNTDISABLE       = 0x0002

        asrep_users, no_pwd, no_expire, dormant = [], [], [], []
        now = _now_utc()
        for u in users:
            uac = u["uac"]
            if uac & UF_ACCOUNTDISABLE:
                continue
            if uac & UF_DONT_REQUIRE_PREAUTH:
                asrep_users.append(u["sam"])
            if uac & UF_PASSWD_NOTREQD:
                no_pwd.append(u["sam"])
            if uac & UF_DONT_EXPIRE_PASSWD:
                no_expire.append(u["sam"])
            # Dormant: last_logon > 90 days ago
            try:
                if u.get("last_logon"):
                    ll = _parse_ts(u["last_logon"])
                    if ll and (now - ll).days > 90:
                        dormant.append(u["sam"])
            except Exception:
                continue

        if asrep_users:
            self.findings.append(Finding(
                source="ntds",
                category="credential.asrep_roastable",
                title=f"AS-REP roastable accounts: "
                      f"{len(asrep_users)}",
                severity=SEV_HIGH,
                conclusion=(
                    f"{len(asrep_users)} user account(s) in the "
                    "domain have 'Do not require Kerberos "
                    "preauthentication' set. Every one of them can "
                    "be AS-REP roasted — their AS-REP ciphertext "
                    "can be extracted without any interaction and "
                    "cracked offline. Remove the flag from every "
                    "account in the list below."),
                description="NTDS sweep for UF_DONT_REQUIRE_PREAUTH.",
                evidence={"users": asrep_users[:200],
                           "total": len(asrep_users)},
                tags=["T1558.004", "credential-access"]))
        if no_pwd:
            self.findings.append(Finding(
                source="ntds",
                category="credential.passwd_notreqd",
                title=f"Accounts with PASSWD_NOTREQD: {len(no_pwd)}",
                severity=SEV_HIGH,
                conclusion=(
                    f"{len(no_pwd)} account(s) are configured to "
                    "allow empty passwords. These are typically "
                    "backdoor accounts left by previous attackers "
                    "or legacy integrations. Remove the flag, "
                    "rotate passwords, and audit creation history."),
                description="NTDS sweep for UF_PASSWD_NOTREQD.",
                evidence={"users": no_pwd[:200],
                           "total": len(no_pwd)},
                tags=["T1098"]))
        if dormant:
            self.findings.append(Finding(
                source="ntds", category="ntds.dormant_accounts",
                title=f"Dormant accounts (>90d no logon): "
                      f"{len(dormant)}",
                severity=SEV_LOW,
                conclusion=(
                    f"{len(dormant)} account(s) have not logged in "
                    "for more than 90 days but are still enabled. "
                    "Attack-surface reduction: disable unused "
                    "accounts. Dormant accounts are the preferred "
                    "targets for password spraying."),
                description="NTDS lastLogonTimestamp > 90d ago.",
                evidence={"users": dormant[:200],
                           "total": len(dormant)},
                tags=["hardening"]))


# ---------------------------------------------------------------------------
# Optional pcap capture (pktmon built-in).
# ---------------------------------------------------------------------------

class PcapTrigger:
    """Starts a short pktmon capture during triage for offline
    analysis. Does not ship the capture anywhere — file lands in
    workdir."""

    def __init__(self, workdir: Path, duration_s: int,
                 logger: logging.Logger):
        self.workdir = workdir
        self.duration_s = duration_s
        self.logger = logger
        self.pcap_path: Optional[Path] = None

    def run(self) -> Optional[Path]:
        if self.duration_s <= 0 or os.name != "nt":
            return None
        pktmon = shutil.which("pktmon.exe") \
            or r"C:\Windows\System32\pktmon.exe"
        if not _safe_exists(Path(pktmon)):
            self.logger.info("pcap: pktmon not available")
            return None
        etl = self.workdir / f"fma-capture-{int(time.time())}.etl"
        try:
            self.logger.info("pcap: starting pktmon (%ds)",
                              self.duration_s)
            subprocess.run([pktmon, "start", "--capture",
                             "--file-name", str(etl),
                             "--pkt-size", "128"],
                            capture_output=True, timeout=15)
            time.sleep(self.duration_s)
            subprocess.run([pktmon, "stop"], capture_output=True,
                            timeout=15)
            self.pcap_path = etl
            self.logger.info("pcap: capture saved to %s", etl)
            return etl
        except Exception as exc:
            self.logger.debug("pcap capture failed: %s", exc)
            return None


# ---------------------------------------------------------------------------
# IoC ingestion.
# ---------------------------------------------------------------------------

@dataclass
class IoCSet:
    ips:       Set[str] = field(default_factory=set)
    domains:   Set[str] = field(default_factory=set)
    sha256:    Set[str] = field(default_factory=set)
    md5:       Set[str] = field(default_factory=set)
    filenames: Set[str] = field(default_factory=set)
    yara_paths: List[Path] = field(default_factory=list)

    @classmethod
    def load(cls, path: Optional[Path]) -> "IoCSet":
        if not path or not path.exists():
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return cls()
        def _lower(xs):
            return {str(x).lower().strip() for x in (xs or []) if x}
        return cls(
            ips=_lower(data.get("ips")),
            domains=_lower(data.get("domains")),
            sha256=_lower(data.get("hashes_sha256")
                          or data.get("sha256")),
            md5=_lower(data.get("hashes_md5") or data.get("md5")),
            filenames=_lower(data.get("filenames")),
            yara_paths=[Path(p) for p in (data.get("yara") or [])
                        if Path(p).exists()],
        )

    def is_empty(self) -> bool:
        return not (self.ips or self.domains or self.sha256
                    or self.md5 or self.filenames or self.yara_paths)

    def match_hash(self, h: str) -> bool:
        h = (h or "").lower()
        return h in self.sha256 or h in self.md5

    def match_ip(self, ip: str) -> bool:
        return (ip or "").lower() in self.ips

    def match_domain(self, d: str) -> bool:
        d = (d or "").lower()
        return any(d == i or d.endswith("." + i) for i in self.domains)

    def match_filename(self, name: str) -> bool:
        n = (name or "").lower()
        base = Path(n).name
        return base in self.filenames or n in self.filenames


# ---------------------------------------------------------------------------
# IP reputation — cloud/CDN allowlist so benign outbound noise is dropped.
# ---------------------------------------------------------------------------

# Very conservative prefix list covering the biggest public-cloud and
# CDN blocks. Drops ~90% of benign IPv4 noise without needing MISP.
BENIGN_IP_PREFIXES = (
    # Microsoft
    "13.64.", "13.65.", "13.66.", "13.67.", "13.68.", "13.69.",
    "13.70.", "13.71.", "13.72.", "13.73.", "13.74.", "13.75.",
    "13.76.", "13.77.", "13.78.", "13.80.", "13.81.", "13.82.",
    "13.83.", "13.84.", "13.85.", "13.86.", "13.87.", "13.88.",
    "13.89.", "13.90.", "13.91.", "13.92.", "13.93.", "13.94.",
    "13.95.", "20.", "23.100.", "40.", "51.", "52.", "65.52.",
    "65.55.", "94.245.", "104.40.", "104.41.", "104.42.", "104.43.",
    "104.44.", "104.45.", "104.46.", "104.47.", "168.61.", "168.62.",
    "168.63.",
    # Google
    "8.8.8.8", "8.8.4.4", "34.", "35.", "142.250.", "142.251.",
    "172.217.", "216.58.", "216.239.", "74.125.",
    # AWS
    "3.5.", "15.177.", "52.94.", "54.239.", "99.78.", "99.79.",
    "99.80.", "99.81.", "99.82.", "99.83.", "99.84.", "99.85.",
    "99.86.", "99.87.",
    # Cloudflare
    "1.1.1.1", "1.0.0.1", "104.16.", "104.17.", "104.18.",
    "172.64.", "172.65.", "172.66.", "172.67.", "173.245.",
    # Akamai
    "23.0.", "23.1.", "23.2.", "23.3.", "23.4.", "23.5.",
    "104.64.", "104.65.", "104.66.", "104.67.", "104.68.",
    "104.69.", "104.70.", "104.71.", "104.72.", "104.73.",
    "104.74.", "104.75.", "104.76.", "104.77.", "104.78.",
    "104.79.", "184.24.", "184.25.", "184.26.", "184.27.",
    "184.28.", "184.29.", "184.30.", "184.31.",
    # Apple
    "17.",
    # Facebook/Meta
    "31.13.", "66.220.", "69.63.", "69.171.", "74.119.",
    "102.132.", "157.240.", "179.60.", "185.60.", "204.15.",
)


def ip_is_benign_cloud(ip: str) -> bool:
    if not ip:
        return False
    return any(ip.startswith(p) for p in BENIGN_IP_PREFIXES)


# ---------------------------------------------------------------------------
# System profile — hostname, OS, IPs, MACs, domain, logged-on users.
# ---------------------------------------------------------------------------

class SystemProfileAnalyzer:
    """
    Collects the 'who/what/where' of the endpoint under investigation.
    Populates a dictionary that the report renders at the very top so
    any analyst opening the report knows immediately which machine
    this is about — hostname, OS build, MAC, IP, logged-on users.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.profile: Dict[str, Any] = {}

    def run(self) -> Dict[str, Any]:
        self.profile["hostname"] = platform.node()
        self.profile["python"] = platform.python_version()
        self.profile["architecture"] = platform.machine()
        self.profile["platform"] = platform.platform()
        # Network interfaces (psutil)
        try:
            import psutil
            nets: Dict[str, Any] = {}
            for iface, addrs in psutil.net_if_addrs().items():
                info = {"ipv4": [], "ipv6": [], "mac": None}
                for a in addrs:
                    fam = getattr(a, "family", None)
                    fam_name = getattr(fam, "name", str(fam))
                    if "AF_INET6" in fam_name:
                        info["ipv6"].append(a.address)
                    elif "AF_INET" in fam_name:
                        info["ipv4"].append(a.address)
                    elif "AF_LINK" in fam_name or "AF_PACKET" in fam_name:
                        info["mac"] = a.address
                nets[iface] = info
            self.profile["interfaces"] = nets
            # Stats — up/down per interface
            try:
                stats = psutil.net_if_stats()
                for iface, s in stats.items():
                    if iface in nets:
                        nets[iface]["is_up"] = s.isup
                        nets[iface]["speed_mbps"] = s.speed
            except Exception:
                pass
            # Boot time
            self.profile["boot_time"] = dt.datetime.fromtimestamp(
                psutil.boot_time(),
                tz=dt.timezone.utc).isoformat()
            # Logged-on users
            users = []
            for u in psutil.users():
                users.append({
                    "name": u.name, "terminal": u.terminal,
                    "host": u.host,
                    "started": dt.datetime.fromtimestamp(
                        u.started,
                        tz=dt.timezone.utc).isoformat(),
                })
            self.profile["logged_on_users"] = users
        except ImportError:
            pass
        if os.name == "nt":
            self._collect_windows()
        self.logger.info(
            "System profile: host=%s domain=%s os=%s build=%s",
            self.profile.get("hostname"),
            self.profile.get("domain"),
            self.profile.get("os_caption"),
            self.profile.get("os_build"))
        return self.profile

    def _collect_windows(self) -> None:
        ps = shutil.which("powershell.exe")
        if not ps:
            return
        script = r"""
$ErrorActionPreference = 'SilentlyContinue'
$cs = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$bios = Get-CimInstance Win32_BIOS
$tz = Get-TimeZone
$locals = @()
try {
    $locals = Get-LocalUser | Select-Object Name, Enabled, `
        LastLogon, Description, SID
} catch {}
$groups = @()
try {
    $groups = Get-LocalGroupMember -Group Administrators |
        Select-Object Name, PrincipalSource, ObjectClass
} catch {}
$ip = $null
try { $ip = (Invoke-RestMethod https://api.ipify.org -TimeoutSec 3) } `
catch {}
$out = [ordered]@{
    ComputerName       = $cs.Name
    Domain             = $cs.Domain
    Workgroup          = $cs.Workgroup
    PartOfDomain       = $cs.PartOfDomain
    Manufacturer       = $cs.Manufacturer
    Model              = $cs.Model
    TotalMemoryGB      = [math]::Round($cs.TotalPhysicalMemory/1GB,1)
    NumberOfCPUs       = $cs.NumberOfLogicalProcessors
    os_caption         = $os.Caption
    os_version         = $os.Version
    os_build           = $os.BuildNumber
    os_arch            = $os.OSArchitecture
    os_install_date    = if ($os.InstallDate) {$os.InstallDate.ToString('o')} else {$null}
    os_last_boot       = if ($os.LastBootUpTime) {$os.LastBootUpTime.ToString('o')} else {$null}
    bios_serial        = $bios.SerialNumber
    bios_version       = $bios.SMBIOSBIOSVersion
    timezone           = $tz.Id
    local_users        = $locals
    local_administrators = $groups
    external_ip        = $ip
}
$out | ConvertTo-Json -Depth 4 -Compress
"""
        try:
            result = subprocess.run(
                [ps, "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=40)
            if result.stdout.strip():
                data = json.loads(result.stdout)
                self.profile.update(data)
        except Exception as exc:
            self.logger.debug("sysprofile ps failed: %s", exc)


# ---------------------------------------------------------------------------
# Domain intelligence: membership, Kerberos tickets, Credential
# Manager, cached domain logons, SMB shares, DC interactions, user
# profiles, information-leakage indicators.
# ---------------------------------------------------------------------------

class DomainIntelAnalyzer:
    """
    Consolidates everything related to the endpoint's domain posture
    and the information an attacker could extract about domain users:

      * Domain membership + domain controller visibility
      * Current user's token: groups, privileges, claims (whoami /all)
      * Cached Kerberos TGT / TGS (klist, klist sessions)
      * Saved credentials in Credential Manager (cmdkey /list)
      * Cached-logons count (registry) — how many domain users' hashes
        are stored locally for offline logon
      * Local user profiles under C:\\Users (SID-resolved)
      * Local SMB share exposure (net share)
      * Recent DC interactions (DNS cache for _ldap._tcp records)
      * Remote-access software installed — lateral / exfil risk
      * AD recon tooling present on disk / in process tree
      * GPP cpassword exposure under SYSVOL (if accessible)

    Detections emitted:
      * Domain recon via net.exe / nltest / dsquery / ADfind / PS AD
        module (Sysmon 1 / 4688 / PS 4104)
      * Saved domain-admin credential in Credential Manager
      * Unusually high cached-logons count (stolen-hash surface)
      * Hidden administrative share exposure
      * Stale / orphan domain user profiles on disk
    """

    # Recon / AD-query tooling names to flag when they appear in
    # Prefetch / BAM / 4688 / process tree.
    AD_RECON_TOOLS = {
        "adfind.exe", "adrecon.exe", "bloodhound.exe",
        "sharphound.exe", "sharpview.exe", "ldapsearch.exe",
        "dsquery.exe", "nltest.exe", "rpcdump.exe",
        "powerview.ps1", "sharpkatz.exe",
        "seatbelt.exe", "winpeas.exe",
    }

    REMOTE_ACCESS_TOOLS = {
        "anydesk.exe", "teamviewer.exe", "teamviewer_service.exe",
        "lmiignition.exe", "chromeremotedesktophost.exe",
        "splashtop.exe", "ngrok.exe", "plink.exe", "putty.exe",
        "vncviewer.exe", "tvnserver.exe", "uvncservice.exe",
        "rustdesk.exe", "atera_agent.exe", "supremoservice.exe",
    }

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        self._collect_whoami()
        self._collect_klist()
        self._collect_cmdkey()
        self._collect_net_info()
        self._collect_user_profiles()
        self._collect_cached_logons_count()
        self._collect_dns_dc_clues()
        self._collect_sysvol_gpp()
        self._detect_domain_tooling()
        self._detect_remote_access()
        self.logger.info(
            "Domain intel: kerb=%d tickets, cred-mgr=%d saved, "
            "profiles=%d, shares=%d, cached-logons=%s, %d findings",
            len(self.state.get("klist", []) or []),
            len(self.state.get("cmdkey", []) or []),
            len(self.state.get("user_profiles", []) or []),
            len(self.state.get("smb_shares", []) or []),
            self.state.get("cached_logons_count"),
            len(self.findings))
        return self.state, self.findings

    # -- whoami / token / groups / privileges ------------------------

    def _collect_whoami(self) -> None:
        out = self._run(["whoami.exe", "/all", "/fo", "csv"])
        if not out:
            return
        # Four blocks separated by blank lines:
        #   USER INFORMATION / GROUP INFORMATION / PRIVILEGES / CLAIMS
        #   each block has a CSV header row.
        blocks = re.split(r"\r?\n\r?\n", out)
        parsed: Dict[str, List[Dict[str, Any]]] = {}
        import csv
        for block in blocks:
            lines = [l for l in block.splitlines() if l.strip()
                     and not l.startswith("USER INFORMATION")
                     and not l.startswith("GROUP INFORMATION")
                     and not l.startswith("PRIVILEGES INFORMATION")
                     and not l.startswith("USER CLAIMS INFORMATION")
                     and not l.startswith("---")]
            if len(lines) < 2:
                continue
            reader = csv.DictReader(lines)
            key = (reader.fieldnames or ["unknown"])[0]
            rows = list(reader)
            if "User Name" in (reader.fieldnames or []):
                parsed["user"] = rows
            elif "Group Name" in (reader.fieldnames or []):
                parsed["groups"] = rows
            elif "Privilege Name" in (reader.fieldnames or []):
                parsed["privileges"] = rows
            else:
                parsed["claims"] = rows
        self.state["whoami"] = parsed

    # -- klist (current + all sessions) -----------------------------

    def _collect_klist(self) -> None:
        tickets: List[Dict[str, Any]] = []
        out = self._run(["klist.exe"])
        if out:
            tickets.extend(self._parse_klist(out, session="current"))
        # `klist sessions` needs admin; failure is normal
        sess = self._run(["klist.exe", "sessions"])
        if sess:
            self.state["klist_sessions"] = sess[:4000]
        self.state["klist"] = tickets

    @staticmethod
    def _parse_klist(text: str, session: str
                      ) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        current: Dict[str, Any] = {}
        num_re = re.compile(r"^#\d+>")
        for line in text.splitlines():
            s = line.strip()
            if num_re.match(s):
                if current:
                    out.append(current)
                current = {"session": session}
                continue
            m = re.match(r"^Client:\s*(.+)", s)
            if m: current["client"] = m.group(1).strip(); continue
            m = re.match(r"^Server:\s*(.+)", s)
            if m: current["server"] = m.group(1).strip(); continue
            m = re.match(r"^KerbTicket Encryption Type:\s*(.+)", s)
            if m: current["enc"] = m.group(1).strip(); continue
            m = re.match(r"^Ticket Flags\s+(.+)", s)
            if m: current["flags"] = m.group(1).strip(); continue
            m = re.match(r"^Start Time:\s*(.+)", s)
            if m: current["start"] = m.group(1).strip(); continue
            m = re.match(r"^End Time:\s*(.+)", s)
            if m: current["end"] = m.group(1).strip(); continue
            m = re.match(r"^Renew Time:\s*(.+)", s)
            if m: current["renew"] = m.group(1).strip(); continue
        if current:
            out.append(current)
        return out

    # -- Credential Manager -----------------------------------------

    def _collect_cmdkey(self) -> None:
        out = self._run(["cmdkey.exe", "/list"])
        if not out:
            return
        entries: List[Dict[str, Any]] = []
        cur: Dict[str, Any] = {}
        for line in out.splitlines():
            s = line.strip()
            if s.startswith("Target:"):
                if cur:
                    entries.append(cur)
                cur = {"target": s.split(":", 1)[1].strip()}
            elif s.startswith("Type:"):
                cur["type"] = s.split(":", 1)[1].strip()
            elif s.startswith("User:"):
                cur["user"] = s.split(":", 1)[1].strip()
            elif s.startswith("Local machine persistence"):
                cur["persistence"] = "local machine"
            elif s.startswith("Enterprise persistence"):
                cur["persistence"] = "enterprise"
        if cur:
            entries.append(cur)
        self.state["cmdkey"] = entries
        for e in entries:
            user = (e.get("user") or "").lower()
            target = (e.get("target") or "").lower()
            # Flag domain admin / server admin creds stored locally.
            if any(k in user for k in ("admin", "administrator",
                                        "_adm", "svc_", "sa_")) \
                    or any(k in target for k in (
                        "domain\\", ".local\\", ".corp\\")):
                self.findings.append(Finding(
                    source="domain",
                    category="credential.saved_admin",
                    title=f"Saved admin credential: {user or target}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Credential Manager stores credential "
                        f"'{user}' for target '{e.get('target')}'. "
                        "Admin-shaped credentials cached on a "
                        "workstation become a lateral-movement "
                        "springboard for anyone who compromises this "
                        "host (they are accessible to the current "
                        "user's process context without prompting)."),
                    description="cmdkey /list entry matching admin "
                                "heuristic.",
                    evidence=e,
                    tags=["T1555.004", "credential-access"]))

    # -- net config + net share + nltest ----------------------------

    def _collect_net_info(self) -> None:
        cfg = self._run(["net.exe", "config", "workstation"])
        if cfg:
            # Extract a few key fields
            fields: Dict[str, Any] = {}
            for line in cfg.splitlines():
                m = re.match(r"^(.*?)\s{2,}(.+)$", line.strip())
                if m:
                    key = m.group(1).strip().rstrip(":")
                    fields[key] = m.group(2).strip()
            self.state["net_config_workstation"] = fields
        shares = self._run(["net.exe", "share"])
        if shares:
            entries: List[Dict[str, Any]] = []
            for line in shares.splitlines()[4:]:      # skip header
                line = line.strip()
                if not line or line.startswith("-") \
                        or line.lower().startswith("the command"):
                    continue
                parts = re.split(r"\s{2,}", line, maxsplit=2)
                if len(parts) >= 2:
                    entries.append({
                        "name": parts[0],
                        "path": parts[1] if len(parts) > 1 else "",
                        "remark": parts[2] if len(parts) > 2 else "",
                    })
            self.state["smb_shares"] = entries
            # Administrative shares are OK by default on admin-capable
            # boxes; NON-default named shares are worth a note.
            default_admins = {"ADMIN$", "IPC$", "PRINT$", "C$",
                              "D$", "E$"}
            for s in entries:
                if s["name"].upper() not in default_admins and \
                        s["name"] and not s["name"].startswith("-"):
                    self.findings.append(Finding(
                        source="domain",
                        category="exposure.custom_share",
                        title=f"Non-default SMB share: {s['name']}",
                        severity=SEV_LOW,
                        conclusion=(
                            f"Local SMB share '{s['name']}' is "
                            f"exposed at path '{s['path']}'. "
                            "Verify the share ACL — world-readable "
                            "shares on domain-joined hosts are a "
                            "classic data-leak path."),
                        description="net.exe share enumeration.",
                        evidence=s,
                        tags=["exposure", "smb"]))
        # Domain controllers visible via nltest
        dcs = self._run(["nltest.exe", "/dclist:"])
        if dcs:
            self.state["nltest_dclist"] = dcs[:2000]

    # -- User profiles on disk --------------------------------------

    def _collect_user_profiles(self) -> None:
        users = Path(r"C:\Users")
        if not _safe_exists(users):
            return
        entries: List[Dict[str, Any]] = []
        try:
            iterable = list(users.iterdir())
        except (OSError, PermissionError):
            iterable = []
        for p in iterable:
            try:
                if not p.is_dir():
                    continue
            except (OSError, PermissionError):
                continue
            if p.name in ("Public", "Default", "Default User",
                           "All Users", "DefaultAccount",
                           "WDAGUtilityAccount"):
                continue
            try:
                stat = p.stat()
                entry = {
                    "name": p.name,
                    "path": str(p),
                    "created": dt.datetime.fromtimestamp(
                        stat.st_ctime,
                        tz=dt.timezone.utc).isoformat(),
                    "accessed": dt.datetime.fromtimestamp(
                        stat.st_atime,
                        tz=dt.timezone.utc).isoformat(),
                    "modified": dt.datetime.fromtimestamp(
                        stat.st_mtime,
                        tz=dt.timezone.utc).isoformat(),
                    "ntuser_present": _safe_exists(p / "NTUSER.DAT"),
                }
                entries.append(entry)
            except (OSError, PermissionError):
                continue
        self.state["user_profiles"] = entries

    # -- Cached domain logons count ---------------------------------

    def _collect_cached_logons_count(self) -> None:
        try:
            import winreg
            with winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE,
                    r"Software\Microsoft\Windows NT\CurrentVersion"
                    r"\Winlogon") as k:
                v, _ = winreg.QueryValueEx(k, "CachedLogonsCount")
                count = int(v)
                self.state["cached_logons_count"] = count
                if count > 0:
                    self.findings.append(Finding(
                        source="domain",
                        category="credential.mscache_surface",
                        title=f"MSCache2 cached-logons surface: "
                              f"{count}",
                        severity=SEV_LOW if count <= 10 else SEV_MED,
                        conclusion=(
                            f"CachedLogonsCount = {count}. This many "
                            "domain-user password hashes (MSCache2 "
                            "format) are persisted locally for "
                            "offline logon. An attacker with SYSTEM "
                            "on this host can pull all of them from "
                            "the SECURITY hive and crack offline."),
                        description=(
                            "HKLM\\Software\\Microsoft\\Windows NT\\"
                            "CurrentVersion\\Winlogon\\"
                            "CachedLogonsCount"),
                        evidence={"cached_logons_count": count},
                        tags=["T1003.005", "credential-access"]))
        except (ImportError, OSError, ValueError):
            pass

    # -- DNS clues about DCs ----------------------------------------

    def _collect_dns_dc_clues(self) -> None:
        # If the DNS resolver cache already has _ldap._tcp or
        # _kerberos._tcp records, the domain is reachable.
        cache = self.state.get("_dns_cache_probe")
        if cache is None:
            out = self._run(["ipconfig.exe", "/displaydns"])
            cache = out or ""
            self.state["_dns_cache_probe"] = cache
        srv_records = re.findall(
            r"(_ldap\._tcp\.[^\s\.]+(?:\.[^\s\.]+)*)",
            cache, flags=re.IGNORECASE)
        if srv_records:
            self.state["dns_domain_srv_records"] = sorted(
                set(srv_records))[:20]

    # -- SYSVOL cpassword sweep (if mapped) -------------------------

    def _collect_sysvol_gpp(self) -> None:
        # Only attempts the local view; full enterprise sweep is out
        # of scope. The presence of any <Groups cpassword="..."/> on
        # an accessible SYSVOL is a straight critical.
        candidates = [
            Path(r"\\?\SYSVOL"),
            Path(r"C:\Windows\SYSVOL"),
            Path(r"C:\Windows\SYSVOL\domain\Policies"),
            Path(r"C:\Windows\SYSVOL\sysvol"),
        ]
        found: List[Dict[str, Any]] = []
        for root in candidates:
            if not root.exists():
                continue
            try:
                for xml in root.rglob("Groups.xml"):
                    try:
                        text = xml.read_text(
                            encoding="utf-16", errors="ignore")
                        if "<?xml" not in text:
                            text = xml.read_text(
                                encoding="utf-8", errors="ignore")
                    except (OSError, PermissionError):
                        continue
                    if "cpassword" in text.lower():
                        found.append({"path": str(xml)})
            except (OSError, PermissionError):
                continue
        if found:
            self.state["gpp_cpassword"] = found
            self.findings.append(Finding(
                source="domain",
                category="credential.gpp_cpassword",
                title=f"GPP cpassword exposure ({len(found)} file(s))",
                severity=SEV_CRIT,
                conclusion=(
                    "SYSVOL Groups.xml files with the `cpassword` "
                    "attribute are accessible from this host. The "
                    "cpassword value is AES-encrypted with a "
                    "Microsoft-published key — anyone reading the "
                    "file can decrypt. This is an instant domain "
                    "credential leak (MS14-025) that Microsoft "
                    "stopped writing a decade ago but many domains "
                    "never cleaned up."),
                description="Groups.xml with cpassword attribute.",
                evidence={"paths": [f["path"] for f in found[:8]]},
                tags=["T1552.006", "credential-access"]))

    # -- AD-recon tooling present on disk / in process tree --------

    def _detect_domain_tooling(self) -> None:
        # Simple name-based sweep against:
        #   * recent prefetch / BAM paths
        #   * live process tree basenames
        # Heavy lifting (full hash / signature verification) happens
        # in the Enrichment pass on the generated findings.
        # We key on basename only — easy to lookup.
        hits: Dict[str, str] = {}

        # Live procs
        try:
            import psutil
            for p in psutil.process_iter(attrs=["name", "exe"]):
                try:
                    name = (p.info.get("name") or "").lower()
                    if name in self.AD_RECON_TOOLS:
                        hits[name] = p.info.get("exe") or name
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass

        # Prefetch
        pf_dir = Path(r"C:\Windows\Prefetch")
        if pf_dir.exists():
            for pf in pf_dir.glob("*.pf"):
                base = re.sub(r"-[0-9a-f]{8,}\.pf$", "",
                              pf.name.lower())
                exe_name = base if base.endswith(".exe") \
                    else base + ".exe"
                if exe_name in self.AD_RECON_TOOLS:
                    hits.setdefault(exe_name, str(pf))

        for tool, location in hits.items():
            self.findings.append(Finding(
                source="domain",
                category="discovery.ad_recon_tooling",
                title=f"AD recon tool present: {tool}",
                severity=SEV_HIGH,
                conclusion=(
                    f"'{tool}' was executed on this host "
                    f"(evidence: {location}). This binary is on the "
                    "offensive AD-reconnaissance hotlist — attackers "
                    "run it after a foothold to enumerate "
                    "users / groups / SPNs / GPOs / ACLs. Unless the "
                    "blue team ran it for authorized exercise, treat "
                    "as active intrusion."),
                description="Known AD-recon tool execution trace.",
                evidence={"tool": tool, "location": location},
                tags=["T1087.002", "T1018", "discovery"]))

    def _detect_remote_access(self) -> None:
        try:
            import psutil
            for p in psutil.process_iter(attrs=["name", "exe", "pid",
                                                  "username"]):
                try:
                    name = (p.info.get("name") or "").lower()
                    if name in self.REMOTE_ACCESS_TOOLS:
                        self.findings.append(Finding(
                            source="domain",
                            category="exposure.remote_access_tool",
                            title=f"Remote-access tool running: {name}",
                            severity=SEV_MED,
                            conclusion=(
                                f"'{name}' is running (PID "
                                f"{p.info.get('pid')}, exe="
                                f"{p.info.get('exe') or '?'}). Remote-"
                                "access / screen-sharing tools on a "
                                "domain-joined endpoint are a known "
                                "lateral-movement and exfil vector. "
                                "Confirm with the user that this is "
                                "sanctioned IT access."),
                            description="Known remote-access tool "
                                        "live.",
                            evidence={"name": name, "pid": p.info.get(
                                "pid"), "exe": p.info.get("exe")},
                            tags=["T1219", "exposure"]))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass

    # -- Helper: subprocess with short timeout + utf/cp fallback ----

    @staticmethod
    def _run(cmd: List[str]) -> Optional[str]:
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=30, encoding="cp1252", errors="ignore")
            out = (result.stdout or "").strip()
            return out or None
        except (subprocess.TimeoutExpired, OSError,
                FileNotFoundError):
            return None


# ---------------------------------------------------------------------------
# Darknet / data-leakage indicators.
# ---------------------------------------------------------------------------

class DarknetLeakAnalyzer:
    """
    Detects indicators of data being exfiltrated toward the darknet
    or anonymous-publishing infrastructure:

      * Tor client / Tor Browser presence (processes / directories /
        DNS queries to torproject.org / .onion history visits)
      * Paste-site activity (pastebin, ghostbin, rentry, ...)
      * Anonymous file-share visits + downloads (anonfile, mega.nz,
        transfer.sh, file.io, gofile.io, catbox, etc.)
      * Stealer drop files (passwords.txt / wallets.txt / cookies.txt
        at well-known exfil staging locations)
      * Archive staging for exfil (encrypted 7z/rar/zip with
        suspicious names and recent mtime in Downloads/Desktop/Docs)
      * Credential-dumping tool binaries on disk
      * DNS cache hits to onion proxies / leak-site research mirrors

    These are all *candidate* indicators — each finding includes the
    evidence path so the analyst can verify.
    """

    # Known domains / process names for anonymous publishing and Tor
    TOR_PROCESS_NAMES = {
        "tor.exe", "tor-browser.exe", "firefox.exe",  # TB uses ff
        "obfs4proxy.exe", "meek-client.exe",
        "snowflake-client.exe", "i2psvc.exe",
    }
    TOR_DIR_HINTS = (
        "tor browser", "\\tor\\", "tor-browser_",
        "\\torbrowser\\", "i2p\\",
    )
    TOR_DNS_HINTS = (
        "torproject.org", "bridges.torproject.org",
        "snowflake.torproject.org", "dist.torproject.org",
        "check.torproject.org", "meek.azureedge.net",
    )
    PASTE_SITES = {
        "pastebin.com", "paste.ee", "pasteio.com", "hastebin.com",
        "dpaste.com", "ghostbin.com", "privatebin.info",
        "pastelink.net", "justpaste.it", "rentry.co",
        "controlc.com", "p.ip.fi", "privatebin.net",
        "paste.pics", "paste.org", "bpa.st",
    }
    ANON_UPLOAD = {
        "anonfile.com", "anonfiles.com", "mega.nz", "mega.io",
        "sendspace.com", "wetransfer.com", "we.tl", "file.io",
        "transfer.sh", "gofile.io", "pixeldrain.com",
        "uploadfiles.io", "dropmefiles.com", "filemail.com",
        "catbox.moe", "litterbox.catbox.moe", "uguu.se",
        "0x0.st", "tmp.ninja", "workupload.com",
        "anonymfiles.com", "send.cm", "send.exploit.in",
    }
    LEAK_SITE_HINTS = {
        # Partial, indicative. Many leak sites live on onion and are
        # reached via their clearnet "news" / "contact" mirrors.
        "ransomlook.io", "dnmlist.com", "ransomwatch.io",
        "lockbitsupp", "contirecovery",
    }
    # Stealer-family drop / dump filenames commonly seen in
    # Vidar / Raccoon / RedLine / MetaStealer archives. Pure name
    # heuristic — the analyst verifies via the evidence path.
    STEALER_FILES = {
        "passwords.txt", "wallets.txt", "autofills.txt",
        "credentials.txt", "cookies.txt", "history.txt",
        "system_info.txt", "information.txt", "loginusers.txt",
        "screen.jpg", "outlook.txt", "telegram.zip",
        "browsers.zip", "wallets.zip", "cards.txt",
    }
    # Credential-recovery tool binaries (Nirsoft family + LaZagne)
    CRED_TOOLS = {
        "lazagne.exe", "chromepass.exe", "webbrowserpassview.exe",
        "mailpv.exe", "winlogonview.exe", "networkpassrec.exe",
        "remotedesktoppassview.exe", "wifipasswordrevealer.exe",
        "credentialsfileview.exe", "vaultpasswordview.exe",
        "iepv.exe", "pwdump.exe", "fgdump.exe",
        "mimikatz.exe", "secretsdump.py", "pypykatz.exe",
    }

    def __init__(self, logger: logging.Logger,
                 browser_state: Optional[Dict[str, Any]] = None,
                 net_state: Optional[Dict[str, Any]] = None):
        self.logger = logger
        self.browser = browser_state or {}
        self.net = net_state or {}
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        self._check_tor_presence()
        self._check_paste_anon_browser()
        self._check_onion_visits()
        self._check_dns_leak_hints()
        self._check_stealer_drops()
        self._check_archive_staging()
        self._check_credential_tools()
        self.logger.info(
            "Darknet/leak: %d findings", len(self.findings))
        return self.state, self.findings

    # -- Tor presence (live + on disk + DNS) -----------------------

    def _check_tor_presence(self):
        hits: Dict[str, List[Dict[str, Any]]] = {
            "processes": [], "dirs": [], "dns": [], "prefetch": []}
        # Live processes
        try:
            import psutil
            for p in psutil.process_iter(
                    attrs=["name", "exe", "pid"]):
                try:
                    name = (p.info.get("name") or "").lower()
                    exe = (p.info.get("exe") or "").lower()
                    if name == "tor.exe" or "tor browser" in exe \
                            or "\\tor\\tor.exe" in exe:
                        hits["processes"].append(p.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass
        # Directories under common roots
        for root in (Path(r"C:\Program Files"),
                      Path(r"C:\Program Files (x86)"),
                      Path(os.environ.get("LOCALAPPDATA") or ""),
                      Path(os.environ.get("APPDATA") or ""),
                      Path(r"C:\Users")):
            if not _safe_exists(root):
                continue
            try:
                # We wrap the generator itself; rglob can raise
                # on denied subdirectories mid-walk.
                for candidate in root.rglob("tor.exe"):
                    try:
                        hits["dirs"].append(
                            {"path": str(candidate)})
                    except (OSError, PermissionError):
                        continue
                    if len(hits["dirs"]) > 10:
                        break
            except (OSError, PermissionError):
                continue
        # DNS cache
        dns = self.net.get("dns_cache") or []
        for r in dns:
            name = (r.get("Record Name") or "").lower()
            if any(h in name for h in self.TOR_DNS_HINTS):
                hits["dns"].append(r)
        # Prefetch
        pf = Path(r"C:\Windows\Prefetch")
        if pf.exists():
            try:
                for pfile in pf.glob("TOR*.pf"):
                    hits["prefetch"].append({"path": str(pfile)})
                for pfile in pf.glob("OBFS4*.pf"):
                    hits["prefetch"].append({"path": str(pfile)})
                for pfile in pf.glob("SNOWFLAKE*.pf"):
                    hits["prefetch"].append({"path": str(pfile)})
            except OSError:
                pass
        if any(hits.values()):
            self.state["tor"] = hits
            self.findings.append(Finding(
                source="darknet", category="darknet.tor_presence",
                title="Tor / anonymity client detected on host",
                severity=SEV_HIGH,
                conclusion=(
                    "Evidence of Tor / anonymity-network software on "
                    "this host: " + ", ".join(
                        k for k, v in hits.items() if v) +
                    ". Tor on a corporate endpoint is highly unusual "
                    "and is the primary channel for interacting with "
                    "ransomware payment portals, leak sites, and "
                    "stealer drop panels. Review whether Tor usage "
                    "is sanctioned for this user."),
                description="Tor binaries / directories / DNS / "
                            "prefetch on host.",
                evidence=hits,
                tags=["T1090.003", "darknet", "exfiltration"]))

    # -- Paste / anonymous upload visits in browser ---------------

    def _check_paste_anon_browser(self):
        history = self.browser.get("history") or []
        downloads = self.browser.get("downloads") or []
        paste_hits: List[Dict[str, Any]] = []
        anon_hits: List[Dict[str, Any]] = []
        for h in history:
            url = (h.get("url") or "").lower()
            for dom in self.PASTE_SITES:
                if dom in url:
                    paste_hits.append(h)
                    break
            for dom in self.ANON_UPLOAD:
                if dom in url:
                    anon_hits.append(h)
                    break
        for d in downloads:
            src = (d.get("source_url") or "").lower()
            for dom in self.ANON_UPLOAD:
                if dom in src:
                    anon_hits.append(d)
                    break
        if paste_hits:
            samples = sorted(
                {h.get("url") for h in paste_hits
                 if h.get("url")})[:10]
            self.findings.append(Finding(
                source="darknet", category="darknet.paste_site_visit",
                title=f"Paste-site activity ({len(paste_hits)} "
                      f"visits)",
                severity=SEV_MED,
                conclusion=(
                    f"Browser history includes {len(paste_hits)} "
                    "visits to paste sites (pastebin / rentry / "
                    "ghostbin / privatebin / dpaste). Paste sites "
                    "are a simple and common exfil channel — "
                    "attackers paste stolen credentials or session "
                    "tokens anonymously and retrieve them later. "
                    "Verify the pastes against what the user "
                    "legitimately published."),
                description="Browser history with paste-site "
                            "domains.",
                evidence={"sample_urls": samples,
                           "total_visits": len(paste_hits)},
                tags=["T1567.002", "darknet", "exfiltration"]))
        if anon_hits:
            samples = sorted({h.get("url") or h.get("source_url")
                              for h in anon_hits
                              if h.get("url")
                              or h.get("source_url")})[:10]
            self.findings.append(Finding(
                source="darknet",
                category="darknet.anonymous_upload",
                title=f"Anonymous file-share activity "
                      f"({len(anon_hits)} hits)",
                severity=SEV_HIGH,
                conclusion=(
                    f"{len(anon_hits)} visits / downloads involve "
                    "anonymous file-share services "
                    "(anonfile / mega.nz / transfer.sh / gofile / "
                    "catbox / wetransfer / file.io / ...). These "
                    "services are the dominant exfiltration channel "
                    "for initial-access brokers and low-tier "
                    "ransomware affiliates — data is uploaded from "
                    "the victim and retrieved anonymously from "
                    "outside. Correlate with SRUM top-senders and "
                    "recent archive-staging files."),
                description="Browser history / download referencing "
                            "anonymous file-share services.",
                evidence={"sample_urls": samples,
                           "total_hits": len(anon_hits)},
                tags=["T1567.002", "darknet", "exfiltration"]))

    # -- .onion visits already caught in browser; re-promote --------

    def _check_onion_visits(self):
        history = self.browser.get("history") or []
        onion = [h for h in history
                 if ".onion" in (h.get("url") or "").lower()]
        if onion:
            samples = [h.get("url") for h in onion[:10]]
            self.findings.append(Finding(
                source="darknet", category="darknet.onion_visit",
                title=f".onion address visits ({len(onion)} unique)",
                severity=SEV_HIGH,
                conclusion=(
                    f"{len(onion)} visit(s) to .onion addresses in "
                    "browser history. Onion addresses resolve only "
                    "via Tor — on an enterprise endpoint this "
                    "overwhelmingly maps to ransomware payment "
                    "portals, leak-site dashboards, stealer panels, "
                    "and darknet marketplaces. Check timing vs the "
                    "incident window."),
                description="Browser history .onion references.",
                evidence={"sample_urls": samples,
                           "total_unique": len(onion)},
                tags=["T1090.003", "darknet"]))

    # -- DNS cache hints ------------------------------------------

    def _check_dns_leak_hints(self):
        dns = self.net.get("dns_cache") or []
        leak_hits: List[Dict[str, Any]] = []
        for r in dns:
            name = (r.get("Record Name") or "").lower()
            if any(h in name for h in self.LEAK_SITE_HINTS):
                leak_hits.append(r)
        if leak_hits:
            self.findings.append(Finding(
                source="darknet",
                category="darknet.leaksite_dns",
                title=f"DNS cache hits for leak-site indicators "
                      f"({len(leak_hits)})",
                severity=SEV_HIGH,
                conclusion=(
                    "DNS resolver cache shows queries for hostnames "
                    "associated with ransomware leak-site monitoring "
                    "or public leak research mirrors. An endpoint "
                    "looking these up outside of a research context "
                    "is worth triage."),
                description="ipconfig /displaydns leak-site "
                            "hostname matches.",
                evidence={"records": leak_hits[:20]},
                tags=["darknet", "T1596"]))

    # -- Stealer drop filenames --------------------------------

    # Exclude paths that are clearly libraries / package installs /
    # Python history / browser profile bits — these produce
    # false positives for single-file matches.
    _STEALER_PATH_BLACKLIST = (
        "\\node_modules\\", "\\site-packages\\",
        "\\vendor\\", "\\zxcvbn", "\\dictionaries\\",
        "\\idlelib\\", "\\pylint\\", "\\pypi",
        "\\wordlist", "\\passwordslist", "\\resources\\",
        "\\extensions\\", "\\cpython-", "\\python3",
        "\\microsoft\\", "\\google\\chrome",
        "\\files.com\\",
    )
    # Stealer-drop trigger needs >= this many canonical files in
    # the SAME directory to raise a finding. Real Vidar/Raccoon
    # drops always write 4-8 of these together.
    _STEALER_CLUSTER_MIN = 3

    def _check_stealer_drops(self):
        search_roots: List[Path] = []
        try:
            users_iter = list(Path(r"C:\Users").glob("*"))
        except (OSError, PermissionError):
            users_iter = []
        for user in users_iter:
            try:
                if not user.is_dir():
                    continue
            except (OSError, PermissionError):
                continue
            for sub in ("Downloads", "Desktop",
                        r"AppData\Local\Temp",
                        r"AppData\Roaming"):
                p = user / sub
                if _safe_exists(p):
                    search_roots.append(p)
        pd = Path(os.environ.get("ProgramData") or r"C:\ProgramData")
        if _safe_exists(pd):
            search_roots.append(pd)

        # Group matches by parent directory so we can demand a
        # cluster of canonical files (the hallmark of a real
        # stealer dump).
        by_dir: Dict[str, List[Dict[str, Any]]] = {}
        for root in search_roots:
            for name in self.STEALER_FILES:
                try:
                    rg = root.rglob(name)
                except (OSError, PermissionError):
                    continue
                for hit in rg:
                    low = str(hit).lower()
                    if any(b in low
                           for b in self._STEALER_PATH_BLACKLIST):
                        continue
                    try:
                        stat = hit.stat()
                    except (OSError, PermissionError):
                        continue
                    entry = {
                        "path": str(hit),
                        "filename": hit.name,
                        "size": stat.st_size,
                        "mtime": dt.datetime.fromtimestamp(
                            stat.st_mtime,
                            tz=dt.timezone.utc).isoformat(),
                    }
                    by_dir.setdefault(
                        str(hit.parent), []).append(entry)

        cluster_hits: List[Dict[str, Any]] = []
        for dirpath, files in by_dir.items():
            unique_names = {f["filename"].lower() for f in files}
            if len(unique_names) >= self._STEALER_CLUSTER_MIN:
                cluster_hits.append({
                    "dir": dirpath,
                    "count": len(files),
                    "files": files[:10],
                })
        if cluster_hits:
            total = sum(c["count"] for c in cluster_hits)
            self.findings.append(Finding(
                source="darknet",
                category="darknet.stealer_drop",
                title=(f"Stealer-family drop cluster(s) detected "
                       f"({len(cluster_hits)} directory, "
                       f"{total} file{'s' if total != 1 else ''})"),
                severity=SEV_CRIT,
                conclusion=(
                    f"Found {len(cluster_hits)} directory containing "
                    f"{self._STEALER_CLUSTER_MIN}+ canonical "
                    "stealer-output filenames (passwords.txt, "
                    "wallets.txt, cookies.txt, autofills.txt, ...) "
                    "clustered together — the defining fingerprint "
                    "of Vidar/Raccoon/RedLine/MetaStealer dump "
                    "directories. The credentials/wallets/cookies "
                    "inside should be considered harvested."),
                description="Multi-file stealer dump cluster.",
                evidence={"clusters": cluster_hits[:10]},
                tags=["T1005", "T1555", "exfiltration"]))

    # -- Archive staging for exfil -----------------------------

    def _check_archive_staging(self):
        roots: List[Path] = []
        try:
            users_iter = Path(r"C:\Users").glob("*")
        except (OSError, PermissionError):
            users_iter = iter([])
        for user in users_iter:
            try:
                if not user.is_dir():
                    continue
            except (OSError, PermissionError):
                continue
            for sub in ("Downloads", "Desktop", "Documents"):
                p = user / sub
                if _safe_exists(p):
                    roots.append(p)
        suspicious_name_tokens = (
            "dump", "data", "exfil", "leak", "passwords",
            "wallets", "cookies", "archive", "docs", "harvest",
            "clientinfo", "confidential", "secret",
        )
        candidates: List[Dict[str, Any]] = []
        cutoff = _now_utc() - dt.timedelta(days=60)
        for root in roots:
            try:
                for ext in ("*.zip", "*.rar", "*.7z"):
                    try:
                        arcs = list(root.glob(ext))
                    except (OSError, PermissionError):
                        arcs = []
                    for arc in arcs:
                        try:
                            stat = arc.stat()
                        except (OSError, PermissionError):
                            continue
                        mtime = dt.datetime.fromtimestamp(
                            stat.st_mtime, tz=dt.timezone.utc)
                        if mtime < cutoff:
                            continue
                        if stat.st_size < 1 * 1024 * 1024:
                            continue
                        low = arc.name.lower()
                        name_match = any(
                            tok in low for tok in
                            suspicious_name_tokens)
                        encrypted = self._archive_is_encrypted(arc)
                        if not (name_match or encrypted):
                            continue
                        candidates.append({
                            "path": str(arc),
                            "size_mb": round(
                                stat.st_size / 1024 / 1024, 1),
                            "mtime": mtime.isoformat(),
                            "encrypted": encrypted,
                            "name_match": name_match,
                        })
            except (OSError, PermissionError):
                continue
        if candidates:
            enc = [c for c in candidates if c["encrypted"]]
            sev = SEV_HIGH if enc else SEV_MED
            self.findings.append(Finding(
                source="darknet",
                category="darknet.archive_staging",
                title=f"Archive staging candidates "
                      f"({len(candidates)})",
                severity=sev,
                conclusion=(
                    f"{len(candidates)} archive file(s) created in "
                    "the last 60 days on Downloads / Desktop / "
                    "Documents match exfil-staging heuristics — "
                    f"{len(enc)} of them are encrypted (7-Zip / RAR "
                    "with password) and/or have filenames suggestive "
                    "of data packaging. Cross-reference with SRUM "
                    "network activity around the archive's mtime to "
                    "confirm whether the file left the host."),
                description="Recent large archives with exfil-shaped "
                            "filenames or encryption flag.",
                evidence={"candidates": candidates[:20]},
                tags=["T1560", "T1074", "staging"]))

    @staticmethod
    def _archive_is_encrypted(path: Path) -> bool:
        try:
            with open(path, "rb") as fh:
                head = fh.read(512)
        except (OSError, PermissionError):
            return False
        # ZIP: check general-purpose bit-flag of first local header
        if head[:4] == b"PK\x03\x04" and len(head) >= 8:
            gp = struct.unpack_from("<H", head, 6)[0]
            if gp & 0x0001:
                return True
        # RAR 4.x: HEAD_FLAGS bit 0x0004 in main header = pwd
        if head[:4] == b"Rar!":
            return b"\x04\x00" in head[:40]
        # RAR 5.x: look for "Encrypted:" header
        if head[:7] == b"Rar!\x1A\x07\x01":
            return True
        # 7z: look for the Encoded header indicator
        if head[:6] == b"7z\xBC\xAF\x27\x1C":
            # Heuristic: presence of AES-256 OID (0x06 0x F1 0x07 0x01)
            return b"\x06\xF1\x07\x01" in head
        return False

    # -- Credential-dumping tool binaries ----------------------

    def _check_credential_tools(self):
        try:
            import psutil
        except ImportError:
            return
        hits: List[Dict[str, Any]] = []
        for p in psutil.process_iter(attrs=["pid", "name", "exe"]):
            try:
                name = (p.info.get("name") or "").lower()
                if name in self.CRED_TOOLS:
                    hits.append(p.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        # Disk presence via Prefetch
        pf = Path(r"C:\Windows\Prefetch")
        disk_hits: List[str] = []
        if pf.exists():
            for tool in self.CRED_TOOLS:
                stem = tool.replace(".exe", "").upper()
                try:
                    for pfile in pf.glob(f"{stem}-*.pf"):
                        disk_hits.append(str(pfile))
                except OSError:
                    continue
        if hits or disk_hits:
            self.findings.append(Finding(
                source="darknet",
                category="credential.extraction_tool",
                title=("Credential-extraction tool(s) detected "
                       f"({len(hits) + len(disk_hits)})"),
                severity=SEV_CRIT,
                conclusion=(
                    "Known credential-recovery / -dumping binaries "
                    "are present on this host (live processes "
                    "and/or Prefetch evidence of prior execution). "
                    "Unless explicitly authorized, the creds cached "
                    "on this host (DPAPI, browser, Wi-Fi, saved "
                    "RDP, domain MSCache, LSASS) should be "
                    "considered harvested."),
                description="LaZagne / Nirsoft / Mimikatz family "
                            "binary detected.",
                evidence={"live": hits, "prefetch": disk_hits[:10]},
                tags=["T1003", "T1555", "credential-access"]))


# ---------------------------------------------------------------------------
# PE Integrity analyzer — catches kernel-level / bootkit tampering of
# critical system binaries by verifying Authenticode + signer against
# a whitelist of Microsoft / hardware-vendor roots.
# ---------------------------------------------------------------------------

class PEIntegrityAnalyzer:
    """
    Verify the digital-signature integrity of critical Windows
    system binaries. Any binary that fails Authenticode verification,
    is signed by a non-Microsoft signer, or has a recent mtime
    suggesting on-disk tampering — is elevated to CRITICAL.

    This is the single highest-signal check for BYOVD / bootkit /
    rootkit-level compromise that replaces legitimate OS binaries
    on disk.
    """

    # ~40 system binaries whose tampering = confirmed compromise
    CRITICAL_BINARIES = [
        # LSA / logon / audit
        r"C:\Windows\System32\lsass.exe",
        r"C:\Windows\System32\winlogon.exe",
        r"C:\Windows\System32\wininit.exe",
        r"C:\Windows\System32\services.exe",
        r"C:\Windows\System32\csrss.exe",
        r"C:\Windows\System32\smss.exe",
        r"C:\Windows\System32\lsass.exe",
        # Core runtime
        r"C:\Windows\System32\ntdll.dll",
        r"C:\Windows\System32\kernel32.dll",
        r"C:\Windows\System32\kernelbase.dll",
        r"C:\Windows\System32\user32.dll",
        r"C:\Windows\System32\advapi32.dll",
        r"C:\Windows\System32\combase.dll",
        r"C:\Windows\System32\rpcrt4.dll",
        # Svchost + scheduled tasks + WMI
        r"C:\Windows\System32\svchost.exe",
        r"C:\Windows\System32\schtasks.exe",
        r"C:\Windows\System32\taskeng.exe",
        r"C:\Windows\System32\wbem\WmiPrvSE.exe",
        r"C:\Windows\System32\wbem\WMIC.exe",
        # Remote / network
        r"C:\Windows\System32\svchost.exe",
        r"C:\Windows\System32\netsh.exe",
        r"C:\Windows\System32\net.exe",
        r"C:\Windows\System32\net1.exe",
        # Logon / session
        r"C:\Windows\System32\userinit.exe",
        r"C:\Windows\explorer.exe",
        r"C:\Windows\System32\taskmgr.exe",
        r"C:\Windows\System32\spoolsv.exe",
        # Defender
        r"C:\Program Files\Windows Defender\MsMpEng.exe",
        # AMSI provider
        r"C:\Windows\System32\amsi.dll",
        # Auth / Kerberos
        r"C:\Windows\System32\kerberos.dll",
        r"C:\Windows\System32\msv1_0.dll",
        r"C:\Windows\System32\sspicli.dll",
        r"C:\Windows\System32\cryptsp.dll",
        r"C:\Windows\System32\secur32.dll",
        # LOLBins we want to track for tampering
        r"C:\Windows\System32\regsvr32.exe",
        r"C:\Windows\System32\rundll32.exe",
        r"C:\Windows\System32\mshta.exe",
        r"C:\Windows\System32\certutil.exe",
        r"C:\Windows\System32\bitsadmin.exe",
        r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        # Sysmon / event log infra
        r"C:\Windows\System32\EventLog.exe",
    ]

    # Trusted signer substrings (case-insensitive). A binary whose
    # signer does NOT contain any of these is suspicious even if
    # "Valid".
    TRUSTED_SIGNERS = (
        "microsoft windows",
        "microsoft corporation",
        "microsoft root certificate",
        "microsoft time-stamp",
    )

    RECENT_DAYS = 30  # mtime within this window is worth a note

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.state: Dict[str, Any] = {"binaries": []}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        seen: Set[str] = set()
        checked = 0
        for path_str in self.CRITICAL_BINARIES:
            p = Path(path_str)
            key = str(p).lower()
            if key in seen:
                continue
            seen.add(key)
            if not _safe_exists(p):
                continue
            checked += 1
            info = self._inspect(p)
            self.state["binaries"].append(info)
            self._classify(info)
        self.logger.info(
            "PE integrity: %d binaries checked, %d findings",
            checked, len(self.findings))
        return self.state, self.findings

    def _inspect(self, path: Path) -> Dict[str, Any]:
        info: Dict[str, Any] = {"path": str(path)}
        try:
            stat = path.stat()
            info["size"] = stat.st_size
            info["mtime"] = dt.datetime.fromtimestamp(
                stat.st_mtime, tz=dt.timezone.utc).isoformat()
            info["age_days"] = (
                _now_utc() - dt.datetime.fromtimestamp(
                    stat.st_mtime, tz=dt.timezone.utc)).days
        except OSError as exc:
            info["error"] = f"stat failed: {exc}"
            return info
        # Hashes
        h = hash_file(path, ("sha256", "md5"))
        info["sha256"] = h.get("sha256")
        info["md5"] = h.get("md5")
        # Authenticode
        auth = verify_authenticode(path, self.logger)
        info["authenticode_status"] = auth.get("Status")
        info["authenticode_message"] = auth.get("StatusMessage")
        info["signer"] = auth.get("SignerName")
        info["issuer"] = auth.get("Issuer")
        return info

    def _classify(self, info: Dict[str, Any]) -> None:
        path = info.get("path", "?")
        status = (info.get("authenticode_status") or "").lower()
        signer = (info.get("signer") or "").lower()
        age = info.get("age_days")

        # 1. Not Valid — strongest indicator of tampering
        if status and status != "valid":
            sev = SEV_CRIT if status in (
                "hashmismatch", "unknownerror", "notsigned") \
                else SEV_HIGH
            self.findings.append(Finding(
                source="peintegrity",
                category="integrity.pe_tamper",
                title=(f"PE integrity failure: {Path(path).name} "
                       f"({info.get('authenticode_status')})"),
                severity=sev,
                conclusion=(
                    f"Critical system binary '{path}' failed "
                    f"Authenticode verification with status "
                    f"'{info.get('authenticode_status')}' "
                    f"({info.get('authenticode_message','')}). "
                    "System binaries are signed by Microsoft and "
                    "verified on every boot. A failed verification "
                    "means the file on disk has been altered — "
                    "classic fingerprint of a rootkit / bootkit / "
                    "BYOVD campaign or of a supply-chain "
                    "compromise. Do NOT trust the rest of this host "
                    "until the binary is replaced from known-good "
                    "media."),
                description="Authenticode status != Valid on "
                            "critical system binary.",
                evidence=info,
                tags=["T1601", "integrity", "bootkit-suspected"]))
            return

        # 2. Signed but by a non-Microsoft entity
        if signer and not any(t in signer
                                for t in self.TRUSTED_SIGNERS):
            self.findings.append(Finding(
                source="peintegrity",
                category="integrity.pe_wrong_signer",
                title=(f"System binary signed by non-Microsoft "
                       f"signer: {Path(path).name}"),
                severity=SEV_CRIT,
                conclusion=(
                    f"Critical system binary '{path}' is "
                    "Authenticode-valid but signed by "
                    f"'{info.get('signer')}', which is not on the "
                    "Microsoft-trusted signer list. The file has "
                    "been replaced with a different (attacker-"
                    "signed) binary that happens to be valid — "
                    "sophisticated supply-chain or "
                    "signed-malware operation."),
                description="Valid signature but wrong signer.",
                evidence=info,
                tags=["T1601", "T1553.002", "signed-malware"]))
            return

        # 3. Recent-mtime check: dropped — Windows Update legitimately
        # touches most of these every Patch Tuesday, producing a
        # wave of FPs. Only signer-mismatch / Authenticode-failure
        # survive as real integrity findings.


# ---------------------------------------------------------------------------
# Live-process memory scanner — runs bundled YARA against every
# accessible user-mode process's private memory, WITHOUT needing a
# memory dump. Catches Mimikatz / Cobalt Strike / Meterpreter running
# RIGHT NOW.
# ---------------------------------------------------------------------------

class LiveProcessYaraAnalyzer:
    """
    Opens each accessible user-mode process and scans its committed,
    readable memory regions with the bundled YARA ruleset + signature
    strings. Produces findings referencing the exact process (name,
    PID, memory region address) where the malicious content lives.

    Limitations (by design, for safety):
      * Skips System / protected processes (no PROCESS_VM_READ)
      * Caps total scan time at ~60s, per-process at 5s
      * Skips regions > 200MB (avoids runaway on big apps)
      * Only scans MEM_COMMIT + readable regions
    """

    MAX_TOTAL_SECONDS = 60
    MAX_PROC_SECONDS = 5
    MAX_REGION_BYTES = 200 * 1024 * 1024

    # Win32 constants
    PROCESS_VM_READ = 0x0010
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    MEM_COMMIT = 0x1000
    PAGE_READABLE = (0x02 | 0x04 | 0x10 | 0x20 | 0x40 | 0x80)

    # Known-benign process names to skip (too large / too noisy /
    # legitimately carry offensive-tool strings in rulesets /
    # threat-intel caches).
    SKIP_PROCS = {
        # Browsers (huge private memory, noisy)
        "msedge.exe", "chrome.exe", "firefox.exe",
        "msedgewebview2.exe", "brave.exe", "opera.exe",
        # Cloud / collaboration
        "onedrive.exe", "teams.exe", "slack.exe",
        "whatsapp.exe", "whatsapp.root.exe", "spotify.exe",
        "dropbox.exe", "zoom.exe",
        # IDEs / dev tools — frequently hold YARA / IOC strings
        "code.exe", "devenv.exe", "studio64.exe",
        "idea64.exe", "pycharm64.exe", "webstorm64.exe",
        "cursor.exe", "notepad++.exe", "sublime_text.exe",
        # Our own tooling / analysis processes
        "python.exe", "pythonw.exe", "py.exe", "pwsh.exe",
        "powershell.exe", "powershell_ise.exe",
        "conhost.exe", "cmd.exe",
        # Security / AV — analyze malware by design
        "msmpeng.exe", "mpdefendercoreservice.exe",
        "securityhealthservice.exe", "nissrv.exe",
        "smartscreen.exe", "mssense.exe",
        "sentinelagent.exe", "cylancesvc.exe",
        "hitmanpro.alert.exe", "hitmanpro.exe",
        "mbam.exe", "mbamservice.exe", "esetservice.exe",
        "avastsvc.exe", "avgsvc.exe", "sophossps.exe",
        "crowdstrike-falcon.exe", "csagent.exe",
        "elastic-agent.exe", "wazuh-agent.exe",
        "osqueryd.exe", "sysmon.exe", "sysmon64.exe",
        # Windows shell / UWP
        "explorer.exe", "shellexperiencehost.exe",
        "searchapp.exe", "searchindexer.exe",
        "startmenuexperiencehost.exe",
        "applicationframehost.exe", "runtimebroker.exe",
        "sihost.exe", "ctfmon.exe", "taskhostw.exe",
    }

    def __init__(self, logger: logging.Logger,
                 extra_yara: Optional[List[Path]] = None):
        self.logger = logger
        self.extra_yara = extra_yara or []
        self.findings: List[Finding] = []
        self.state: Dict[str, Any] = {
            "scanned": 0, "skipped": 0,
            "access_denied": 0, "matches": 0}

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        try:
            import ctypes
            from ctypes import wintypes
            import psutil
        except ImportError:
            return self.state, self.findings
        rules = _compile_yara_rules(self.extra_yara)
        if not rules:
            self.logger.info(
                "Live YARA: no YARA rules compiled — skipping")
            return self.state, self.findings

        # Local class for VirtualQueryEx output
        class MBI(ctypes.Structure):
            _fields_ = [
                ("BaseAddress", ctypes.c_void_p),
                ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wintypes.DWORD),
                ("PartitionId", wintypes.WORD),
                ("RegionSize", ctypes.c_size_t),
                ("State", wintypes.DWORD),
                ("Protect", wintypes.DWORD),
                ("Type", wintypes.DWORD),
            ]

        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.OpenProcess.argtypes = [
            wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.VirtualQueryEx.restype = ctypes.c_size_t
        kernel32.VirtualQueryEx.argtypes = [
            wintypes.HANDLE, ctypes.c_void_p,
            ctypes.POINTER(MBI), ctypes.c_size_t]
        kernel32.ReadProcessMemory.restype = wintypes.BOOL
        kernel32.ReadProcessMemory.argtypes = [
            wintypes.HANDLE, ctypes.c_void_p,
            ctypes.c_void_p, ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_size_t)]
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

        start = time.time()
        for p in psutil.process_iter(
                attrs=["pid", "name", "exe", "username"]):
            if time.time() - start > self.MAX_TOTAL_SECONDS:
                self.logger.info(
                    "Live YARA: total time budget exhausted")
                break
            try:
                info = p.info
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            pid = info.get("pid")
            name = (info.get("name") or "").lower()
            if not pid or pid < 4 or name in self.SKIP_PROCS:
                self.state["skipped"] += 1
                continue
            # Skip our own process
            if pid == os.getpid():
                continue
            matches = self._scan_one(
                pid, info, kernel32, MBI, rules)
            if matches:
                self._emit_finding(info, matches)
        self.logger.info(
            "Live YARA: scanned=%d skipped=%d access_denied=%d "
            "matches=%d",
            self.state["scanned"], self.state["skipped"],
            self.state["access_denied"], self.state["matches"])
        return self.state, self.findings

    def _scan_one(self, pid: int, info: Dict[str, Any],
                   kernel32, MBI, rules
                   ) -> List[Dict[str, Any]]:
        import ctypes
        h = kernel32.OpenProcess(
            self.PROCESS_VM_READ
            | self.PROCESS_QUERY_LIMITED_INFORMATION,
            False, pid)
        if not h:
            self.state["access_denied"] += 1
            return []
        matches: List[Dict[str, Any]] = []
        start_p = time.time()
        try:
            self.state["scanned"] += 1
            addr = 0
            mbi = MBI()
            while time.time() - start_p < self.MAX_PROC_SECONDS:
                got = kernel32.VirtualQueryEx(
                    h, ctypes.c_void_p(addr),
                    ctypes.byref(mbi), ctypes.sizeof(mbi))
                if not got:
                    break
                region_size = int(mbi.RegionSize)
                base = int(mbi.BaseAddress or 0)
                if region_size == 0:
                    break
                # Committed + readable + not too big
                if (mbi.State == self.MEM_COMMIT and
                        (mbi.Protect & self.PAGE_READABLE) and
                        region_size <= self.MAX_REGION_BYTES):
                    buf = (ctypes.c_char * region_size)()
                    read = ctypes.c_size_t()
                    if kernel32.ReadProcessMemory(
                            h, ctypes.c_void_p(base), buf,
                            region_size, ctypes.byref(read)):
                        data = buf.raw[:read.value]
                        try:
                            yara_hits = rules.match(data=data)
                        except Exception:
                            yara_hits = []
                        for m in yara_hits:
                            matches.append({
                                "address_hex": f"0x{base:x}",
                                "region_size": region_size,
                                "rule": m.rule,
                                "strings": [
                                    getattr(s, "identifier", "?")
                                    for s in (getattr(m, "strings",
                                                      []) or [])
                                ][:6],
                            })
                addr = base + region_size
                if addr > 0x7FFFFFFFFFFF:
                    break
        finally:
            kernel32.CloseHandle(h)
        if matches:
            self.state["matches"] += len(matches)
        return matches

    # Substrings in process exe paths that mean "this is a
    # security / AV / EDR / research tool that legitimately
    # carries attack-string detections in its memory".
    _SECURITY_PATH_MARKERS = (
        # Defender + Microsoft security services
        "\\windows defender\\",
        "\\windows defender advanced threat protection\\",
        "\\microsoft\\mpdefender\\",
        "\\program files\\microsoft defender",
        "\\program files (x86)\\microsoft defender",
        # EDR / AV vendors
        "\\crowdstrike\\", "\\sentinelone\\", "\\cylance\\",
        "\\sophos\\", "\\symantec\\", "\\mcafee\\",
        "\\kaspersky\\", "\\bitdefender\\", "\\eset\\",
        "\\malwarebytes\\", "\\hitmanpro\\",
        "\\carbonblack\\", "\\trendmicro\\",
        "\\wazuh\\", "\\osquery\\", "\\sysmon\\",
        "\\elastic-agent\\", "\\falcon\\",
        # Remote-access + management
        "\\screenconnect client",
        "\\teamviewer\\", "\\anydesk\\", "\\rustdesk\\",
        "\\splashtop\\", "\\logmein\\", "\\atera\\",
        "\\connectwise\\", "\\ninjaone\\",
        # Windows Store apps (many trigger YARA via containers)
        "\\windowsapps\\microsoft.",
        "\\windowsapps\\microsoftwindows.",
        "\\windowsapps\\microsoftcorporationii.",
        # Dev tools
        "\\program files\\nodejs\\",
        "\\anaconda\\", "\\python3", "\\python\\",
        "\\.vscode\\", "\\.vscode-server\\",
        "\\code.exe",
        # Background hosts / brokers (legitimate WinRT)
        "\\system32\\backgroundtaskhost.exe",
        "\\system32\\runtimebroker.exe",
        "\\system32\\applicationframehost.exe",
    )

    def _is_security_process(self, info: Dict[str, Any]) -> bool:
        exe = (info.get("exe") or "").lower()
        if not exe:
            return False
        return any(m in exe for m in self._SECURITY_PATH_MARKERS)

    def _emit_finding(self, info: Dict[str, Any],
                       matches: List[Dict[str, Any]]) -> None:
        rules = sorted({m["rule"] for m in matches})
        # FP guard: security / AV / EDR / research tool memory
        # legitimately contains the strings our YARA rules hunt
        # for (Defender carries Mimikatz detection signatures,
        # CrowdStrike holds CS beacon patterns, etc.).
        # Downgrade those dramatically.
        if self._is_security_process(info):
            self.findings.append(Finding(
                source="live_yara",
                category="memory.live_yara_security_tool",
                title=(f"YARA match in security/AV/EDR process "
                       f"(likely benign): '{info.get('name')}'"),
                severity=SEV_INFO,
                conclusion=(
                    f"Process '{info.get('name')}' "
                    f"(exe={info.get('exe')}) contains YARA "
                    f"matches ({', '.join(rules)}) in its "
                    "memory. This is a known security / AV / EDR "
                    "tool — the matches are almost certainly "
                    "detection signatures the tool loads by "
                    "design, not active malware. Filed at "
                    "informational level for transparency."),
                description="Live YARA match in security-tool "
                            "process — auto-downgraded.",
                evidence={
                    "pid": info.get("pid"),
                    "name": info.get("name"),
                    "exe": info.get("exe"),
                    "rules_matched": rules,
                    "region_count": len(matches),
                },
                tags=["likely-benign", "security-tool"]))
            return

        self.findings.append(Finding(
            source="live_yara",
            category="memory.live_yara_match",
            title=(f"Live-memory YARA match in "
                   f"'{info.get('name')}' (PID {info.get('pid')})"),
            severity=SEV_CRIT,
            conclusion=(
                f"Running process '{info.get('name')}' "
                f"(PID {info.get('pid')}, exe={info.get('exe')}) "
                f"has memory regions that match the YARA rule(s): "
                f"{', '.join(rules)}. This is the highest-"
                "confidence runtime detection the analyzer "
                "produces — the offensive family is resident in "
                "the process RIGHT NOW. Preserve the process "
                "memory (procdump -ma <pid>) before killing or "
                "rebooting."),
            description="YARA hit in live process memory via "
                        "ReadProcessMemory.",
            evidence={
                "pid": info.get("pid"),
                "name": info.get("name"),
                "exe": info.get("exe"),
                "username": info.get("username"),
                "rules_matched": rules,
                "regions": matches[:10],
            },
            tags=["T1055", "live-memory", "yara-match",
                  "preserve-before-kill"]))


# ---------------------------------------------------------------------------
# USN Journal — best-effort parsing via fsutil. Records every file
# create / delete / rename on the volume in the last few weeks, even
# after the files are gone.
# ---------------------------------------------------------------------------

class USNJournalAnalyzer:
    """
    Wraps `fsutil usn readjournal C:` (requires admin) with strict
    size + time caps. Records are parsed into a structured list;
    high-signal patterns (Downloads/Desktop creates of .exe/.dll/
    .ps1/.hta/.lnk, deletions of recently-created executables,
    renames .txt->.exe) are promoted to findings.
    """

    READ_TIMEOUT = 120       # seconds
    MAX_BYTES = 30 * 1024 * 1024
    MAX_RECORDS = 150_000

    # File extensions that indicate actionable events when
    # created/deleted/renamed
    ACTIONABLE_EXT = (".exe", ".dll", ".sys", ".ps1", ".vbs",
                       ".js", ".jse", ".hta", ".lnk", ".bat",
                       ".cmd", ".wsf", ".msi")

    # Paths we care about — attacker-staging candidates
    WATCH_PATH_FRAGMENTS = (
        "\\downloads\\", "\\desktop\\",
        "\\appdata\\local\\temp\\", "\\appdata\\roaming\\",
        "\\public\\", "\\programdata\\", "\\windows\\temp\\",
        "\\perflogs\\",
    )

    REASON_FLAGS = {
        0x00000001: "DATA_OVERWRITE",
        0x00000002: "DATA_EXTEND",
        0x00000004: "DATA_TRUNCATION",
        0x00000100: "FILE_CREATE",
        0x00000200: "FILE_DELETE",
        0x00001000: "RENAME_OLD_NAME",
        0x00002000: "RENAME_NEW_NAME",
        0x00008000: "BASIC_INFO_CHANGE",
    }

    def __init__(self, volume: str, workdir: Path,
                 logger: logging.Logger):
        self.volume = volume
        self.workdir = workdir
        self.logger = logger
        self.records: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []
        self.state: Dict[str, Any] = {
            "volume": volume,
            "available": False,
            "records_parsed": 0,
        }

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        fsutil = shutil.which("fsutil.exe") \
            or r"C:\Windows\System32\fsutil.exe"
        if not _safe_exists(Path(fsutil)):
            return self.state, self.findings

        # Check USN availability first (fast query)
        try:
            q = subprocess.run(
                [fsutil, "usn", "queryjournal", self.volume],
                capture_output=True, text=True, timeout=10,
                encoding="cp1252", errors="ignore")
        except (subprocess.TimeoutExpired, OSError):
            return self.state, self.findings
        if q.returncode != 0:
            if "5" in (q.stderr or "") or "denied" in \
                    (q.stderr or "").lower():
                self.logger.info(
                    "USN: access denied on %s (needs admin)",
                    self.volume)
            return self.state, self.findings
        self.state["available"] = True

        # Read journal with size cap
        raw_path = self.workdir / "usn-journal-raw.txt"
        try:
            proc = subprocess.Popen(
                [fsutil, "usn", "readjournal", self.volume,
                 "/minmajorversion", "2",
                 "/maxmajorversion", "2"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, encoding="cp1252", errors="ignore")
        except OSError as exc:
            self.logger.debug("USN readjournal start: %s", exc)
            return self.state, self.findings

        start = time.time()
        bytes_read = 0
        chunks: List[str] = []
        try:
            while True:
                if time.time() - start > self.READ_TIMEOUT:
                    break
                line = proc.stdout.readline()
                if not line:
                    break
                bytes_read += len(line)
                if bytes_read > self.MAX_BYTES:
                    break
                chunks.append(line)
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()

        text = "".join(chunks)
        self._parse(text)
        self.state["records_parsed"] = len(self.records)
        self.logger.info(
            "USN: %d records parsed, %d findings",
            len(self.records), len(self.findings))
        return self.state, self.findings

    def _parse(self, text: str) -> None:
        blocks = re.split(r"\*+\s*Record Number:\s*", text)
        for block in blocks[1:]:
            if len(self.records) >= self.MAX_RECORDS:
                break
            rec: Dict[str, Any] = {}
            for line in block.splitlines():
                m = re.match(r"^\s*([^:]+?):\s+(.+)$", line)
                if not m:
                    continue
                k = m.group(1).strip().lower()
                v = m.group(2).strip()
                if k == "file name":
                    rec["filename"] = v
                elif k == "reason":
                    rec["reason_raw"] = v
                    rec["reasons"] = self._decode_reason(v)
                elif k == "time stamp":
                    rec["timestamp"] = v
                elif k == "file attributes":
                    rec["attributes"] = v
            if rec.get("filename"):
                self.records.append(rec)
        self._analyze()

    def _decode_reason(self, raw: str) -> List[str]:
        # raw is usually "0x00000100: FILE_CREATE"
        # or "0x00000102: DATA_EXTEND | FILE_CREATE"
        out: List[str] = []
        m = re.search(r"0x([0-9a-fA-F]+)", raw)
        if m:
            mask = int(m.group(1), 16)
            for flag, label in self.REASON_FLAGS.items():
                if mask & flag:
                    out.append(label)
        return out

    def _analyze(self) -> None:
        # Group by filename to see lifecycle (created then deleted)
        lifecycle: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        for rec in self.records:
            fn = (rec.get("filename") or "").lower()
            if not fn:
                continue
            ext_match = any(fn.endswith(e)
                            for e in self.ACTIONABLE_EXT)
            if not ext_match:
                continue
            slot = lifecycle.setdefault(fn, {
                "created": [], "deleted": [], "renamed": []})
            reasons = rec.get("reasons") or []
            if "FILE_CREATE" in reasons:
                slot["created"].append(rec)
            if "FILE_DELETE" in reasons:
                slot["deleted"].append(rec)
            if ("RENAME_OLD_NAME" in reasons
                    or "RENAME_NEW_NAME" in reasons):
                slot["renamed"].append(rec)

        # Short-lived executables: created + deleted (dropper
        # signature)
        for fn, ev in lifecycle.items():
            if ev["created"] and ev["deleted"]:
                self.findings.append(Finding(
                    source="usn",
                    category="fs.shortlived_executable",
                    title=(f"Short-lived executable (created + "
                           f"deleted): {Path(fn).name}"),
                    severity=SEV_HIGH,
                    conclusion=(
                        f"USN journal records both creation AND "
                        f"deletion of '{fn}' within the journal "
                        f"window. A file whose entire lifecycle "
                        "is create-then-delete — especially when "
                        "it's an executable / script / shortcut — "
                        "is the canonical dropper footprint. The "
                        "file is GONE from disk; the USN record "
                        "is the only remaining evidence."),
                    description="USN FILE_CREATE + FILE_DELETE for "
                                "the same executable.",
                    evidence={
                        "filename": fn,
                        "create_count": len(ev["created"]),
                        "delete_count": len(ev["deleted"]),
                        "first_create": (ev["created"][0].get(
                            "timestamp")
                            if ev["created"] else None),
                        "last_delete": (ev["deleted"][-1].get(
                            "timestamp")
                            if ev["deleted"] else None),
                    },
                    tags=["T1070.004", "usn", "dropper-footprint"]))

        # Rename-to-executable (e.g., .txt -> .exe)
        rename_targets = [r for r in self.records
                          if "RENAME_NEW_NAME" in (r.get(
                              "reasons") or [])]
        for r in rename_targets:
            fn = (r.get("filename") or "").lower()
            if any(fn.endswith(ext) for ext in
                   (".exe", ".dll", ".scr")):
                self.findings.append(Finding(
                    source="usn",
                    category="fs.rename_to_executable",
                    title=(f"Rename-to-executable: "
                           f"{Path(fn).name}"),
                    severity=SEV_MED,
                    conclusion=(
                        f"USN records a rename that produced "
                        f"the executable '{fn}'. Renames "
                        "into .exe / .dll / .scr are the "
                        "classic maneuver used by malware to "
                        "sidestep MOTW / AV / user vigilance — "
                        "download as .txt / no extension, then "
                        "rename."),
                    description="USN RENAME_NEW_NAME ending in "
                                "executable extension.",
                    evidence=r,
                    tags=["T1036.008", "usn"]))

        # Creation of executables in attacker-staging paths
        for rec in self.records:
            fn = (rec.get("filename") or "").lower()
            # We don't have full path in USN records (USN stores
            # parent ref, not path). Skip path-based filter for
            # now.
            reasons = rec.get("reasons") or []
            if "FILE_CREATE" not in reasons:
                continue
            if not any(fn.endswith(e)
                       for e in (".hta", ".vbs", ".js",
                                  ".ps1", ".wsf", ".lnk")):
                continue
            self.findings.append(Finding(
                source="usn",
                category="fs.script_created",
                title=f"Script/shortcut created: {Path(fn).name}",
                severity=SEV_LOW,
                conclusion=(
                    f"USN records creation of script/shortcut "
                    f"'{fn}'. Scripts and .lnk files are the "
                    "primary phishing payload shape — cross-"
                    "reference with the browser-downloads "
                    "section for arrival vector."),
                description="USN FILE_CREATE of script-family "
                            "file.",
                evidence=rec,
                tags=["T1204.002", "usn"]))
            if len([f for f in self.findings
                    if f.category == "fs.script_created"]) > 20:
                break


# ---------------------------------------------------------------------------
# Network inventory (DNS cache, listening ports).
# ---------------------------------------------------------------------------

class NetworkInventoryAnalyzer:
    """
    Captures the host's live network posture:
      - listening TCP/UDP ports (what's exposed)
      - established connections (who is this talking to)
      - DNS resolver cache (where has it looked up recently)
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.listening: List[Dict[str, Any]] = []
        self.established: List[Dict[str, Any]] = []
        self.dns_cache: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        self._collect_sockets()
        if os.name == "nt":
            self._collect_dns_cache()
        self._analyze()
        self.logger.info(
            "Network: %d listeners, %d established, "
            "%d DNS cache entries, %d findings",
            len(self.listening), len(self.established),
            len(self.dns_cache), len(self.findings))
        return ({"listening": self.listening,
                 "established": self.established,
                 "dns_cache": self.dns_cache},
                self.findings)

    def _collect_sockets(self) -> None:
        try:
            import psutil
        except ImportError:
            return
        pid_names: Dict[int, str] = {}
        for p in psutil.process_iter(attrs=["pid", "name"]):
            try:
                pid_names[p.info["pid"]] = p.info["name"]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        try:
            for c in psutil.net_connections(kind="inet"):
                rec = {
                    "pid": c.pid,
                    "process": pid_names.get(c.pid, "?"),
                    "laddr": f"{c.laddr.ip}:{c.laddr.port}"
                             if c.laddr else None,
                    "raddr": f"{c.raddr.ip}:{c.raddr.port}"
                             if c.raddr else None,
                    "status": c.status,
                    "proto": "TCP"
                              if str(c.type).endswith("SOCK_STREAM")
                              else "UDP",
                }
                if c.status == "LISTEN" or (c.status is not None
                                             and not c.raddr):
                    self.listening.append(rec)
                elif c.status in ("ESTABLISHED",
                                    "SYN_SENT", "SYN_RECV"):
                    self.established.append(rec)
        except (psutil.AccessDenied, OSError):
            pass

    def _collect_dns_cache(self) -> None:
        try:
            result = subprocess.run(
                ["ipconfig", "/displaydns"],
                capture_output=True, text=True, timeout=20,
                encoding="cp1252", errors="ignore")
        except (subprocess.TimeoutExpired, OSError):
            return
        cur: Dict[str, Any] = {}
        for line in (result.stdout or "").splitlines():
            s = line.strip()
            if not s:
                if cur.get("Record Name"):
                    self.dns_cache.append(cur)
                cur = {}
                continue
            m = re.match(r"^([\w \(\)]+?)\s*\.{2,}\s*:\s*(.+)$", s)
            if m:
                cur[m.group(1).strip()] = m.group(2).strip()
        if cur.get("Record Name"):
            self.dns_cache.append(cur)

    # Common well-known exposed ports we don't want to alert on.
    _COMMON_LISTEN = {135, 139, 445, 3389, 5357, 5040, 5353, 5355,
                      49664, 49665, 49666, 49667, 49668, 49669, 49670,
                      49671, 49672, 49673, 49674, 49675, 49676, 49677}

    # Ports historically used by malware / C2 frameworks.
    _MALWARE_LISTEN_PORTS = {4444, 5555, 6666, 7777, 8888, 9999,
                              1337, 31337, 12345, 54321, 60000}

    def _analyze(self) -> None:
        # Don't flag every listener / connection as a finding — they
        # all appear in the Network Activity section. Only emit a
        # finding when the pattern is distinctly suspicious.
        for rec in self.listening:
            try:
                port = int((rec.get("laddr") or "").rsplit(":", 1)[-1])
            except (ValueError, IndexError):
                continue
            proc = (rec.get("process") or "").lower()
            if port in self._MALWARE_LISTEN_PORTS:
                self.findings.append(Finding(
                    source="network",
                    category="network.c2_port_listener",
                    title=f"Listener on known-malware port "
                          f"{port} by {proc}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Process '{proc}' (PID {rec.get('pid')}) is "
                        f"listening on {rec.get('laddr')}. Port "
                        f"{port} is historically associated with C2 "
                        "frameworks and RATs. Validate the binary "
                        "immediately."),
                    description="Listener on well-known attacker "
                                "port.",
                    evidence=rec,
                    tags=["network", "c2-candidate"]))
        # Established: flag only if destination is a raw public IP
        # (no hostname involved) that is not cloud, AND the owning
        # process is outside browsers / MS system procs.
        benign_procs = {
            "msedge.exe", "chrome.exe", "firefox.exe", "brave.exe",
            "opera.exe", "iexplore.exe",
            "msedgewebview2.exe", "slack.exe", "teams.exe",
            "onedrive.exe", "outlook.exe", "ms-teams.exe",
            "whatsapp.exe", "whatsapp.root.exe", "spotify.exe",
            "zoom.exe", "discord.exe",
            "svchost.exe", "backgroundtaskhost.exe",
            "searchapp.exe", "applicationframehost.exe",
            "smartscreen.exe",
        }
        seen: Set[Tuple[str, str]] = set()
        for rec in self.established:
            raddr = rec.get("raddr") or ""
            if not raddr:
                continue
            ip = raddr.rsplit(":", 1)[0]
            if not _is_external_ip(ip) or ip_is_benign_cloud(ip):
                continue
            proc = (rec.get("process") or "").lower()
            if proc in benign_procs:
                continue
            key = (proc, ip)
            if key in seen:
                continue
            seen.add(key)
            self.findings.append(Finding(
                source="network",
                category="network.external_established",
                title=f"{proc} -> {raddr} (external, non-cloud)",
                severity=SEV_LOW,
                conclusion=(
                    f"Process '{proc}' (PID {rec.get('pid')}) has an "
                    f"established connection to {raddr}. The host is "
                    "external, not in the cloud-CDN allowlist, and "
                    "the process is not a browser / MS-system one. "
                    "Verify the destination against the application "
                    "owner."),
                description="Outbound established to unrecognized IP.",
                evidence=rec,
                tags=["network", "c2-candidate"]))


# ---------------------------------------------------------------------------
# Memory analysis (Volatility3 backend).
# ---------------------------------------------------------------------------

class MemoryAnalyzer:
    PLUGINS = [
        "windows.info.Info",
        "windows.pslist.PsList",
        "windows.psscan.PsScan",
        "windows.pstree.PsTree",
        "windows.malfind.Malfind",
        "windows.netscan.NetScan",
        "windows.cmdline.CmdLine",
        "windows.ssdt.SSDT",
        "windows.driverscan.DriverScan",
        "windows.handles.Handles",
        "windows.hollowprocesses.HollowProcesses",
        "windows.svcscan.SvcScan",
        "windows.registry.hivelist.HiveList",
    ]

    def __init__(self, image_path: Path, workdir: Path,
                 logger: logging.Logger):
        self.image_path = image_path
        self.workdir = workdir
        self.logger = logger
        self.dump_dir = workdir / "memdumps"
        self.dump_dir.mkdir(parents=True, exist_ok=True)
        self.results: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if not self.image_path.exists():
            return self.results, self.findings
        self.logger.info("Memory image: %s (%.2f MB)",
                         self.image_path,
                         self.image_path.stat().st_size / 1024 / 1024)
        for plugin in self.PLUGINS:
            try:
                t0 = time.time()
                rows = self._run_plugin(plugin)
                self.results[plugin] = rows
                self.logger.info("  %-40s rows=%-5d (%.1fs)",
                                 plugin, len(rows), time.time() - t0)
            except Exception as exc:
                self.logger.warning("  %s failed: %s", plugin, exc)
                self.results[plugin] = []
        self._analyze()
        return self.results, self.findings

    def _run_plugin(self, name: str) -> List[Dict[str, Any]]:
        rows = self._run_library(name)
        if rows is not None:
            return rows
        return self._run_cli(name)

    def _run_library(self, name: str) -> Optional[List[Dict[str, Any]]]:
        try:
            from volatility3 import framework
            from volatility3.framework import contexts, automagic, plugins
            from volatility3.cli import PrintedProgress
            from volatility3.framework.renderers import format_hints
        except Exception:
            return None
        try:
            framework.require_interface_version(2, 0, 0)
            ctx = contexts.Context()
            framework.import_files(
                __import__("volatility3.plugins", fromlist=["*"]), True)
            plugin_cls = framework.list_plugins().get(name)
            if plugin_cls is None:
                return []
            available = automagic.available(ctx)
            ctx.config["automagic.LayerStacker.single_location"] = \
                self.image_path.as_uri()
            automagics = automagic.choose_automagic(available, plugin_cls)
            constructed = plugins.construct_plugin(
                ctx, automagics, plugin_cls, "plugins",
                PrintedProgress(), None)
            tree = constructed.run()

            flat: List[Dict[str, Any]] = []
            columns = [c.name for c in tree.columns]

            def _visit(node, _):
                values = []
                for i in range(len(columns)):
                    try:
                        v = node.values[i]
                    except Exception:
                        v = None
                    if isinstance(v, (format_hints.Hex,
                                      format_hints.HexBytes)):
                        v = str(v)
                    elif isinstance(v, bytes):
                        v = v.hex()
                    elif isinstance(v, dt.datetime):
                        v = v.isoformat()
                    values.append(v)
                flat.append(dict(zip(columns, values)))

            tree.populate(_visit, None)
            return flat
        except Exception as exc:
            self.logger.debug("library path failed for %s: %s", name, exc)
            return None

    def _run_cli(self, name: str) -> List[Dict[str, Any]]:
        exe = shutil.which("vol") or shutil.which("vol.py")
        args = [exe] if exe else [sys.executable, "-m", "volatility3"]
        cmd = args + ["-q", "-r", "json", "-f", str(self.image_path), name]
        try:
            out = subprocess.run(cmd, capture_output=True, text=True,
                                 timeout=60 * 20)
        except subprocess.TimeoutExpired:
            return []
        if out.returncode != 0:
            return []
        try:
            return json.loads(out.stdout or "[]")
        except json.JSONDecodeError:
            return []

    # Analysis -----------------------------------------------------

    def _analyze(self) -> None:
        self._detect_injection()
        self._detect_hidden_procs()
        self._detect_kernel_hooks()
        self._detect_dormant_sockets()
        self._detect_credential_access()
        self._carve_suspicious_buffers()

    def _detect_injection(self) -> None:
        rows = self.results.get("windows.malfind.Malfind", [])
        for row in rows:
            prot = str(row.get("Protection", ""))
            if "EXECUTE" not in prot or "WRITE" not in prot:
                continue
            proc = row.get("Process") or row.get("ImageFileName") or "?"
            pid = row.get("PID")
            hx = row.get("Hexdump") or ""
            has_mz = "4d 5a" in hx.lower()
            sev = SEV_CRIT if has_mz else SEV_HIGH

            conclusion = (
                f"Process '{proc}' (PID {pid}) contains code-injection. "
                f"The region is marked {prot} and "
                + ("begins with an MZ header — a full PE has been injected "
                   "into this process (Reflective DLL / shellcode stager)."
                   if has_mz else
                   "holds executable shellcode with no file backing "
                   "(classic process injection / Beacon memory).")
            )
            self.findings.append(Finding(
                source="memory", category="vad.injection",
                title=f"Code injection in {proc} (PID {pid})",
                severity=sev, conclusion=conclusion,
                description=(
                    "Private-committed memory marked executable+writable. "
                    "Signature of in-memory implants such as Cobalt Strike "
                    "Beacon, Meterpreter, or reflective loaders."),
                evidence={"process": proc, "pid": pid,
                          "protection": prot,
                          "hexdump": hx[:512]},
                tags=["T1055", "injection"],
            ))

    def _detect_hidden_procs(self) -> None:
        def _idx(rows):
            return {int(r["PID"]): r for r in rows
                    if r.get("PID") is not None}
        pslist = _idx(self.results.get("windows.pslist.PsList", []))
        psscan = _idx(self.results.get("windows.psscan.PsScan", []))
        hidden = set(psscan) - set(pslist)
        for pid in sorted(hidden):
            row = psscan[pid]
            name = row.get("ImageFileName") or "?"
            self.findings.append(Finding(
                source="memory", category="rootkit.hidden_process",
                title=f"Hidden process: {name} (PID {pid})",
                severity=SEV_CRIT,
                conclusion=(
                    f"Process '{name}' (PID {pid}) is hidden via DKOM. "
                    "The kernel's ActiveProcessLinks has been unlinked, "
                    "so Task Manager and most EDRs will not see it, but "
                    "pool-tag scanning recovered the _EPROCESS block."),
                description=(
                    "Direct Kernel Object Manipulation rootkit technique. "
                    "User-mode and kernel-mode implants both use this to "
                    "disappear from process enumeration."),
                evidence={"pid": pid, "name": name, "record": row},
                tags=["T1014", "DKOM", "rootkit"],
            ))

    def _detect_kernel_hooks(self) -> None:
        known_good = {"ntoskrnl.exe", "ntkrnlmp.exe",
                      "ntkrnlpa.exe", "win32k.sys",
                      "win32kbase.sys", "win32kfull.sys"}
        for row in self.results.get("windows.ssdt.SSDT", []):
            module = (row.get("Module") or "").lower()
            if not module:
                continue
            if Path(module).name.lower() in known_good:
                continue
            self.findings.append(Finding(
                source="memory", category="rootkit.ssdt_hook",
                title=f"SSDT hook -> {module}",
                severity=SEV_CRIT,
                conclusion=(
                    f"Kernel SSDT entry points into '{module}'. Syscall "
                    "interception by a non-Microsoft kernel module is "
                    "active on this system."),
                description=(
                    "A System Service Descriptor Table entry was modified "
                    "to redirect a syscall through a foreign driver — "
                    "classic kernel rootkit."),
                evidence={"module": module, "record": row},
                tags=["T1014", "kernel-hook"],
            ))
        for row in self.results.get("windows.driverscan.DriverScan", []):
            path = (row.get("Path") or "").lower()
            if not path:
                continue
            if path.startswith(("\\systemroot", "\\??\\c:\\windows",
                                r"c:\windows")):
                continue
            self.findings.append(Finding(
                source="memory", category="rootkit.driver",
                title=f"Driver loaded from non-standard path: {path}",
                severity=SEV_HIGH,
                conclusion=(
                    f"Kernel driver loaded from '{path}' (outside "
                    "System32). This is anomalous and warrants immediate "
                    "triage of the driver binary."),
                description=(
                    "Legitimate drivers live under \\SystemRoot\\System32. "
                    "Drivers elsewhere are almost always BYOVD or "
                    "custom rootkits."),
                evidence={"path": path},
                tags=["T1014", "driver"],
            ))

    def _detect_dormant_sockets(self) -> None:
        seen: Set[Tuple] = set()
        for row in self.results.get("windows.netscan.NetScan", []):
            key = (row.get("LocalAddr"), row.get("LocalPort"),
                   row.get("ForeignAddr"), row.get("ForeignPort"),
                   row.get("PID"))
            if key in seen:
                continue
            seen.add(key)
            foreign = row.get("ForeignAddr") or ""
            if not self._is_suspicious_endpoint(foreign):
                continue
            owner = row.get("Owner") or row.get("ImageFileName") or "?"
            pid = row.get("PID")
            self.findings.append(Finding(
                source="memory", category="network.c2_artifact",
                title=f"Dormant external socket {foreign} from {owner}",
                severity=SEV_HIGH,
                conclusion=(
                    f"Socket to external host {foreign} was recovered "
                    f"from pool memory, owned by '{owner}' (PID {pid}). "
                    "The live OS no longer reports this connection, which "
                    "strongly suggests it was a past or dormant C2 "
                    "channel."),
                description=(
                    "NetScan walks pool-tags for past socket objects. "
                    "These frequently reveal C2 endpoints long after the "
                    "OS has closed them."),
                evidence={**row, "ForeignAddr": foreign},
                tags=["T1071", "c2"],
            ))

    @staticmethod
    def _is_suspicious_endpoint(host: str) -> bool:
        if not host or host in ("0.0.0.0", "::", "127.0.0.1",
                                "::1", "*"):
            return False
        private_prefixes = ["10."] + [f"172.{i}." for i in range(16, 32)] \
            + ["192.168."]
        if any(host.startswith(p) for p in private_prefixes):
            return False
        # Drop well-known cloud / CDN noise that is almost never C2
        # in practice (legitimate OS traffic to Microsoft, Google,
        # CDNs). Removes ~90% of benign outbound FPs.
        if ip_is_benign_cloud(host):
            return False
        return True

    def _detect_credential_access(self) -> None:
        lsass_pids = {
            int(r["PID"]) for r in
            self.results.get("windows.pslist.PsList", [])
            if (r.get("ImageFileName") or "").lower() in CREDENTIAL_TARGETS
            and r.get("PID") is not None
        }
        if not lsass_pids:
            return
        for row in self.results.get("windows.handles.Handles", []):
            if (row.get("Type") or "").lower() != "process":
                continue
            target = row.get("Name") or ""
            m = re.search(r"Pid:\s*(\d+)", target)
            if not m:
                continue
            tpid = int(m.group(1))
            if tpid not in lsass_pids:
                continue
            granted = str(row.get("GrantedAccess")
                          or row.get("Granted Access") or "").upper()
            if any(x in granted for x in ("VM_READ", "0X1010",
                                          "0X1410", "0X1438", "0X143A")):
                pid = row.get("PID")
                self.findings.append(Finding(
                    source="memory", category="credential.lsass_access",
                    title=f"Process PID {pid} reads lsass memory",
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Process PID {pid} holds an open handle to "
                        f"lsass.exe with VM_READ. Credential material is "
                        "being, or has been, read from LSASS. This is the "
                        "defining behavior of Mimikatz / procdump / "
                        "comsvcs.dll credential dumping."),
                    description=("VM_READ handle into LSASS from a "
                                 "non-system process."),
                    evidence={"handle": row,
                              "target_pids": list(lsass_pids)},
                    tags=["T1003.001", "credential-access"],
                ))

    def _carve_suspicious_buffers(self) -> None:
        rows = self.results.get("windows.malfind.Malfind", [])
        for i, row in enumerate(rows):
            hx = row.get("Hexdump") or ""
            if not hx:
                continue
            pid = row.get("PID") or "x"
            start = str(row.get("Start VPN") or row.get("Start")
                        or f"b{i}").replace("0x", "")
            blob = self._hex_to_bytes(hx)
            if not blob:
                continue
            out = self.dump_dir / f"malfind_pid{pid}_{start}.bin"
            try:
                out.write_bytes(blob)
            except OSError:
                continue
            try:
                import pefile
                pefile.PE(data=blob, fast_load=True)
                pe_valid = True
            except Exception:
                pe_valid = False
            if pe_valid:
                sha = hashlib.sha256(blob).hexdigest()
                self.findings.append(Finding(
                    source="memory", category="malware.carved_pe",
                    title=f"Carved PE from PID {pid}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"A valid PE was extracted from injected memory "
                        f"in PID {pid} and saved to '{out.name}' "
                        f"(sha256 {sha[:16]}...). This binary is ready "
                        "for static analysis / YARA / sandboxing."),
                    description=("Buffer passed pefile validation; "
                                 "standalone PE file reconstructed from "
                                 "injected memory region."),
                    evidence={"path": str(out),
                              "size": len(blob), "sha256": sha},
                    tags=["malware", "pe", "carving"],
                ))

    @staticmethod
    def _hex_to_bytes(hx: str) -> bytes:
        out = bytearray()
        for line in hx.splitlines():
            tokens = line.split()
            for t in tokens[1:]:
                if re.fullmatch(r"[0-9a-fA-F]{2}", t):
                    out.append(int(t, 16))
        return bytes(out)


# ---------------------------------------------------------------------------
# Crash-dump analyzer (MEMORY.DMP, Minidumps, WER, user CrashDumps).
# ---------------------------------------------------------------------------

STREAM_UNUSED = 0
STREAM_THREAD_LIST = 3
STREAM_MODULE_LIST = 4
STREAM_MEMORY_LIST = 5
STREAM_EXCEPTION = 6
STREAM_SYSTEM_INFO = 7
STREAM_MISC_INFO = 15

# Well-known NT status/exception codes that indicate memory-corruption
# or security-relevant crashes. Anything here in a minidump warrants
# closer inspection.
HIGH_RISK_EXCEPTIONS = {
    0xC0000005: "EXCEPTION_ACCESS_VIOLATION",
    0xC0000409: "STACK_BUFFER_OVERRUN (/GS cookie)",
    0xC0000374: "HEAP_CORRUPTION",
    0xC00000FD: "STACK_OVERFLOW",
    0xC0000602: "FAILFAST / RtlFailFast",
    0xC0000420: "ASSERTION_FAILURE",
    0xC0000139: "ENTRYPOINT_NOT_FOUND",
    0x80000003: "BREAKPOINT",
    0xC000041D: "USER_MODE_EXCEPTION_HANDLER_FAULT",
}

# Bugchecks (kernel dump) that suggest malicious drivers or exploitation.
HIGH_RISK_BUGCHECKS = {
    0x0000007E: "SYSTEM_THREAD_EXCEPTION_NOT_HANDLED",
    0x0000003B: "SYSTEM_SERVICE_EXCEPTION",
    0x00000050: "PAGE_FAULT_IN_NONPAGED_AREA",
    0x000000D1: "DRIVER_IRQL_NOT_LESS_OR_EQUAL",
    0x000000C4: "DRIVER_VERIFIER_DETECTED_VIOLATION",
    0x000000BE: "ATTEMPTED_WRITE_TO_READONLY_MEMORY",
    0x000000F7: "DRIVER_OVERRAN_STACK_BUFFER",
    0x00000139: "KERNEL_SECURITY_CHECK_FAILURE",
    0x0000007F: "UNEXPECTED_KERNEL_MODE_TRAP",
    0x00000109: "CRITICAL_STRUCTURE_CORRUPTION",
}

# A crash whose faulting module is in this set is almost always an
# application bug — the C-runtime / XAML / .NET framework is asserting
# on invalid state inside the hosting process. Filtering these out is
# the single biggest false-positive reduction for the dump analyzer.
BENIGN_CRASH_MODULES = {
    # C/C++ runtime
    "ucrtbase.dll", "vcruntime140.dll", "vcruntime140_1.dll",
    "msvcr120.dll", "msvcr100.dll", "msvcr110.dll",
    "msvcp140.dll", "msvcp140_1.dll", "msvcp140_2.dll",
    "msvcp120.dll", "msvcp100.dll",
    # WinRT / XAML / UWP
    "windows.ui.xaml.dll", "xamltransform.dll", "xamlparser.dll",
    "twinapi.appcore.dll", "combase.dll",
    # .NET / CLR
    "clr.dll", "mscoree.dll", "coreclr.dll", "system.private.corelib.dll",
    # Core OS surfaces where misuse by the app causes the fault
    "ntdll.dll", "kernel32.dll", "kernelbase.dll",
}

# Processes known to crash often from ordinary application bugs. A
# single dump here is noise, not a security signal.
KNOWN_FLAKY_APPS = {
    # Chat / conferencing
    "whatsapp.exe", "whatsapp.root.exe", "slack.exe", "teams.exe",
    "ms-teams.exe", "zoom.exe", "spotify.exe", "discord.exe",
    # Windows shell / UWP hosts
    "lockapp.exe", "searchapp.exe", "searchui.exe",
    "startmenuexperiencehost.exe", "shellexperiencehost.exe",
    "applicationframehost.exe", "systemsettings.exe",
    "explorer.exe", "sihost.exe", "ctfmon.exe", "taskhostw.exe",
    "dllhost.exe", "runtimebroker.exe", "conhost.exe",
    "textinputhost.exe", "gamebar.exe", "xboxapp.exe",
    # Media / productivity
    "notepad.exe", "calculator.exe", "mspaint.exe",
    "acrobat.exe", "adobecollabsync.exe", "acrord32.exe",
    # Browsers
    "firefox.exe", "chrome.exe", "msedge.exe",
    "opera.exe", "brave.exe", "iexplore.exe",
    # OneDrive / Teams / etc.
    "onedrive.exe", "dwm.exe",
    # OEM / hardware helpers
    "dptf_helper.exe", "igfxtray.exe", "igfxpers.exe",
    "rtkngui64.exe", "hotkeyservice.exe",
}

# Processes that are never supposed to crash benignly. Any dump here
# warrants investigation regardless of faulting module.
SECURITY_CRITICAL_PROCS = {
    "lsass.exe", "winlogon.exe", "csrss.exe", "wininit.exe",
    "services.exe", "smss.exe", "lsm.exe",
}


class DumpAnalyzer:
    """
    Walks Windows dump files on the host:
      * C:\\Windows\\MEMORY.DMP  (full kernel dump -> handed to Volatility3)
      * C:\\Windows\\Minidump\\*.dmp (kernel minidumps)
      * %LOCALAPPDATA%\\CrashDumps\\*.dmp (user-mode)
      * %LOCALAPPDATA%\\Microsoft\\Windows\\WER\\ReportQueue\\**\\*.dmp
    """

    def __init__(self, hosts: List[Path], workdir: Path,
                 logger: logging.Logger):
        self.hosts = hosts
        self.workdir = workdir
        self.logger = logger
        self.records: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        for p in self.hosts:
            if not p.exists():
                continue
            self._dispatch(p)
        self._analyze()
        return self.records, self.findings

    # -- discovery ------------------------------------------------------

    @staticmethod
    def auto_discover() -> List[Path]:
        out: List[Path] = []
        win = Path(os.environ.get("SystemRoot", r"C:\Windows"))
        if (win / "MEMORY.DMP").exists():
            out.append(win / "MEMORY.DMP")
        md = win / "Minidump"
        if md.exists():
            out += sorted(md.glob("*.dmp"))
        lkr = win / "LiveKernelReports"
        if lkr.exists():
            out += sorted(lkr.glob("*.dmp"))
        local = Path(os.environ.get("LOCALAPPDATA", ""))
        if local.exists():
            cd = local / "CrashDumps"
            if cd.exists():
                out += sorted(cd.glob("*.dmp"))
            wer = local / "Microsoft" / "Windows" / "WER" / "ReportQueue"
            if wer.exists():
                out += sorted(wer.rglob("*.dmp"))
        # Users' WER
        users = Path(r"C:\Users")
        if users.exists():
            for profile in users.iterdir():
                try:
                    cd = profile / "AppData" / "Local" / "CrashDumps"
                    if cd.exists():
                        out += sorted(cd.glob("*.dmp"))
                except (PermissionError, OSError):
                    continue
        return out

    def _dispatch(self, path: Path) -> None:
        try:
            with open(path, "rb") as fh:
                head = fh.read(8)
        except (OSError, PermissionError) as exc:
            self.logger.info("dump unreadable: %s (%s)", path.name, exc)
            return

        if head[:4] == b"PAGE":
            # Full kernel dump (PAGEDU64 / PAGEDUMP)
            self._analyze_full_kernel_dump(path)
        elif head[:4] == b"MDMP":
            rec = self._parse_minidump(path)
            if rec:
                self.records.append(rec)
        else:
            self.logger.debug("unknown dump signature in %s: %r",
                              path.name, head)

    # -- minidump parser ------------------------------------------------

    def _parse_minidump(self, path: Path) -> Optional[Dict[str, Any]]:
        try:
            data = path.read_bytes()
        except (OSError, PermissionError) as exc:
            self.logger.info("  minidump unreadable: %s (%s)",
                             path.name, exc)
            return None
        if len(data) < 32 or data[:4] != b"MDMP":
            return None

        (_sig, version, nstreams, dir_rva,
         _cks, tstamp, flags) = struct.unpack_from("<IIIIIIQ", data, 0)
        created = _filetime_to_iso(
            tstamp * 10_000_000 + 116444736000000000) \
            if tstamp else None
        if not created:
            try:
                created = dt.datetime.fromtimestamp(
                    tstamp, tz=dt.timezone.utc).isoformat()
            except (OverflowError, OSError, ValueError):
                created = None

        rec: Dict[str, Any] = {
            "path": str(path), "name": path.name,
            "size": len(data), "version": version,
            "streams": nstreams, "timestamp": created,
            "type": "user-mode" if flags < 0x1FFFF else "kernel",
            "exception": None, "faulting_module": None,
            "os": None, "modules": [], "thread_count": 0,
            "process_name": None,
        }

        for i in range(nstreams):
            entry_off = dir_rva + i * 12
            if entry_off + 12 > len(data):
                break
            stype, dsize, drva = struct.unpack_from(
                "<III", data, entry_off)
            if drva + dsize > len(data):
                continue
            blob = data[drva:drva + dsize]

            try:
                if stype == STREAM_SYSTEM_INFO:
                    rec["os"] = self._parse_system_info(blob)
                elif stype == STREAM_EXCEPTION:
                    rec["exception"] = self._parse_exception(blob, data)
                elif stype == STREAM_MODULE_LIST:
                    rec["modules"] = self._parse_modules(blob, data)
                elif stype == STREAM_THREAD_LIST:
                    if len(blob) >= 4:
                        rec["thread_count"] = struct.unpack_from(
                            "<I", blob, 0)[0]
                elif stype == STREAM_MISC_INFO:
                    # MiscInfo: ProcessId at offset 8, process times after
                    if len(blob) >= 12:
                        pid = struct.unpack_from("<I", blob, 8)[0]
                        rec["pid"] = pid
            except Exception as exc:
                self.logger.debug("  stream %d parse failed in %s: %s",
                                  stype, path.name, exc)

        # Infer faulting module from the exception address
        if rec["exception"] and rec["modules"]:
            addr = rec["exception"].get("address")
            if isinstance(addr, int):
                for m in rec["modules"]:
                    if m["base"] <= addr < m["base"] + m["size"]:
                        rec["faulting_module"] = m["name"]
                        break

        # Process name is usually the first loaded module
        if rec["modules"]:
            rec["process_name"] = Path(rec["modules"][0]["name"]).name

        # Deep content scan — strings / YARA / injected-PE / URLs.
        # Only for reasonably-sized minidumps to keep the pass fast.
        if len(data) <= 80 * 1024 * 1024:
            try:
                rec["content_hits"] = self._scan_dump_content(rec, data)
            except Exception as exc:
                self.logger.debug(
                    "  content scan %s failed: %s", path.name, exc)
                rec["content_hits"] = []

        return rec

    # -- Deep content scan of minidump memory --------------------------

    # Strings whose presence inside a crash dump is a strong
    # indicator of an offensive tool, malware family, or
    # injection primitive. Each maps to a short analyst-facing
    # explanation.
    _DUMP_STRING_IOCS: Dict[bytes, Tuple[str, int]] = {
        # Mimikatz family
        b"sekurlsa::":          ("Mimikatz sekurlsa command", SEV_CRIT),
        b"lsadump::":           ("Mimikatz lsadump command",  SEV_CRIT),
        b"privilege::debug":    ("Mimikatz SeDebugPrivilege enable",
                                 SEV_CRIT),
        b"kerberos::ptt":       ("Mimikatz pass-the-ticket",  SEV_CRIT),
        b"kerberos::list":      ("Mimikatz Kerberos listing", SEV_HIGH),
        b"kerberos::purge":     ("Mimikatz Kerberos purge",   SEV_HIGH),
        b"misc::skeleton":      ("Mimikatz Skeleton Key",     SEV_CRIT),
        b"gentilkiwi":          ("Mimikatz author tag",       SEV_CRIT),
        b"mimikatz":            ("Mimikatz string",           SEV_CRIT),
        # PowerSploit / offensive PowerShell
        b"Invoke-Mimikatz":     ("PowerSploit Mimikatz wrapper",
                                 SEV_CRIT),
        b"Invoke-DCSync":       ("DCSync attack script",      SEV_CRIT),
        b"Invoke-Kerberoast":   ("Kerberoasting script",      SEV_CRIT),
        b"Invoke-NinjaCopy":    ("NinjaCopy raw-read tool",   SEV_HIGH),
        b"Get-GPPPassword":     ("GPP cpassword harvester",   SEV_HIGH),
        b"Invoke-PsExec":       ("PowerSploit PsExec",        SEV_HIGH),
        # AMSI bypass
        b"AmsiScanBuffer":      ("AMSI scan API (bypass target)",
                                 SEV_HIGH),
        b"amsiInitFailed":      ("AMSI bypass flag",          SEV_HIGH),
        b"AmsiUtils":           ("AMSI bypass primitive",     SEV_HIGH),
        b"amsi.dll":            ("AMSI DLL reference",        SEV_MED),
        # Injection primitives
        b"WriteProcessMemory":  ("WriteProcessMemory API "
                                 "(injection)",               SEV_MED),
        b"CreateRemoteThread":  ("CreateRemoteThread "
                                 "(injection)",               SEV_MED),
        b"NtCreateThreadEx":    ("Native RemoteThread syscall",
                                 SEV_HIGH),
        b"VirtualAllocEx":      ("Remote memory allocation",  SEV_MED),
        b"SetWindowsHookEx":    ("Global hook API",           SEV_MED),
        b"ReflectiveLoader":    ("Reflective DLL loader",     SEV_CRIT),
        # Cobalt Strike / Beacon markers
        b"beacon.dll":          ("Cobalt Strike Beacon DLL",  SEV_CRIT),
        b"beacon.x64.dll":      ("Cobalt Strike Beacon x64",  SEV_CRIT),
        b"ReflectiveLoader@":   ("Reflective-loader symbol "
                                 "(CS / Meter)",              SEV_CRIT),
        b"%s (admin)":          ("Cobalt Strike privilege tag",
                                 SEV_CRIT),
        b"start_thread":        ("Cobalt Strike / metasploit marker",
                                 SEV_HIGH),
        # Meterpreter
        b"metsrv.dll":          ("Meterpreter server DLL",    SEV_CRIT),
        b"stdapi_":             ("Meterpreter stdapi extension",
                                 SEV_CRIT),
        b"core_channel_":       ("Meterpreter core channel",  SEV_CRIT),
        # Common shellcode / loader substrings
        b"NtProtectVirtualMemory": ("Syscall in shellcode",    SEV_MED),
        b"kernel32.dll\x00LoadLibrary": ("API-hash walker "
                                         "primitive",         SEV_HIGH),
        # Credential-dumping byproducts
        b"WDigest":             ("WDigest provider string",   SEV_MED),
        b"UseLogonCredential":  ("WDigest cleartext toggle "
                                 "(Mimikatz pre-flight)",     SEV_HIGH),
    }

    def _scan_dump_content(self, rec: Dict[str, Any],
                            data: bytes) -> List[Dict[str, Any]]:
        hits: List[Dict[str, Any]] = []

        # --- Fast string / IOC scan --------------------------------
        # We do one pass per pattern. For a 30 MB dump this is still
        # ~30 MB × ~50 patterns in native code, <1s.
        for pattern, (label, sev) in self._DUMP_STRING_IOCS.items():
            idx = data.find(pattern)
            if idx < 0:
                continue
            ctx_start = max(0, idx - 24)
            ctx_end = min(len(data), idx + len(pattern) + 48)
            ctx = data[ctx_start:ctx_end].decode(
                "latin-1", errors="replace")
            ctx = "".join(c if 32 <= ord(c) < 127 else "." for c in ctx)
            count = 1
            nxt = idx + len(pattern)
            while True:
                nxt2 = data.find(pattern, nxt)
                if nxt2 < 0 or count >= 50:
                    break
                count += 1
                nxt = nxt2 + len(pattern)
            hits.append({
                "kind": "string",
                "pattern": pattern.decode("latin-1", "ignore"),
                "label": label, "severity": sev,
                "offset": idx,
                "offset_hex": f"0x{idx:x}",
                "count": count, "context": ctx,
            })

        # --- YARA scan on whole dump ------------------------------
        try:
            yara_hits = yara_scan_buffer(data)
            for m in yara_hits:
                hits.append({
                    "kind": "yara",
                    "rule": m.get("rule"),
                    "strings": m.get("strings", []),
                    "tags": m.get("tags", []),
                })
        except Exception:
            pass

        # --- URL / IP strings in memory ---------------------------
        try:
            found_urls = re.findall(
                rb"https?://[A-Za-z0-9.\-_:/?&%=+~#]{6,200}",
                data)[:300]
            unique: Set[str] = set()
            for u in found_urls:
                s = u.decode("latin-1", "ignore")
                # Reject mangled / truncated / trailing garbage
                if len(s) > 300:
                    continue
                unique.add(s)
            if unique:
                hits.append({
                    "kind": "urls_in_memory",
                    "urls": sorted(unique)[:40],
                    "total": len(unique),
                })
        except Exception:
            pass

        # --- Standalone MZ/PE (potential injected PE) -------------
        try:
            module_extents = [
                (m["base"], m["base"] + m["size"])
                for m in (rec.get("modules") or [])
                if m.get("base") and m.get("size")]
            orphan_offsets: List[int] = []
            # MZ-signature scan. We require a valid e_lfanew pointer
            # that lands on 'PE\0\0' within the dump.
            for m in re.finditer(b"MZ", data):
                off = m.start()
                if off + 0x40 >= len(data):
                    break
                try:
                    e_lfanew = struct.unpack_from(
                        "<I", data, off + 0x3C)[0]
                except struct.error:
                    continue
                if not (0 < e_lfanew < 0x1000):
                    continue
                pe_off = off + e_lfanew
                if pe_off + 4 > len(data):
                    continue
                if data[pe_off:pe_off + 4] != b"PE\x00\x00":
                    continue
                # The PE exists — is it part of a loaded module?
                # (modules carry virtual-address ranges; offsets in
                # the dump are file-offsets. We compare against the
                # virtual range loosely: if the PE offset is far
                # away from any module base, treat as orphan.)
                # Since module bases are RVAs, and dump-file offsets
                # aren't directly comparable, we use a proximity
                # heuristic: collect all MZ/PE pairs, then flag only
                # if the count exceeds the number of known modules.
                orphan_offsets.append(off)
                if len(orphan_offsets) > 64:
                    break
            if len(orphan_offsets) > len(module_extents):
                extra = len(orphan_offsets) - len(module_extents)
                hits.append({
                    "kind": "injected_pe",
                    "total_mz_pe": len(orphan_offsets),
                    "known_modules": len(module_extents),
                    "extra": extra,
                    "offsets_hex": [f"0x{o:x}"
                                      for o in orphan_offsets[:20]],
                })
        except Exception:
            pass

        # --- Secrets / credential fragments ----------------------
        try:
            # Look for plaintext domain\\user style strings followed
            # by what looks like a password-like string. Purely a
            # heuristic — reported as informational.
            dom_user_count = len(re.findall(
                rb"[A-Z][A-Z0-9_-]{2,15}\\[a-zA-Z][a-zA-Z0-9._-]{2,20}",
                data))
            if dom_user_count > 0:
                hits.append({
                    "kind": "credential_fragments",
                    "domain_user_strings": dom_user_count,
                })
        except Exception:
            pass

        return hits

    def _parse_system_info(self, blob: bytes) -> Dict[str, Any]:
        if len(blob) < 24:
            return {}
        (arch, _level, _rev, _ncpu_bytes, product,
         major, minor, build, _plat) = struct.unpack_from(
            "<HBBHHIIII", blob, 0)
        return {
            "arch": {0: "x86", 9: "x64", 5: "ARM"}.get(arch, arch),
            "product_type": {1: "Workstation", 2: "DC",
                             3: "Server"}.get(product, product),
            "version": f"{major}.{minor}.{build}",
        }

    def _parse_exception(self, blob: bytes, full: bytes
                          ) -> Dict[str, Any]:
        if len(blob) < 168:
            return {}
        # MINIDUMP_EXCEPTION_STREAM:
        #   ThreadId DWORD, __alignment DWORD
        #   MINIDUMP_EXCEPTION:
        #     ExceptionCode DWORD
        #     ExceptionFlags DWORD
        #     ExceptionRecord ULONGLONG
        #     ExceptionAddress ULONGLONG
        #     NumberParameters DWORD
        #     __unusedAlignment DWORD
        #     ExceptionInformation [15]ULONGLONG
        (thread_id, _a, code, flags_f, _rec,
         addr, nparams) = struct.unpack_from(
            "<II II Q Q I", blob, 0)
        return {
            "thread_id": thread_id,
            "code": code,
            "code_hex": f"0x{code:08X}",
            "code_name": HIGH_RISK_EXCEPTIONS.get(code & 0xFFFFFFFF,
                                                 "(unknown)"),
            "address": addr,
            "address_hex": f"0x{addr:016X}",
            "num_params": nparams,
        }

    def _parse_modules(self, blob: bytes, full: bytes
                        ) -> List[Dict[str, Any]]:
        # MINIDUMP_MODULE layout (108 bytes, packed):
        #   0x00  ULONG64  BaseOfImage
        #   0x08  ULONG32  SizeOfImage
        #   0x0C  ULONG32  CheckSum
        #   0x10  ULONG32  TimeDateStamp
        #   0x14  RVA      ModuleNameRva
        #   0x18  52B      VS_FIXEDFILEINFO
        #   0x4C  8B       CvRecord
        #   0x54  8B       MiscRecord
        #   0x5C  ULONG64  Reserved0
        #   0x64  ULONG64  Reserved1
        if len(blob) < 4:
            return []
        n = struct.unpack_from("<I", blob, 0)[0]
        out: List[Dict[str, Any]] = []
        for i in range(min(n, 512)):
            off = 4 + i * 108
            if off + 108 > len(blob):
                break
            base = struct.unpack_from("<Q", blob, off)[0]
            size = struct.unpack_from("<I", blob, off + 8)[0]
            name_rva = struct.unpack_from("<I", blob, off + 0x14)[0]
            name = self._read_minidump_string(full, name_rva)
            out.append({"name": name, "base": base, "size": size})
        return out

    @staticmethod
    def _read_minidump_string(data: bytes, rva: int) -> str:
        if rva <= 0 or rva + 4 > len(data):
            return "?"
        strlen = struct.unpack_from("<I", data, rva)[0]
        raw = data[rva + 4: rva + 4 + strlen]
        try:
            return raw.decode("utf-16le", errors="ignore")
        except Exception:
            return "?"

    # -- full kernel dump -----------------------------------------------

    def _analyze_full_kernel_dump(self, path: Path) -> None:
        rec = {
            "path": str(path), "name": path.name,
            "size": path.stat().st_size, "type": "full-kernel-dump",
        }
        self.records.append(rec)
        self.findings.append(Finding(
            source="dump", category="dump.full_kernel",
            title=f"Full kernel dump present: {path.name}",
            severity=SEV_INFO,
            conclusion=(
                f"Kernel memory dump '{path.name}' is available "
                f"({rec['size'] / 1024 / 1024:.1f} MB). Re-run this tool "
                "with --memory "
                f"{path} to drive Volatility3 plugins against it."),
            description=("MEMORY.DMP contains a full kernel memory "
                         "snapshot usable with Volatility3 for deep "
                         "rootkit / injection analysis."),
            evidence=rec,
            tags=["dump", "kernel"],
        ))

    # -- analysis -------------------------------------------------------

    def _analyze(self) -> None:
        # First pass: group dumps by process / module for repetition
        # signals.
        by_proc: Dict[str, List[Dict[str, Any]]] = {}
        by_module: Dict[str, List[Dict[str, Any]]] = {}
        for rec in self.records:
            if rec.get("type") == "full-kernel-dump":
                continue
            proc = (rec.get("process_name") or "").lower()
            module = Path(rec.get("faulting_module") or "").name.lower()
            if proc:
                by_proc.setdefault(proc, []).append(rec)
            if module:
                by_module.setdefault(module, []).append(rec)

        for rec in self.records:
            if rec.get("type") == "full-kernel-dump":
                continue
            exc = rec.get("exception") or {}
            code = exc.get("code")
            if code is None:
                continue

            proc = (rec.get("process_name") or "").lower()
            module = Path(rec.get("faulting_module") or "").name.lower()
            proc_repeats = len(by_proc.get(proc, [])) if proc else 1

            # ---- FP filter --------------------------------------
            # Skip entirely when the signal is clearly application
            # instability, not a security event:
            if self._is_likely_benign_crash(proc, module, proc_repeats):
                continue

            # ---- Severity ---------------------------------------
            sev = SEV_INFO

            # A crash in a security-critical process is always
            # worth attention.
            if proc in SECURITY_CRITICAL_PROCS:
                sev = SEV_HIGH
            # An exploitation-class exception in an Office app is a
            # likely macro/exploit payload.
            elif proc in OFFICE_APPS and code in (
                    0xC0000005, 0xC0000409, 0xC0000374):
                sev = SEV_HIGH
            # Faulting module in a user-writable path = third-party /
            # potentially malicious library.
            elif module and _path_is_suspicious(
                    (rec.get("faulting_module") or "").lower()):
                sev = SEV_HIGH
            # Kernel bugcheck in the exploit-relevant set.
            elif code in HIGH_RISK_BUGCHECKS:
                sev = SEV_HIGH
            # Unknown process name (can't rule out anything) with
            # a high-risk exception and repetition.
            elif proc == "" and code in HIGH_RISK_EXCEPTIONS \
                    and proc_repeats >= 3:
                sev = SEV_MED
            else:
                # Non-security-sensitive process with a high-risk
                # exception: escalate only when it's happening often.
                if code in HIGH_RISK_EXCEPTIONS and proc_repeats >= 5:
                    sev = SEV_MED

            if sev < SEV_MED:
                continue

            conclusion = self._crash_conclusion(rec, proc_repeats)
            self.findings.append(Finding(
                source="dump", category="dump.crash",
                title=f"Crash: {rec['name']} "
                      f"({exc.get('code_name', '?')})",
                severity=sev,
                conclusion=conclusion,
                description=(
                    "Minidump records an unhandled exception. Benign "
                    "app-bug crashes (runtime asserts in known-flaky "
                    "apps) are filtered out; only crashes with real "
                    "security relevance are surfaced here."),
                evidence=rec,
                timestamp=rec.get("timestamp"),
                tags=["dump", "crash"],
            ))

    def _emit_content_finding(self, rec: Dict[str, Any],
                                hit: Dict[str, Any]) -> None:
        """Turn one content-hit into a Finding. Each finding
        carries a clear reference (dump path + offset / module) and
        a short analyst-level explanation."""
        dump_path = rec.get("path") or rec.get("name") or "?"
        dump_name = rec.get("name") or Path(dump_path).name
        proc = rec.get("process_name") or "?"
        kind = hit.get("kind")

        if kind == "string":
            sev = hit.get("severity", SEV_MED)
            pattern = hit.get("pattern", "?")
            label = hit.get("label", "?")
            self.findings.append(Finding(
                source="dump",
                category="dump.memory_ioc_string",
                title=(f"Memory IOC '{pattern}' in {dump_name} "
                       f"({label})"),
                severity=sev,
                conclusion=(
                    f"The literal string '{pattern}' was found in "
                    f"the memory of '{proc}' (dump "
                    f"'{dump_name}', offset "
                    f"{hit.get('offset_hex','?')}, "
                    f"{hit.get('count',1)} occurrence(s)). "
                    f"This string is a known indicator of: "
                    f"{label}. Even when the original process is "
                    "no longer running, the string's residence in "
                    "the crash dump confirms the tool or technique "
                    "was active in that process's address space."),
                description="Signature-string match against dump "
                            "memory.",
                evidence={
                    "dump_path": dump_path,
                    "dump_name": dump_name,
                    "process": proc,
                    "pattern": pattern,
                    "label": label,
                    "offset": hit.get("offset"),
                    "offset_hex": hit.get("offset_hex"),
                    "occurrences": hit.get("count", 1),
                    "context": hit.get("context"),
                },
                timestamp=rec.get("timestamp"),
                tags=["dump", "memory-ioc",
                      label.lower().split()[0]]))

        elif kind == "yara":
            self.findings.append(Finding(
                source="dump",
                category="dump.yara_match",
                title=f"YARA match in dump {dump_name}: "
                      f"{hit.get('rule','?')}",
                severity=SEV_CRIT,
                conclusion=(
                    f"YARA rule '{hit.get('rule')}' matched inside "
                    f"the memory dump '{dump_name}' (process "
                    f"'{proc}'). Strings that matched: "
                    f"{', '.join(hit.get('strings') or [])[:200]}. "
                    "The YARA ruleset bundled with the analyzer "
                    "targets well-known offensive families "
                    "(Mimikatz, Cobalt Strike Beacon, Meterpreter, "
                    "PowerSploit, AMSI bypass). A match at this "
                    "depth implies the family was actually loaded "
                    "into the process — this is the highest-"
                    "confidence attribution the analyzer produces."),
                description="YARA scan of minidump memory bytes.",
                evidence={
                    "dump_path": dump_path, "process": proc,
                    "rule": hit.get("rule"),
                    "strings": hit.get("strings"),
                    "tags": hit.get("tags"),
                },
                timestamp=rec.get("timestamp"),
                tags=["dump", "yara-match"] +
                      list(hit.get("tags") or [])))

        elif kind == "injected_pe":
            extra = hit.get("extra", 0)
            self.findings.append(Finding(
                source="dump", category="dump.injected_pe",
                title=(f"Injected PE(s) in {dump_name}: "
                       f"{extra} beyond loaded modules"),
                severity=SEV_HIGH,
                conclusion=(
                    f"Dump '{dump_name}' contains "
                    f"{hit.get('total_mz_pe',0)} valid MZ/PE "
                    f"headers but the process only has "
                    f"{hit.get('known_modules',0)} loaded modules. "
                    f"The {extra} extra PE(s) present in memory "
                    "without being part of the module list are "
                    "the fingerprint of reflective-DLL / in-memory "
                    "PE loaders (Cobalt Strike Reflective Loader, "
                    "Meterpreter Reflective DLL, custom shellcode "
                    "stagers). Offsets in dump: "
                    f"{', '.join(hit.get('offsets_hex') or [])[:200]}."),
                description="MZ/PE pairs found in memory beyond the "
                            "loaded-module list.",
                evidence={
                    "dump_path": dump_path, "process": proc,
                    "total_mz_pe": hit.get("total_mz_pe"),
                    "known_modules": hit.get("known_modules"),
                    "extra": extra,
                    "offsets_hex": hit.get("offsets_hex"),
                },
                timestamp=rec.get("timestamp"),
                tags=["dump", "injection", "T1055.001"]))

        elif kind == "urls_in_memory":
            # Filter against cloud allowlist.
            urls = hit.get("urls") or []
            sus = []
            for u in urls:
                low = u.lower()
                if any(dom in low for dom in (
                        "microsoft.com", "windows.com", "live.com",
                        "azure.com", "office.com", "msedge.net",
                        "msocdn", "visualstudio.com", "github.com",
                        "digicert.com", "msftconnecttest",
                        "bing.com", "xbox.com", "schemas.microsoft",
                        "w3.org", "api.github", "googleapis.com",
                        "cdn.mozilla", "mozilla.org", "mozilla.net")):
                    continue
                m = re.match(r"^https?://([^/:]+)", low)
                if m:
                    host = m.group(1)
                    if re.match(r"^\d+\.\d+\.\d+\.\d+$", host) \
                            and ip_is_benign_cloud(host):
                        continue
                sus.append(u)
            if sus:
                self.findings.append(Finding(
                    source="dump",
                    category="dump.url_in_memory",
                    title=(f"Suspicious URLs in {dump_name} "
                           f"memory ({len(sus)})"),
                    severity=SEV_MED,
                    conclusion=(
                        f"Dump '{dump_name}' (process '{proc}') "
                        f"contains {len(sus)} URL-shaped string(s) "
                        "in its memory that are neither Microsoft "
                        "nor common-cloud endpoints. URLs living "
                        "in a crashed process's RAM are the most "
                        "direct evidence of its recent network "
                        "targets — validate each destination."),
                    description="URL-shaped strings in memory "
                                "dump content.",
                    evidence={
                        "dump_path": dump_path, "process": proc,
                        "suspicious_urls": sus[:30],
                        "total_urls_in_memory": hit.get("total", 0),
                    },
                    timestamp=rec.get("timestamp"),
                    tags=["dump", "c2-candidate"]))

    @staticmethod
    def _is_likely_benign_crash(proc: str, module: str,
                                 proc_repeats: int) -> bool:
        """True when the crash pattern matches application instability
        rather than a security event. Used to drop false positives
        before they ever enter findings."""
        if proc in SECURITY_CRITICAL_PROCS:
            return False
        # Known-flaky app crashing in a framework/runtime module —
        # textbook application bug.
        if proc in KNOWN_FLAKY_APPS and module in BENIGN_CRASH_MODULES:
            return True
        # Known-flaky app with no identifiable module is also noise.
        if proc in KNOWN_FLAKY_APPS and not module:
            return True
        # Any process crashing in a C-runtime / CLR / XAML module,
        # single or low-repetition — application bug.
        if module in BENIGN_CRASH_MODULES and proc_repeats < 5:
            return True
        return False

        # Repeated crash clusters — only flagged when the process is
        # not on the flaky-apps list. Known-flaky apps crash a lot
        # from ordinary bugs; that is not a security event.
        for proc, recs in by_proc.items():
            if len(recs) < 3:
                continue
            if proc in KNOWN_FLAKY_APPS:
                continue
            # If every crash points at a benign module, it is still
            # application instability.
            mods = {Path(r.get("faulting_module") or "").name.lower()
                    for r in recs}
            if mods and all(m in BENIGN_CRASH_MODULES or not m
                            for m in mods):
                continue

            sev = SEV_HIGH if proc in SECURITY_CRITICAL_PROCS \
                else SEV_MED
            self.findings.append(Finding(
                source="dump", category="dump.repeated_crash",
                title=f"Repeated crashes in {proc} ({len(recs)})",
                severity=sev,
                conclusion=(
                    f"Process '{proc}' has {len(recs)} distinct "
                    "crash dumps on this host and the faulting modules "
                    "do not match an ordinary app-instability pattern. "
                    "Investigate whether a persistent malware "
                    "component is destabilizing the process or whether "
                    "a failing exploit loop is reaching it repeatedly."),
                description=("Multiple user-mode dumps for the same "
                             "binary, after filtering out benign "
                             "runtime / framework faults."),
                evidence={"process": proc,
                          "dumps": [r["name"] for r in recs]},
                tags=["dump", "exploit-suspected"],
            ))

        # ---- Content-based findings from deep memory scan -----
        for rec in self.records:
            for hit in rec.get("content_hits") or []:
                self._emit_content_finding(rec, hit)

        for module, recs in by_module.items():
            if len(recs) < 3:
                continue
            if module in BENIGN_CRASH_MODULES:
                continue
            if all((r.get("process_name") or "").lower() in KNOWN_FLAKY_APPS
                   for r in recs):
                continue
            # Cross-process faulting module that is not a system one =
            # suspicious third-party library / driver.
            procs = sorted({(r.get("process_name") or "?") for r in recs})
            self.findings.append(Finding(
                source="dump", category="dump.bad_module",
                title=f"Suspicious module crashes "
                      f"multiple processes: {module}",
                severity=SEV_HIGH,
                conclusion=(
                    f"Module '{module}' was the faulting module in "
                    f"{len(recs)} crashes across processes "
                    f"{procs[:5]}. A non-system library that destabilizes "
                    "multiple different processes is the shape of a "
                    "malicious injected DLL or a bad driver (BYOVD). "
                    "Validate its signature and load path immediately."),
                description=("Same non-benign module crashed multiple "
                             "distinct processes."),
                evidence={"module": module, "processes": procs,
                          "dumps": [r["name"] for r in recs]},
                tags=["dump", "byovd", "injected-dll"],
            ))

    @staticmethod
    def _crash_conclusion(rec: Dict[str, Any],
                           proc_repeats: int = 1) -> str:
        exc = rec.get("exception") or {}
        proc = rec.get("process_name") or "?"
        module = rec.get("faulting_module") or "?"
        code_name = exc.get("code_name", "?")
        addr = exc.get("address_hex", "?")
        when = rec.get("timestamp", "?")

        lead = f"'{proc}' crashed at {when} with {code_name} at {addr}"
        if module and module != "?":
            lead += f", inside '{module}'"

        # Repetition drives the verdict. A single stack-cookie fire is
        # almost always a C-runtime assertion on a bug in the app;
        # repeated fires in the same binary look like a live exploit
        # loop that keeps failing the mitigation.
        repeat_note = ""
        if proc_repeats >= 3:
            repeat_note = (f" This is one of {proc_repeats} such "
                           f"crashes in '{proc}' — repeated memory-"
                           "corruption crashes in the same process are "
                           "consistent with an active exploitation "
                           "attempt against it.")
        elif proc_repeats == 2:
            repeat_note = (f" The same process has now crashed "
                           f"{proc_repeats} times — worth checking "
                           "whether the host is being probed.")

        if exc.get("code") == 0xC0000409:
            return (lead + ". The /GS stack-cookie mitigation fired. "
                    "A single instance in a normal application is most "
                    "commonly an application bug that corrupts the "
                    "stack and is caught by the C-runtime; it only "
                    "becomes exploit-shaped when the same binary "
                    "crashes this way repeatedly." + repeat_note)
        if exc.get("code") == 0xC0000374:
            return (lead + ". The heap manager detected corruption. "
                    "Common during ordinary use-after-free bugs; "
                    "elevated when it recurs." + repeat_note)
        if exc.get("code") == 0xC0000005:
            return (lead + ". Access violation — the process read/"
                    "wrote an invalid address. Single instances are "
                    "almost always latent bugs; repeated AVs in the "
                    "same binary are closer to exploitation signatures."
                    + repeat_note)
        return lead + "." + repeat_note


# ---------------------------------------------------------------------------
# Windows Event Log investigator.
# ---------------------------------------------------------------------------

# -- Attack phases (MITRE ATT&CK tactic names, abbreviated) ------------
ATTACK_PHASES = [
    "reconnaissance", "initial-access", "execution",
    "persistence", "privilege-escalation", "defense-evasion",
    "credential-access", "discovery", "lateral-movement",
    "collection", "command-and-control", "exfiltration", "impact",
]

# -- Comprehensive Event ID catalog ------------------------------------
# Each entry tells the analyzer and the report what the event means,
# which attack phase it maps to, and when an instance of it is
# considered suspicious. The analyzer uses `phase` to group findings in
# the report and `when_suspicious` to render "why this matters".
EVENT_CATALOG: Dict[int, Dict[str, Any]] = {
    # ---- Logon activity ------------------------------------------
    4624: {"name": "Successful logon", "phase": "initial-access",
           "mitre": ["T1078"],
           "description": "A user account successfully logged on. "
                          "LogonType disambiguates interactive vs "
                          "network vs service vs unlock.",
           "when_suspicious": "Unusual hours, unusual source IP, "
                              "privileged account, Type 3/10 from the "
                              "internet, success immediately after a "
                              "4625 burst."},
    4625: {"name": "Failed logon", "phase": "credential-access",
           "mitre": ["T1110"],
           "description": "A logon attempt failed.",
           "when_suspicious": "Burst against one or many users, from "
                              "a remote source, outside business "
                              "hours."},
    4634: {"name": "Logoff", "phase": "initial-access",
           "mitre": [],
           "description": "A user session ended.",
           "when_suspicious": "Rarely alone; used for session timeline "
                              "reconstruction."},
    4647: {"name": "User-initiated logoff", "phase": "initial-access",
           "mitre": [],
           "description": "User voluntarily signed out.",
           "when_suspicious": "Timeline use only."},
    4648: {"name": "Logon using explicit credentials (RunAs)",
           "phase": "credential-access", "mitre": ["T1134.002"],
           "description": "A process presented credentials for another "
                          "account (runas / CreateProcessWithLogonW). "
                          "Often used for UAC elevation, sometimes for "
                          "pass-the-hash or lateral movement.",
           "when_suspicious": "TargetUser is a privileged or service "
                              "account, and the source process is not "
                              "a standard RunAs host (consent.exe, "
                              "runas.exe, mmc.exe). Anomalous source "
                              "IPs are a strong signal."},
    4672: {"name": "Special privileges assigned to new logon",
           "phase": "privilege-escalation", "mitre": ["T1078"],
           "description": "A privileged logon occurred (admin-class "
                          "SIDs in the token).",
           "when_suspicious": "Non-service, non-built-in account "
                              "receiving admin privileges outside "
                              "normal business hours."},
    # ---- Kerberos / NTLM -----------------------------------------
    4768: {"name": "Kerberos TGT requested (AS-REQ)",
           "phase": "credential-access", "mitre": ["T1558.004"],
           "description": "A Kerberos Ticket Granting Ticket was "
                          "issued to a principal.",
           "when_suspicious": "PreAuthType 0 (no pre-auth) for a user "
                              "that should have pre-auth enabled — "
                              "AS-REP roasting. Or RC4 encryption when "
                              "the domain is AES-capable."},
    4769: {"name": "Kerberos service ticket requested (TGS-REQ)",
           "phase": "credential-access", "mitre": ["T1558.003"],
           "description": "A service ticket was issued for an SPN.",
           "when_suspicious": "RC4 (0x17) encryption for a user-SPN — "
                              "Kerberoasting. Bursts across many "
                              "service SPNs from one user indicate "
                              "offline-cracking prep."},
    4770: {"name": "Kerberos service ticket renewed",
           "phase": "credential-access", "mitre": [],
           "description": "An existing service ticket was renewed.",
           "when_suspicious": "Rarely useful alone."},
    4771: {"name": "Kerberos pre-auth failed", "phase": "credential-access",
           "mitre": ["T1110.003"],
           "description": "Pre-authentication for a Kerberos AS-REQ "
                          "failed — typically wrong password.",
           "when_suspicious": "Many 4771s across many user accounts "
                              "from the same source IP = password-"
                              "spray. Many for one account = brute "
                              "force."},
    4776: {"name": "NTLM credential validation",
           "phase": "credential-access", "mitre": ["T1550.002"],
           "description": "A domain controller or local SAM validated "
                          "NTLM credentials.",
           "when_suspicious": "High volume of NTLM to a DC (should be "
                              "rare in Kerberos-first domains), or "
                              "status 0xC000006A (bad password) "
                              "bursts — spray."},
    # ---- Account management --------------------------------------
    4720: {"name": "User account created", "phase": "persistence",
           "mitre": ["T1136.001"],
           "description": "A local or domain user account was created.",
           "when_suspicious": "Outside of HR / onboarding process, "
                              "especially if the account is added to "
                              "admin groups shortly after."},
    4722: {"name": "User account enabled", "phase": "persistence",
           "mitre": ["T1098"],
           "description": "A disabled account was re-enabled.",
           "when_suspicious": "Dormant admin account re-enabled = "
                              "classic backdoor reactivation."},
    4723: {"name": "User password change attempted",
           "phase": "credential-access", "mitre": ["T1098"],
           "description": "A user initiated a password change.",
           "when_suspicious": "When target != subject and target is "
                              "privileged."},
    4724: {"name": "Password reset attempted",
           "phase": "credential-access", "mitre": ["T1098"],
           "description": "An administrator reset another user's "
                          "password.",
           "when_suspicious": "Unscheduled reset of a privileged "
                              "account = account takeover."},
    4725: {"name": "User account disabled", "phase": "impact",
           "mitre": ["T1531"],
           "description": "An account was disabled.",
           "when_suspicious": "Attacker disabling legitimate admins "
                              "to slow IR."},
    4726: {"name": "User account deleted", "phase": "defense-evasion",
           "mitre": ["T1070"],
           "description": "An account was deleted.",
           "when_suspicious": "Removing the attacker's own account "
                              "post-op as cleanup."},
    4738: {"name": "User account changed", "phase": "persistence",
           "mitre": ["T1098"],
           "description": "Properties of a user account changed "
                          "(password-never-expires, UAC flags, etc.).",
           "when_suspicious": "Setting 'password never expires' or "
                              "'no preauth' on an account."},
    4740: {"name": "Account locked out", "phase": "credential-access",
           "mitre": ["T1110"],
           "description": "An account was locked by policy after too "
                          "many failed logons.",
           "when_suspicious": "Implies brute-force was attempted. "
                              "Check the source workstation."},
    4767: {"name": "User account unlocked", "phase": "defense-evasion",
           "mitre": [],
           "description": "A locked account was unlocked.",
           "when_suspicious": "By someone other than the help-desk / "
                              "owner."},
    4781: {"name": "Name of account changed", "phase": "defense-evasion",
           "mitre": ["T1036"],
           "description": "Account rename.",
           "when_suspicious": "Attacker renaming a backdoor account "
                              "to look legitimate."},
    # ---- Group membership ---------------------------------------
    4727: {"name": "Security-enabled global group created",
           "phase": "persistence", "mitre": ["T1098"],
           "description": "New global security group.",
           "when_suspicious": "Odd naming, no ticket/CR."},
    4728: {"name": "Added to security-enabled global group",
           "phase": "privilege-escalation", "mitre": ["T1098"],
           "description": "Member added to a global security group.",
           "when_suspicious": "Target group is Domain Admins / "
                              "Enterprise Admins / Schema Admins."},
    4732: {"name": "Added to security-enabled local group",
           "phase": "privilege-escalation", "mitre": ["T1098"],
           "description": "Member added to a local security group.",
           "when_suspicious": "Target group is Administrators / Remote "
                              "Desktop Users / Backup Operators."},
    4733: {"name": "Removed from security-enabled local group",
           "phase": "defense-evasion", "mitre": [],
           "description": "Member removed from a local group.",
           "when_suspicious": "Removing legit admins from Admins "
                              "group = denial-of-defense."},
    # ---- Process / service --------------------------------------
    4688: {"name": "Process creation", "phase": "execution",
           "mitre": ["T1059"],
           "description": "A new process was created.",
           "when_suspicious": "Office -> LOLBin, encoded PowerShell, "
                              "lsass as parent, rundll32 with "
                              "javascript: / scrobj.dll."},
    4689: {"name": "Process exit", "phase": "execution",
           "mitre": [],
           "description": "A process terminated.",
           "when_suspicious": "Timeline only."},
    4697: {"name": "Service installed (Security log)",
           "phase": "persistence", "mitre": ["T1543.003"],
           "description": "A service was installed (Security channel "
                          "equivalent of 7045).",
           "when_suspicious": "Unsigned binary, unusual path, encoded "
                              "PowerShell action."},
    7045: {"name": "Service installed (System log)",
           "phase": "persistence", "mitre": ["T1543.003"],
           "description": "A service was installed (System channel).",
           "when_suspicious": "Same as 4697."},
    # ---- Scheduled tasks ----------------------------------------
    4698: {"name": "Scheduled task created", "phase": "persistence",
           "mitre": ["T1053.005"],
           "description": "New scheduled task registered.",
           "when_suspicious": "Encoded PowerShell in the task action, "
                              "transient path, runs as SYSTEM."},
    4699: {"name": "Scheduled task deleted", "phase": "defense-evasion",
           "mitre": [],
           "description": "A scheduled task was deleted.",
           "when_suspicious": "Attacker cleaning up their own task."},
    4700: {"name": "Scheduled task enabled", "phase": "persistence",
           "mitre": [],
           "description": "A disabled task was enabled.",
           "when_suspicious": "Weaponizing a dormant task."},
    4702: {"name": "Scheduled task updated", "phase": "persistence",
           "mitre": [],
           "description": "An existing task was modified.",
           "when_suspicious": "Changing the action of a legitimate "
                              "task to run attacker code."},
    # ---- Audit / logs -------------------------------------------
    1102: {"name": "Security audit log cleared",
           "phase": "defense-evasion", "mitre": ["T1070.001"],
           "description": "The Security log was cleared — requires "
                          "SeSecurityPrivilege.",
           "when_suspicious": "Always suspicious outside of audited "
                              "maintenance."},
    104:  {"name": "Operational log cleared", "phase": "defense-evasion",
           "mitre": ["T1070.001"],
           "description": "An Operational channel log was cleared.",
           "when_suspicious": "Always suspicious."},
    1100: {"name": "Event logging service shut down",
           "phase": "defense-evasion", "mitre": ["T1562.002"],
           "description": "The Windows event logging service stopped.",
           "when_suspicious": "Outside of clean reboot window = "
                              "attacker disabling logging."},
    1101: {"name": "Audit events dropped",
           "phase": "defense-evasion", "mitre": [],
           "description": "The audit queue overflowed.",
           "when_suspicious": "Sustained dropping = log flooding "
                              "attack (drown signal in noise)."},
    4719: {"name": "System audit policy changed",
           "phase": "defense-evasion", "mitre": ["T1562.002"],
           "description": "Auditpol was modified — audit settings "
                          "changed.",
           "when_suspicious": "Changes that REDUCE auditing "
                              "(subcategories moved to 'No Auditing') "
                              "are a high-signal anti-forensic "
                              "action."},
    # ---- Registry / DPAPI ---------------------------------------
    4657: {"name": "Registry value modified",
           "phase": "persistence", "mitre": ["T1112"],
           "description": "A registry value was changed (only logged "
                          "when an audit SACL is set).",
           "when_suspicious": "Modifications to Run keys, AppInit_Dlls, "
                              "IFEO, Winlogon, Userinit."},
    4692: {"name": "DPAPI master key backup requested",
           "phase": "credential-access", "mitre": ["T1555.004"],
           "description": "Backup of a user's DPAPI master key was "
                          "attempted.",
           "when_suspicious": "Non-owner / service account requesting "
                              "this = DPAPI credential theft (SharpDPAPI, "
                              "Mimikatz DPAPI)."},
    4693: {"name": "DPAPI master key recovery attempted",
           "phase": "credential-access", "mitre": ["T1555.004"],
           "description": "Recovery of a DPAPI master key was "
                          "attempted (domain backup key).",
           "when_suspicious": "Rare outside IT ops; strong IoC."},
    # ---- Shares / network -------------------------------------
    5140: {"name": "Network share accessed", "phase": "lateral-movement",
           "mitre": ["T1021.002"],
           "description": "A network share object was accessed.",
           "when_suspicious": "Access to ADMIN$ / C$ / IPC$ from a "
                              "workstation IP — SMB lateral movement."},
    5145: {"name": "Network share access check",
           "phase": "lateral-movement", "mitre": ["T1021.002"],
           "description": "Granular share-level access check with "
                          "filename. Highly verbose; logged only when "
                          "object-access auditing is enabled.",
           "when_suspicious": "Access to named pipes (\\\\svcctl, \\\\srvsvc, "
                              "\\\\winreg, \\\\atsvc) on ADMIN$ = PsExec, "
                              "WMIC, scheduled-task lateral movement."},
    # ---- Recon / enumeration --------------------------------
    4798: {"name": "Local group membership enumerated",
           "phase": "discovery", "mitre": ["T1087.002"],
           "description": "An API enumerated a user's local group "
                          "membership.",
           "when_suspicious": "Bursts from a non-IT account across "
                              "many targets = BloodHound / SharpHound "
                              "collection."},
    4799: {"name": "Security-enabled local group enumerated",
           "phase": "discovery", "mitre": ["T1069.001"],
           "description": "Local security group membership "
                          "enumerated.",
           "when_suspicious": "Same as 4798. Combined they are the "
                              "primary signature of AD recon tooling."},
    # ---- PowerShell (requires PS Operational log) ------------
    4104: {"name": "PowerShell script block logged",
           "phase": "execution", "mitre": ["T1059.001"],
           "description": "Script block executed, captured via PS "
                          "script-block logging.",
           "when_suspicious": "Base64/gzip-encoded block, obfuscation, "
                              "download-cradle (IEX new-object "
                              "net.webclient).downloadstring), Invoke-"
                              "Mimikatz, Invoke-Obfuscation."},
    4103: {"name": "PowerShell pipeline execution",
           "phase": "execution", "mitre": ["T1059.001"],
           "description": "Module-level logging of a PS command.",
           "when_suspicious": "Rarely alone; combine with 4104."},
    400:  {"name": "PowerShell engine started",
           "phase": "execution", "mitre": ["T1059.001"],
           "description": "PS engine initialized.",
           "when_suspicious": "Engine state changes from unusual "
                              "HostApplications."},
    403:  {"name": "PowerShell engine stopped",
           "phase": "execution", "mitre": [],
           "description": "PS engine shut down.",
           "when_suspicious": "Timeline only."},
}

# ---------------------------------------------------------------------------
# Sysmon event catalog. These come from the Sysmon Operational channel
# and have VASTLY richer data than Security.evtx equivalents (process
# hash, parent commandline, DNS, raw disk reads, WMI subscription
# events, etc.). Sysmon-specific detectors live alongside the Security
# ones in EventLogAnalyzer.
# ---------------------------------------------------------------------------

SYSMON_CATALOG: Dict[int, Dict[str, Any]] = {
    1: {"name": "Sysmon: Process create",
        "phase": "execution", "mitre": ["T1059"],
        "description": "Process creation with full commandline, "
                       "parent, user, image hash.",
        "when_suspicious": "Office -> LOLBin, signed binary running "
                           "unsigned child, image hash matches IoC, "
                           "unusual parent."},
    3: {"name": "Sysmon: Network connection",
        "phase": "command-and-control", "mitre": ["T1071"],
        "description": "Outbound (or inbound) network connection "
                       "initiated by a process.",
        "when_suspicious": "Non-browser process reaching out to an "
                           "external host, IP matches IoC, or "
                           "connection from a service binary to an "
                           "unusual destination."},
    7: {"name": "Sysmon: Image loaded",
        "phase": "execution", "mitre": ["T1574.002"],
        "description": "A DLL / image loaded into a process.",
        "when_suspicious": "Unsigned DLL loaded from user-writable "
                           "path into a signed process — DLL "
                           "sideloading or injection."},
    8: {"name": "Sysmon: CreateRemoteThread",
        "phase": "privilege-escalation", "mitre": ["T1055"],
        "description": "Thread created in another process.",
        "when_suspicious": "Almost always interesting outside of "
                           "known debuggers; classic code-injection "
                           "primitive."},
    10: {"name": "Sysmon: Process access",
         "phase": "credential-access", "mitre": ["T1003.001"],
         "description": "One process opened a handle to another.",
         "when_suspicious": "Access to lsass.exe with VM_READ / "
                            "PROCESS_QUERY_INFORMATION from a non-"
                            "system caller. Canonical credential-"
                            "dumping primitive."},
    11: {"name": "Sysmon: File create",
         "phase": "execution", "mitre": ["T1105"],
         "description": "New file written to disk.",
         "when_suspicious": "Executable written to Startup folder, "
                            "System32, or a transient path by a "
                            "non-installer process."},
    12: {"name": "Sysmon: Registry object create/delete",
         "phase": "persistence", "mitre": ["T1112"],
         "description": "Registry key created or deleted.",
         "when_suspicious": "Creation of new subkeys under Run / "
                            "IFEO / AppInit."},
    13: {"name": "Sysmon: Registry value set",
         "phase": "persistence", "mitre": ["T1547.001"],
         "description": "Registry value write.",
         "when_suspicious": "Write to HKLM\\...\\Run, Winlogon\\Shell "
                            "/ Userinit, IFEO Debugger."},
    17: {"name": "Sysmon: Pipe created",
         "phase": "lateral-movement", "mitre": ["T1021.002"],
         "description": "Named pipe created by a process.",
         "when_suspicious": "Cobalt Strike default pipe names "
                            "(\\msagent_*, \\status_*, etc.) or "
                            "unusually-named pipes from non-services."},
    22: {"name": "Sysmon: DNS query",
         "phase": "command-and-control", "mitre": ["T1071.004"],
         "description": "A DNS query was issued.",
         "when_suspicious": "DGA-looking domains, DNS over HTTPS from "
                            "non-browser, domains matching IoC feed."},
    23: {"name": "Sysmon: FileDelete",
         "phase": "defense-evasion", "mitre": ["T1070.004"],
         "description": "File deletion (archived by Sysmon).",
         "when_suspicious": "Self-delete of a dropper, log deletion."},
    25: {"name": "Sysmon: Process tampering",
         "phase": "defense-evasion", "mitre": ["T1055.012"],
         "description": "Process Image changed at runtime "
                        "(process hollowing / herpaderp / etc.).",
         "when_suspicious": "Always interesting. Sysmon was purpose-"
                            "built to catch this class of injection."},
}

# Merge Sysmon into main catalog so the report handles both cleanly.
for _eid, _meta in SYSMON_CATALOG.items():
    # Sysmon IDs overlap with low-number Security IDs, but in practice
    # they come from a different channel and we key by (eid, channel).
    # For simplicity we namespace Sysmon as negative IDs internally.
    EVENT_CATALOG[-_eid] = _meta

# Back-compat alias (used by existing code paths)
INTERESTING_EVENTS: Dict[int, str] = {
    eid: meta["name"] for eid, meta in EVENT_CATALOG.items()}


class EventLogAnalyzer:
    def __init__(self, log_paths: List[Path], logger: logging.Logger):
        self.log_paths = log_paths
        self.logger = logger
        self.events: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []
        # eid -> { "count": int, "first": iso, "last": iso, "channels": set }
        self.event_overview: Dict[int, Dict[str, Any]] = {}

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        try:
            import Evtx.Evtx as evtx
        except ImportError:
            self.logger.warning("python-evtx missing; skipping evtx")
            return self.events, self.findings

        # Parallel evtx parsing: python-evtx is I/O + XML-parse heavy,
        # which releases the GIL enough that threads give a real speedup
        # across multiple log files.
        self._overview_lock = threading.Lock()
        logs_to_parse = [l for l in self.log_paths
                          if _safe_exists(l)]
        for missing in [l for l in self.log_paths
                        if not _safe_exists(l)]:
            self.logger.info("evtx not found: %s", missing.name)

        per_log_results: List[List[Dict[str, Any]]] = []
        if not logs_to_parse:
            pass
        else:
            with ThreadPoolExecutor(
                    max_workers=min(len(logs_to_parse), 6)) as ex:
                futures = {ex.submit(self._parse_single_log, evtx, log): log
                           for log in logs_to_parse}
                for fut in as_completed(futures):
                    log = futures[fut]
                    try:
                        rows = fut.result()
                        per_log_results.append(rows)
                        self.logger.info("  %s -> %d events",
                                         log.name, len(rows))
                    except Exception as exc:
                        self.logger.warning(
                            "  parse failed %s: %s", log.name, exc)
        # Flatten and stable-sort by TimeCreated so downstream analysis
        # sees a coherent stream regardless of which thread finished
        # first.
        for rows in per_log_results:
            self.events.extend(rows)
        self.events.sort(
            key=lambda r: r.get("TimeCreated") or "")
        self.logger.info(
            "Collected %d interesting events across %d IDs",
            len(self.events), len(self.event_overview))
        self._analyze()
        return self.events, self.findings

    def _parse_single_log(self, evtx,
                           log: Path) -> List[Dict[str, Any]]:
        is_sysmon = "sysmon" in log.name.lower()
        rows: List[Dict[str, Any]] = []
        self.logger.info("Parsing %s", log.name)
        try:
            with evtx.Evtx(str(log)) as handle:
                for record in handle.records():
                    try:
                        root = ET.fromstring(record.xml())
                    except ET.ParseError:
                        continue
                    row = self._xml_to_dict(root)
                    row["__source_log"] = log.name
                    raw_eid = row.get("EventID")
                    if is_sysmon and raw_eid is not None:
                        row["SysmonEventID"] = raw_eid
                        row["EventID"] = -raw_eid
                    eid = row.get("EventID")
                    if eid in EVENT_CATALOG:
                        rows.append(row)
                        with self._overview_lock:
                            self._track_overview(row)
        except Exception as exc:
            self.logger.warning("  parse failed %s: %s", log.name, exc)
        return rows

    # Caps on how many per-EID samples we retain for the report. We
    # hold more suspicious than benign ones since suspicious rows are
    # what the analyst actually wants to see.
    _MAX_SUSPICIOUS_SAMPLES = 25
    _MAX_BENIGN_SAMPLES     = 5

    def _track_overview(self, row: Dict[str, Any]) -> None:
        eid = row["EventID"]
        slot = self.event_overview.setdefault(eid, {
            "count": 0, "first": None, "last": None,
            "channels": set(),
            "suspicious_samples": [],
            "benign_samples": [],
        })
        slot["count"] += 1
        t = row.get("TimeCreated")
        if t:
            if slot["first"] is None or t < slot["first"]:
                slot["first"] = t
            if slot["last"] is None or t > slot["last"]:
                slot["last"] = t
        ch = row.get("Channel") or row.get("__source_log")
        if ch:
            slot["channels"].add(ch)

        # Sample collection
        reason = _event_is_suspicious(eid, row)
        if reason is not None:
            if len(slot["suspicious_samples"]) < \
                    self._MAX_SUSPICIOUS_SAMPLES:
                sample = _extract_event_fields(eid, row)
                sample["_suspicion"] = reason
                slot["suspicious_samples"].append(sample)
        else:
            if len(slot["benign_samples"]) < \
                    self._MAX_BENIGN_SAMPLES:
                slot["benign_samples"].append(
                    _extract_event_fields(eid, row))

    @staticmethod
    def _xml_to_dict(root) -> Dict[str, Any]:
        ns = "{http://schemas.microsoft.com/win/2004/08/events/event}"
        out: Dict[str, Any] = {}
        sys_el = root.find(f"{ns}System")
        if sys_el is not None:
            eid = sys_el.find(f"{ns}EventID")
            if eid is not None and eid.text:
                try:
                    out["EventID"] = int(eid.text)
                except ValueError:
                    pass
            tc = sys_el.find(f"{ns}TimeCreated")
            if tc is not None:
                out["TimeCreated"] = tc.get("SystemTime")
            comp = sys_el.find(f"{ns}Computer")
            if comp is not None:
                out["Computer"] = comp.text
            chan = sys_el.find(f"{ns}Channel")
            if chan is not None:
                out["Channel"] = chan.text
        data = root.find(f"{ns}EventData")
        if data is not None:
            for item in data.findall(f"{ns}Data"):
                name = item.get("Name")
                if name:
                    out[name] = item.text
        return out

    # -- Investigative analysis ----------------------------------------

    def _analyze(self) -> None:
        self._investigate_log_clearing()
        self._investigate_logging_disabled()
        self._investigate_audit_policy_change()
        self._investigate_brute_force()
        self._investigate_password_spray()
        self._investigate_kerberoasting()
        self._investigate_asrep_roasting()
        self._investigate_runas()
        self._investigate_dpapi_theft()
        self._investigate_recon_enumeration()
        self._investigate_service_installs()
        self._investigate_scheduled_tasks()
        self._investigate_lateral_movement()
        self._investigate_smb_admin_share()
        self._investigate_process_creation()
        self._investigate_powershell_scriptblock()
        self._investigate_account_ops()
        self._investigate_account_lockout()
        self._investigate_sysmon()

    # -- log clear ------------------------------------------------------

    def _investigate_log_clearing(self) -> None:
        for ev in self.events:
            if ev.get("EventID") not in (1102, 104):
                continue
            # Find a logon that immediately preceded the clear to name
            # the actor who did it.
            tclear = _parse_ts(ev.get("TimeCreated"))
            actor = "unknown"
            if tclear:
                priors = [
                    e for e in self.events
                    if e.get("EventID") == 4624 and
                    (t := _parse_ts(e.get("TimeCreated"))) and
                    0 <= (tclear - t).total_seconds() <= 3600
                ]
                if priors:
                    latest = max(priors,
                                 key=lambda x: _parse_ts(x["TimeCreated"]))
                    actor = (latest.get("TargetUserName")
                             or latest.get("SubjectUserName")
                             or "unknown")
            self.findings.append(Finding(
                source="evtlog", category="log.cleared",
                title="Audit log cleared",
                severity=SEV_HIGH,
                conclusion=(
                    f"Audit log was cleared at {ev.get('TimeCreated')}. "
                    f"Most recent interactive logon before the clear was "
                    f"'{actor}'. This actor is the prime suspect for "
                    "the log-clear event."),
                description=("Clearing the audit log requires "
                             "SeSecurityPrivilege — a privileged, "
                             "deliberate anti-forensic action."),
                evidence={"event": ev, "suspected_actor": actor},
                timestamp=ev.get("TimeCreated"),
                tags=["T1070.001", "anti-forensics"],
            ))

    # -- brute force (with success/failure verdict) --------------------

    def _investigate_brute_force(self) -> None:
        fails = [e for e in self.events if e.get("EventID") == 4625]
        if not fails:
            return

        by_user: Dict[str, List[Dict[str, Any]]] = {}
        for e in fails:
            user = (e.get("TargetUserName") or "?").lower()
            by_user.setdefault(user, []).append(e)

        for user, group in by_user.items():
            if len(group) < 5:
                continue
            if user in ("system", "local service", "network service",
                        "anonymous logon"):
                continue

            # Collect the densest temporal sub-cluster: walk the sorted
            # times and find any window of length <= 1h that holds at
            # least 5 failures. If no such window exists, these events
            # are baseline typos, not a burst.
            events_with_ts = sorted(
                [(g, _parse_ts(g.get("TimeCreated"))) for g in group
                 if _parse_ts(g.get("TimeCreated"))],
                key=lambda x: x[1])
            if len(events_with_ts) < 5:
                continue

            window = dt.timedelta(hours=1)
            burst: List[Dict[str, Any]] = []
            i = 0
            for j in range(len(events_with_ts)):
                while (events_with_ts[j][1] -
                       events_with_ts[i][1]) > window:
                    i += 1
                cluster = [events_with_ts[k][0]
                           for k in range(i, j + 1)]
                if len(cluster) > len(burst):
                    burst = cluster
            if len(burst) < 5:
                continue

            burst_times = sorted(filter(None,
                                        (_parse_ts(g.get("TimeCreated"))
                                         for g in burst)))
            first, last = burst_times[0], burst_times[-1]
            span = (last - first).total_seconds()

            src_ips = sorted({(e.get("IpAddress") or "").strip()
                              for e in burst
                              if e.get("IpAddress")
                              and e.get("IpAddress") != "-"})
            workstations = sorted({e.get("WorkstationName") for e in burst
                                   if e.get("WorkstationName")
                                   and e.get("WorkstationName") != "-"})
            logon_types = sorted({str(e.get("LogonType")) for e in burst
                                  if e.get("LogonType")})
            is_interactive_only = bool(logon_types) and all(
                lt in ("2", "10", "11") for lt in logon_types)

            # Follow-through: 4624 for this user within 5 min of the
            # last failure, AND sharing source IP or logon-type-3 with
            # the failed cluster. Without that link, a later successful
            # logon is just the user eventually logging in themselves.
            successes_related: List[Dict[str, Any]] = []
            for e in self.events:
                if e.get("EventID") != 4624:
                    continue
                if (e.get("TargetUserName") or "").lower() != user:
                    continue
                t = _parse_ts(e.get("TimeCreated"))
                if t is None or not (last <= t <=
                                     last + dt.timedelta(minutes=5)):
                    continue
                succ_ip = (e.get("IpAddress") or "").strip()
                succ_type = str(e.get("LogonType") or "")
                ip_match = succ_ip and succ_ip in src_ips
                type_match = (succ_type == "3" and "3" in logon_types)
                if ip_match or type_match:
                    successes_related.append(e)

            if successes_related:
                succ = successes_related[0]
                succ_ip = (succ.get("IpAddress") or "").strip()
                succ_type = str(succ.get("LogonType") or "")
                succ_ip_is_local = succ_ip in ("", "-", "127.0.0.1",
                                               "::1", "localhost")
                # Benign-typo filter: an interactive-only burst followed
                # by an interactive success from the local console is
                # simply the user mistyping their own password at the
                # keyboard before getting it right. Not a compromise.
                if (is_interactive_only and succ_type in ("2", "10", "11")
                        and succ_ip_is_local):
                    sev = SEV_LOW
                    conclusion = (
                        f"User '{user}' mistyped password {len(burst)} "
                        f"times at the console within {int(span)}s "
                        f"and then logged in successfully (interactive, "
                        "local). Not a compromise — benign keyboard "
                        "typos. Recorded at informational level only.")
                    tags = ["benign", "keyboard-typos"]
                else:
                    sev = SEV_CRIT
                    conclusion = (
                        f"Brute-force against '{user}' SUCCEEDED. "
                        f"{len(burst)} failed attempts in a "
                        f"{int(span)}s burst culminated in a "
                        f"successful logon at {succ.get('TimeCreated')} "
                        f"(logon type {succ_type}"
                        + (f", from {succ_ip}" if succ_ip else "")
                        + "). Source IP / logon type matches the "
                        "failed cluster, so this is a confirmed "
                        "account compromise."
                    )
                    tags = ["T1110", "compromise-confirmed"]
            else:
                remote = "3" in logon_types
                high_rate = len(burst) >= 10 and span <= 600
                if is_interactive_only and len(burst) <= 15:
                    sev = SEV_LOW
                elif remote and high_rate:
                    sev = SEV_HIGH
                elif high_rate:
                    sev = SEV_MED
                else:
                    sev = SEV_LOW

                source_desc = (
                    f"from {', '.join(src_ips)}" if src_ips
                    else (f"from workstation(s) "
                          f"{', '.join(workstations)}"
                          if workstations else "source IP not recorded"))
                conclusion = (
                    f"Brute-force against '{user}' FAILED. "
                    f"{len(burst)} failed attempts in a {int(span)}s "
                    f"burst {source_desc}, logon types "
                    f"{', '.join(logon_types)}. No matching successful "
                    "logon (same source IP / remote logon type) within "
                    "5 minutes of the last failure, so the account was "
                    "not compromised in this burst."
                )
                tags = ["T1110"]
                if is_interactive_only:
                    conclusion += (" All failures are interactive "
                                   "(logon type 2 / 10 / 11) — "
                                   "consistent with password typos "
                                   "at the keyboard rather than a "
                                   "remote brute-force.")

            self.findings.append(Finding(
                source="evtlog", category="auth.bruteforce",
                title=f"Failed-logon burst against '{user}' "
                      f"({len(burst)} attempts in {int(span)}s)",
                severity=sev,
                conclusion=conclusion,
                description=("Cluster of 4625 events analyzed for "
                             "temporal density, source, logon type, "
                             "and success follow-through with source "
                             "correlation."),
                evidence={
                    "target_user": user,
                    "burst_count": len(burst),
                    "total_failures_for_user": len(group),
                    "first": first.isoformat(),
                    "last": last.isoformat(),
                    "span_seconds": int(span),
                    "src_ips": src_ips,
                    "workstations": workstations,
                    "logon_types": logon_types,
                    "success_after_burst": bool(successes_related),
                },
                correlated=[{"EventID": e.get("EventID"),
                             "TimeCreated": e.get("TimeCreated"),
                             "IpAddress": e.get("IpAddress"),
                             "LogonType": e.get("LogonType")}
                            for e in successes_related],
                timestamp=last.isoformat(),
                tags=tags,
                confidence="high",
            ))

    # -- service installs (classified) ---------------------------------

    def _investigate_service_installs(self) -> None:
        clusters: Dict[Tuple[str, str], Dict[str, Any]] = {}
        for ev in self.events:
            if ev.get("EventID") not in (7045, 4697):
                continue
            name = (ev.get("ServiceName")
                    or ev.get("SubjectUserName") or "?")
            image = (ev.get("ImagePath")
                     or ev.get("ServiceFileName") or "")
            path_norm = image.lower().strip().strip('"')
            key = (name.lower(), path_norm)
            cluster = clusters.setdefault(key, {
                "name": name, "image": image, "count": 0,
                "first": None, "last": None, "events": [],
            })
            cluster["count"] += 1
            cluster["events"].append(ev)
            t = _parse_ts(ev.get("TimeCreated"))
            if t:
                if cluster["first"] is None or t < cluster["first"]:
                    cluster["first"] = t
                if cluster["last"] is None or t > cluster["last"]:
                    cluster["last"] = t

        for (n_lower, p_lower), c in clusters.items():
            verdict, sev, conclusion = self._classify_service(c)
            if verdict == "benign":
                continue
            self.findings.append(Finding(
                source="evtlog", category="persistence.service",
                title=f"Service installed: {c['name']}",
                severity=sev,
                conclusion=conclusion,
                description=("Service persistence analysis with vendor / "
                             "path / encoded-command classification and "
                             "duplicate collapse."),
                evidence={
                    "service_name": c["name"],
                    "image_path": c["image"],
                    "install_count": c["count"],
                    "first_install": c["first"].isoformat()
                                     if c["first"] else None,
                    "last_install": c["last"].isoformat()
                                    if c["last"] else None,
                    "verdict": verdict,
                },
                timestamp=c["last"].isoformat() if c["last"] else None,
                tags=["T1543.003", "persistence"],
            ))

    @staticmethod
    def _classify_service(c: Dict[str, Any]
                          ) -> Tuple[str, int, str]:
        name = c["name"]
        image = c["image"] or ""
        p_lower = image.lower()

        if _has_encoded_cmd(image):
            return ("malicious", SEV_CRIT,
                    f"Service '{name}' launches a PowerShell / encoded "
                    f"command line ('{image[:120]}'). This is the classic "
                    "pattern of a malicious persistence installer — "
                    "Cobalt Strike / Meterpreter service stagers behave "
                    "exactly this way.")
        if _path_is_suspicious(p_lower):
            return ("malicious", SEV_HIGH,
                    f"Service '{name}' runs binary from a non-standard, "
                    f"user-writable path ('{image}'). Legitimate services "
                    "do not install under TEMP / AppData / Public. "
                    "Treat as malicious persistence until proven "
                    "otherwise.")
        if _path_is_standard(p_lower) and _is_known_vendor(name):
            return ("benign", SEV_INFO, "")
        if _path_is_standard(p_lower) and c["count"] >= 3:
            # Normal service lifecycle (e.g. AV driver reloaded daily)
            return ("benign", SEV_INFO, "")
        if _path_is_standard(p_lower):
            return ("baseline", SEV_LOW,
                    f"Service '{name}' installed from '{image}'. Path is "
                    "within the standard service tree. No vendor match — "
                    "investigate Authenticode signer to confirm it is "
                    "legitimate.")
        return ("suspicious", SEV_MED,
                f"Service '{name}' installed from '{image}'. Path is "
                "neither System32 nor a known Program Files vendor "
                "directory; treat as untrusted until the signer is "
                "verified.")

    # -- scheduled tasks (evtx-side) -----------------------------------

    def _investigate_scheduled_tasks(self) -> None:
        for ev in self.events:
            if ev.get("EventID") != 4698:
                continue
            task = ev.get("TaskName") or "?"
            actor = ev.get("SubjectUserName") or "?"
            content = ev.get("TaskContent") or ""
            encoded = _has_encoded_cmd(content)
            sev = SEV_HIGH if encoded else SEV_MED
            conclusion = (
                f"Scheduled task '{task}' was created by '{actor}'. "
                + ("It contains an encoded PowerShell / hidden "
                   "invocation in its XML action — this is a malicious "
                   "persistence task."
                   if encoded else
                   "Task action should be reviewed in the XML payload "
                   "for legitimacy.")
            )
            self.findings.append(Finding(
                source="evtlog", category="persistence.schtask",
                title=f"Scheduled task created: {task}",
                severity=sev, conclusion=conclusion,
                description="Scheduled task creation event (4698).",
                evidence=ev, timestamp=ev.get("TimeCreated"),
                tags=["T1053.005", "persistence"],
            ))

    # -- lateral movement ---------------------------------------------

    def _investigate_lateral_movement(self) -> None:
        logons = [e for e in self.events
                  if e.get("EventID") == 4624
                  and str(e.get("LogonType")) == "3"]
        services = [e for e in self.events
                    if e.get("EventID") in (7045, 4697)]
        for l in logons:
            lt = _parse_ts(l.get("TimeCreated"))
            if lt is None:
                continue
            for s in services:
                st = _parse_ts(s.get("TimeCreated"))
                if st is None:
                    continue
                delta = (st - lt).total_seconds()
                if not (0 <= delta <= 120):
                    continue
                src = l.get("IpAddress") or l.get("WorkstationName") or "?"
                user = l.get("TargetUserName") or "?"
                svc_name = s.get("ServiceName") or "?"
                svc_path = s.get("ImagePath") or ""
                self.findings.append(Finding(
                    source="evtlog", category="lateral.smb_service",
                    title=(f"Lateral movement: {user}@{src} installed "
                           f"service '{svc_name}'"),
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Network logon (Type 3) by '{user}' from '{src}' "
                        f"was followed {int(delta)}s later by the "
                        f"installation of service '{svc_name}' "
                        f"('{svc_path}'). Textbook PsExec / Cobalt Strike "
                        "'jump psexec' fingerprint — lateral movement "
                        "from an already-compromised source host."),
                    description=("Type-3 logon + fast service install "
                                 "sequence (<=120s)."),
                    evidence={
                        "logon": l, "service": s,
                        "delta_seconds": int(delta),
                        "src_ip": src, "target_user": user,
                        "service_name": svc_name,
                    },
                    timestamp=l.get("TimeCreated"),
                    tags=["T1021.002", "T1543.003", "lateral"],
                ))

    # -- process creation anomaly (4688) -------------------------------

    def _investigate_process_creation(self) -> None:
        creates = [e for e in self.events if e.get("EventID") == 4688]
        for e in creates:
            new = Path(e.get("NewProcessName") or "").name.lower()
            parent = Path(e.get("ParentProcessName") or "").name.lower()
            cmdline = e.get("CommandLine") or ""
            user = e.get("SubjectUserName") or "?"

            anomaly, sev, conc = self._classify_4688(
                new, parent, cmdline, user)
            if not anomaly:
                continue
            self.findings.append(Finding(
                source="evtlog", category=anomaly,
                title=f"{parent or '?'} -> {new or '?'}",
                severity=sev, conclusion=conc,
                description=("4688 parent-child anomaly rule engine."),
                evidence={"event": e,
                          "parent": parent, "child": new,
                          "cmdline": cmdline, "user": user},
                timestamp=e.get("TimeCreated"),
                tags=["T1059", "execution"],
            ))

    @staticmethod
    def _classify_4688(child: str, parent: str,
                        cmdline: str, user: str
                        ) -> Tuple[Optional[str], int, str]:
        if not child:
            return None, SEV_INFO, ""

        if parent in OFFICE_APPS and child in LOLBINS:
            return ("exec.office_to_lolbin", SEV_CRIT,
                    f"Office application '{parent}' spawned LOLBin "
                    f"'{child}' ('{cmdline[:160]}'). Signature of a "
                    "malicious macro dropper.")
        if parent in BROWSER_APPS and child in LOLBINS:
            return ("exec.browser_to_lolbin", SEV_HIGH,
                    f"Browser '{parent}' spawned '{child}' — consistent "
                    "with a drive-by / HTML-smuggling payload.")
        if child in ("powershell.exe", "pwsh.exe") and \
                _has_encoded_cmd(cmdline):
            return ("exec.encoded_powershell", SEV_HIGH,
                    f"Encoded / hidden PowerShell command executed "
                    f"('{cmdline[:160]}'). Characteristic of malware "
                    "loaders.")
        if parent in ("lsass.exe",):
            return ("exec.lsass_child", SEV_CRIT,
                    f"lsass.exe spawned child '{child}'. lsass does not "
                    "legitimately create children; this is injection or "
                    "credential-dump tooling running inside LSASS.")
        if parent == "services.exe" and _path_is_suspicious(
                cmdline.lower()):
            return ("exec.service_from_temp", SEV_HIGH,
                    f"services.exe launched '{child}' from a transient "
                    "path — matches PsExec service abuse.")
        if child in ("rundll32.exe", "regsvr32.exe") and \
                ("javascript:" in cmdline.lower()
                 or "scrobj.dll" in cmdline.lower()):
            return ("exec.squiblydoo", SEV_HIGH,
                    f"{child} invoked with scrobj.dll / javascript: "
                    "('squiblydoo' / 'squiblytwo' AppLocker bypass).")
        return None, SEV_INFO, ""

    # -- account operations -------------------------------------------

    def _investigate_account_ops(self) -> None:
        for ev in self.events:
            eid = ev.get("EventID")
            if eid == 4720:
                tgt = ev.get("TargetUserName") or "?"
                actor = ev.get("SubjectUserName") or "?"
                self.findings.append(Finding(
                    source="evtlog", category="account.created",
                    title=f"User account created: {tgt}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Account '{tgt}' was created by '{actor}'. "
                        "Account creation is a common persistence "
                        "step — validate with the account owner that "
                        "this was intentional."),
                    description="4720 user-account creation.",
                    evidence=ev, timestamp=ev.get("TimeCreated"),
                    tags=["T1136", "persistence"],
                ))
            elif eid in (4728, 4732):
                grp = ev.get("TargetUserName") or "?"
                who = ev.get("MemberName") or "?"
                if "admin" in grp.lower():
                    self.findings.append(Finding(
                        source="evtlog",
                        category="account.priv_escalation",
                        title=f"Added to privileged group {grp}",
                        severity=SEV_HIGH,
                        conclusion=(
                            f"Member '{who}' added to '{grp}'. "
                            "Privilege escalation via group membership "
                            "— verify change-management ticket."),
                        description="Membership added to admin group.",
                        evidence=ev, timestamp=ev.get("TimeCreated"),
                        tags=["T1098"],
                    ))
            elif eid == 4722:
                tgt = ev.get("TargetUserName") or "?"
                self.findings.append(Finding(
                    source="evtlog", category="account.enabled",
                    title=f"Account re-enabled: {tgt}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Account '{tgt}' was re-enabled. If this is a "
                        "dormant privileged or service account, this "
                        "is classic backdoor reactivation."),
                    description="4722 account enabled.",
                    evidence=ev, timestamp=ev.get("TimeCreated"),
                    tags=["T1098", "persistence"],
                ))
            elif eid == 4724:
                tgt = ev.get("TargetUserName") or "?"
                actor = ev.get("SubjectUserName") or "?"
                self.findings.append(Finding(
                    source="evtlog", category="account.pwd_reset",
                    title=f"Password reset: {actor} reset '{tgt}'",
                    severity=SEV_MED,
                    conclusion=(
                        f"'{actor}' reset the password of '{tgt}'. "
                        "Password resets outside the help-desk flow "
                        "are a sign of account takeover."),
                    description="4724 password reset by admin.",
                    evidence=ev, timestamp=ev.get("TimeCreated"),
                    tags=["T1098", "credential-access"],
                ))
            elif eid == 4738:
                flags = ev.get("PasswordLastSet") or ""
                uac = str(ev.get("UserAccountControl") or "")
                if "0x02" in uac or "PASSWD_NOTREQD" in uac.upper() \
                        or "DONT_EXPIRE_PASSWORD" in uac.upper():
                    tgt = ev.get("TargetUserName") or "?"
                    self.findings.append(Finding(
                        source="evtlog",
                        category="account.uac_tampering",
                        title=f"UAC flags changed on account: {tgt}",
                        severity=SEV_HIGH,
                        conclusion=(
                            f"UAC flags on '{tgt}' were changed to "
                            "weaken the account (password-not-required "
                            "/ never-expires / no pre-auth). Attackers "
                            "flip these bits so a planted backdoor "
                            "account never rotates."),
                        description="4738 account UAC change.",
                        evidence=ev, timestamp=ev.get("TimeCreated"),
                        tags=["T1098", "persistence"],
                    ))

    # -- logging service disabled / audit policy changed --------------

    def _investigate_logging_disabled(self) -> None:
        # A 1100 at every OS shutdown is normal. Only flag when a
        # 1100 occurs WITHOUT a matching 6006 (clean shutdown) or
        # 6005 (event log start) in close proximity — i.e. the
        # service was stopped mid-session rather than during reboot.
        ev_ids = {e.get("EventID"): [] for e in self.events}
        for e in self.events:
            ev_ids.setdefault(e.get("EventID"), []).append(e)
        stops = ev_ids.get(1100, [])
        if not stops:
            return
        # Reuse the System-channel 6005 (event log started) timestamps
        # when available via the overview; they arrive as plain events
        # too only if INTERESTING_EVENTS includes them (which it does
        # not). So we rely on a simple heuristic: if there are many
        # 1100 events but each clusters with another within a couple
        # of minutes (classic reboot pair), treat as benign.
        suspect = []
        stop_times = sorted(filter(None,
                                   (_parse_ts(e.get("TimeCreated"))
                                    for e in stops)))
        for i, e in enumerate(stops):
            t = _parse_ts(e.get("TimeCreated"))
            if t is None:
                continue
            # A 1100 is suspicious if isolated — no other 1100 within
            # a ~10-minute window around it and no log-gap pair-up.
            nearby = [s for s in stop_times
                      if s != t and abs((s - t).total_seconds())
                      <= 600]
            if nearby:
                # Part of a normal reboot/maintenance cluster.
                continue
            # Also suspicious only if the stop time is during
            # typical active hours (08:00-22:00 local-ish UTC tail).
            hour = t.hour
            if 8 <= hour <= 22:
                suspect.append(e)

        for e in suspect[:3]:  # cap noise
            self.findings.append(Finding(
                source="evtlog", category="log.service_shutdown",
                title=("Event logging service stopped mid-session"),
                severity=SEV_HIGH,
                conclusion=(
                    "The Windows event-logging service stopped at "
                    f"{e.get('TimeCreated')} without a surrounding "
                    "reboot cluster. Stopping the log service mid-"
                    "session is a textbook anti-forensic step — "
                    "attacker silencing the SIEM before performing a "
                    "noisy action."),
                description="1100 with no matching restart cluster.",
                evidence=e, timestamp=e.get("TimeCreated"),
                tags=["T1562.002", "defense-evasion"],
            ))

    def _investigate_audit_policy_change(self) -> None:
        for ev in self.events:
            if ev.get("EventID") != 4719:
                continue
            sub = ev.get("SubcategoryGuid") or ev.get("AuditPolicyChanges") \
                or ""
            changes = str(ev.get("AuditPolicyChanges") or "").lower()
            reduced = ("%%8448" in changes   # Success removed
                       or "%%8450" in changes  # Failure removed
                       or "removed" in changes)
            sev = SEV_HIGH if reduced else SEV_MED
            self.findings.append(Finding(
                source="evtlog", category="log.audit_policy_change",
                title="System audit policy changed",
                severity=sev,
                conclusion=(
                    "Audit policy was modified at "
                    f"{ev.get('TimeCreated')}."
                    + (" The change REDUCES auditing — the attacker "
                       "is blinding the SIEM for a specific category. "
                       "This is a high-signal anti-forensic step."
                       if reduced else
                       " Validate whether this change is approved; "
                       "auditpol tampering is a common defender-"
                       "evasion play.")),
                description="4719 audit policy change.",
                evidence=ev, timestamp=ev.get("TimeCreated"),
                tags=["T1562.002", "defense-evasion"],
            ))

    # -- Kerberos-based credential access -----------------------------

    def _investigate_kerberoasting(self) -> None:
        # 4769 with ETYPE 0x17 (RC4) and TargetUserName not ending in $
        # is the canonical Kerberoast signature.
        hits: Dict[str, List[Dict[str, Any]]] = {}
        for ev in self.events:
            if ev.get("EventID") != 4769:
                continue
            etype = str(ev.get("TicketEncryptionType") or "").lower()
            spn = (ev.get("ServiceName") or "")
            requester = ev.get("TargetUserName") or "?"
            if etype not in ("0x17", "0x18", "rc4", "rc4-hmac"):
                continue
            if spn.endswith("$") or spn.lower() == "krbtgt":
                # machine / krbtgt — not roastable user SPNs
                continue
            hits.setdefault(requester, []).append(ev)

        for user, group in hits.items():
            distinct_spns = {e.get("ServiceName") for e in group}
            if len(distinct_spns) < 3:
                continue
            self.findings.append(Finding(
                source="evtlog", category="kerberos.kerberoast",
                title=(f"Kerberoasting pattern: '{user}' requested "
                       f"RC4 tickets for {len(distinct_spns)} user SPNs"),
                severity=SEV_CRIT,
                conclusion=(
                    f"Account '{user}' requested Kerberos service "
                    f"tickets with RC4 (weak) encryption for "
                    f"{len(distinct_spns)} distinct user-SPN accounts "
                    "in short order. This is the deterministic "
                    "signature of Kerberoasting (Rubeus / Invoke-"
                    "Kerberoast): tickets are taken offline and "
                    "brute-forced into cleartext service passwords."),
                description="4769 RC4 tickets for multiple user SPNs.",
                evidence={"requester": user,
                          "spn_count": len(distinct_spns),
                          "spn_sample": sorted(distinct_spns)[:10]},
                timestamp=group[0].get("TimeCreated"),
                tags=["T1558.003", "credential-access"],
            ))

    def _investigate_asrep_roasting(self) -> None:
        # 4768 with pre-auth type 0 for user accounts = AS-REP roastable
        for ev in self.events:
            if ev.get("EventID") != 4768:
                continue
            preauth = str(ev.get("PreAuthType") or "")
            user = ev.get("TargetUserName") or "?"
            if preauth != "0":
                continue
            if user.endswith("$"):
                continue
            self.findings.append(Finding(
                source="evtlog", category="kerberos.asrep_roast",
                title=f"AS-REP roastable: '{user}' (PreAuthType=0)",
                severity=SEV_HIGH,
                conclusion=(
                    f"User '{user}' requested a TGT without Kerberos "
                    "pre-authentication. This means the 'Do not "
                    "require Kerberos preauthentication' UAC flag is "
                    "set. Attackers query such accounts to harvest "
                    "AS-REP ciphertexts that can be cracked offline "
                    "(AS-REP roasting)."),
                description="4768 no-preauth TGT for user account.",
                evidence=ev, timestamp=ev.get("TimeCreated"),
                tags=["T1558.004", "credential-access"],
            ))

    def _investigate_password_spray(self) -> None:
        # 4771 (Kerberos preauth fail) or 4625 LogonType=3 across many
        # distinct users from the same source — password spray.
        window = dt.timedelta(minutes=30)
        candidates = [e for e in self.events
                      if e.get("EventID") == 4771
                      or (e.get("EventID") == 4625
                          and str(e.get("LogonType")) == "3")]
        if not candidates:
            return
        # Group by source IP + sliding window, count unique usernames
        buckets: Dict[str, List[Dict[str, Any]]] = {}
        for e in candidates:
            ip = e.get("IpAddress") or e.get("ClientAddress") or "?"
            if ip in ("-", "", "127.0.0.1", "::1"):
                continue
            buckets.setdefault(ip, []).append(e)
        for ip, group in buckets.items():
            group.sort(key=lambda x: _parse_ts(x.get("TimeCreated"))
                       or dt.datetime.min.replace(
                           tzinfo=dt.timezone.utc))
            # any 30-minute window with >= 5 distinct usernames?
            i = 0
            for j in range(len(group)):
                tj = _parse_ts(group[j].get("TimeCreated"))
                ti = _parse_ts(group[i].get("TimeCreated"))
                while ti and tj and (tj - ti) > window and i < j:
                    i += 1
                    ti = _parse_ts(group[i].get("TimeCreated"))
                users = {e.get("TargetUserName")
                         for e in group[i:j + 1]
                         if e.get("TargetUserName")}
                if len(users) >= 5:
                    self.findings.append(Finding(
                        source="evtlog",
                        category="auth.password_spray",
                        title=(f"Password spray from {ip}: "
                               f"{len(users)} accounts in one window"),
                        severity=SEV_HIGH,
                        conclusion=(
                            f"Source {ip} attempted auth against "
                            f"{len(users)} distinct users within "
                            "30 minutes (one-or-two guesses per "
                            "account). This is password-spraying — "
                            "trying common passwords broadly to avoid "
                            "lockout."),
                        description=("Cross-user, low-count-per-user "
                                     "auth failures from one source."),
                        evidence={"src_ip": ip,
                                  "unique_users": sorted(users)[:15],
                                  "total_attempts": len(
                                      [e for e in group[i:j + 1]])},
                        timestamp=group[j].get("TimeCreated"),
                        tags=["T1110.003", "credential-access"],
                    ))
                    break  # One finding per source IP is enough

    # -- RunAs abuse -------------------------------------------------

    # Built-in Windows session-init pseudo-accounts. Event 4648 between
    # these is a Windows internal, not a lateral-movement primitive.
    _WINDOWS_PSEUDO_USERS_PREFIX = ("umfd-", "dwm-", "anonymous logon")

    # Callers that legitimately produce 4648 as part of Windows ops.
    _BENIGN_RUNAS_CALLERS = {
        "consent.exe", "runas.exe", "mmc.exe", "taskmgr.exe",
        "userinit.exe", "credwiz.exe", "explorer.exe",
        "wininit.exe", "winlogon.exe", "lsass.exe",
        "services.exe", "svchost.exe",
        "vmcompute.exe", "vmwp.exe", "vmmem.exe",     # Hyper-V
        "dllhost.exe", "runtimebroker.exe",
        "wmprvse.exe",
    }

    def _investigate_runas(self) -> None:
        for ev in self.events:
            if ev.get("EventID") != 4648:
                continue
            caller = (ev.get("ProcessName") or "").lower()
            caller_base = Path(caller).name
            target = (ev.get("TargetUserName") or "").lower()
            subject = (ev.get("SubjectUserName") or "").lower()

            if not target or not caller_base:
                continue
            if target.endswith("$"):
                continue
            # Windows session-init pseudo accounts: never interesting.
            if any(target.startswith(p)
                   for p in self._WINDOWS_PSEUDO_USERS_PREFIX):
                continue
            # Target == subject (process switching to an already-
            # authenticated context; self-impersonation).
            if target == subject:
                continue
            # Hyper-V VM GUIDs (target is a UUID-shaped string).
            if re.fullmatch(
                    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"
                    r"[0-9a-f]{4}-[0-9a-f]{12}", target):
                continue
            if caller_base in self._BENIGN_RUNAS_CALLERS:
                continue
            # Suppress logons TO local pseudo-service SIDs when the
            # subject is SYSTEM / a service.
            if subject in ("system", "local service", "network service"):
                continue
            self.findings.append(Finding(
                source="evtlog", category="credential.runas",
                title=(f"Explicit-credential logon from unusual "
                       f"process: {caller_base} -> {target}"),
                severity=SEV_HIGH,
                conclusion=(
                    f"Process '{caller_base}' invoked "
                    "CreateProcessWithLogonW (explicit credentials) "
                    f"for account '{target}'. Outside of standard UAC "
                    "/ RunAs hosts and Windows internal services, this "
                    "is how pass-the-hash, pass-the-ticket, and "
                    "lateral-movement frameworks (CrackMapExec, "
                    "Impacket, Cobalt Strike 'make_token') impersonate "
                    "privileged accounts."),
                description="4648 explicit-cred logon from a caller "
                            "that does not legitimately produce it.",
                evidence=ev, timestamp=ev.get("TimeCreated"),
                tags=["T1134.002", "T1550.002", "credential-access"],
            ))

    # -- DPAPI theft -------------------------------------------------

    def _investigate_dpapi_theft(self) -> None:
        for ev in self.events:
            eid = ev.get("EventID")
            if eid not in (4692, 4693):
                continue
            subject = ev.get("SubjectUserName") or "?"
            target = ev.get("MasterKeyId") or ev.get("TargetUserName") or "?"
            # Skip system services performing legitimate backup.
            if subject.upper() in ("SYSTEM", "LOCAL SERVICE",
                                    "NETWORK SERVICE") \
                    or subject.endswith("$"):
                continue
            self.findings.append(Finding(
                source="evtlog", category="credential.dpapi",
                title=(f"DPAPI master-key {'backup' if eid == 4692 else 'recovery'} "
                       f"by '{subject}'"),
                severity=SEV_CRIT,
                conclusion=(
                    f"Account '{subject}' attempted to "
                    f"{'back up' if eid == 4692 else 'recover'} a "
                    f"DPAPI master key (target {target}). DPAPI holds "
                    "Chrome/Edge passwords, saved RDP credentials, "
                    "and Wi-Fi keys. Non-system access to DPAPI keys "
                    "is the signature of SharpDPAPI / Mimikatz "
                    "DPAPI-extraction tooling."),
                description=f"{eid} DPAPI master-key operation.",
                evidence=ev, timestamp=ev.get("TimeCreated"),
                tags=["T1555.004", "credential-access"],
            ))

    # -- Recon (BloodHound-like enumeration) -------------------------

    def _investigate_recon_enumeration(self) -> None:
        enum_events = [e for e in self.events
                       if e.get("EventID") in (4798, 4799)]
        if not enum_events:
            return
        # Cluster by subject user, then require TEMPORAL DENSITY
        # (BloodHound collects hundreds within seconds to minutes,
        # not months) AND cross-target variety (many distinct targets
        # being enumerated, not the same one over and over).
        by_subj: Dict[str, List[Dict[str, Any]]] = {}
        for e in enum_events:
            who = (e.get("SubjectUserName") or "?").lower()
            if who.endswith("$") or who in ("system", ""):
                continue
            by_subj.setdefault(who, []).append(e)

        density_window = dt.timedelta(minutes=10)
        for subj, group in by_subj.items():
            events_with_ts = sorted(
                [(g, _parse_ts(g.get("TimeCreated"))) for g in group
                 if _parse_ts(g.get("TimeCreated"))],
                key=lambda x: x[1])
            if len(events_with_ts) < 50:
                continue

            # Find the densest 10-minute window.
            best_burst: List[Dict[str, Any]] = []
            i = 0
            for j in range(len(events_with_ts)):
                while (events_with_ts[j][1]
                       - events_with_ts[i][1]) > density_window:
                    i += 1
                sub = [events_with_ts[k][0] for k in range(i, j + 1)]
                if len(sub) > len(best_burst):
                    best_burst = sub
            # A BloodHound collection spikes — require 50+ queries in
            # a 10-minute window, hitting many distinct targets.
            if len(best_burst) < 50:
                continue
            targets = {(e.get("TargetUserName")
                        or e.get("TargetSid") or "?")
                       for e in best_burst}
            if len(targets) < 15:
                continue

            first_t = _parse_ts(best_burst[0].get("TimeCreated"))
            last_t = _parse_ts(best_burst[-1].get("TimeCreated"))
            span = (last_t - first_t).total_seconds() if first_t \
                and last_t else 0
            self.findings.append(Finding(
                source="evtlog", category="discovery.enumeration",
                title=(f"AD enumeration burst by '{subj}': "
                       f"{len(best_burst)} queries / "
                       f"{len(targets)} targets in {int(span)}s"),
                severity=SEV_HIGH,
                conclusion=(
                    f"Account '{subj}' enumerated AD group/membership "
                    f"for {len(targets)} distinct targets inside a "
                    f"{int(span)}-second window — a rate-and-breadth "
                    "profile that normal desktop activity does not "
                    "produce. This is the deterministic fingerprint "
                    "of SharpHound / BloodHound collection, run after "
                    "a foothold to map lateral-movement paths."),
                description="Temporally dense, cross-target 4798/4799 "
                            "burst.",
                evidence={"subject": subj,
                          "burst_queries": len(best_burst),
                          "distinct_targets": len(targets),
                          "span_seconds": int(span),
                          "first": best_burst[0].get("TimeCreated"),
                          "last": best_burst[-1].get("TimeCreated")},
                timestamp=best_burst[-1].get("TimeCreated"),
                tags=["T1087.002", "T1069.001", "discovery"],
            ))

    # -- SMB ADMIN$ / IPC$ named pipe lateral -----------------------

    def _investigate_smb_admin_share(self) -> None:
        suspect_pipes = ("\\svcctl", "\\srvsvc", "\\winreg",
                         "\\atsvc", "\\lsarpc", "\\samr", "\\spoolss")
        by_src: Dict[str, List[Dict[str, Any]]] = {}
        for ev in self.events:
            if ev.get("EventID") != 5145:
                continue
            share = (ev.get("ShareName") or "").lower()
            obj = (ev.get("RelativeTargetName") or "").lower()
            if share in ("\\\\*\\admin$", "\\\\*\\ipc$") \
                    and any(p in obj for p in suspect_pipes):
                src = ev.get("IpAddress") or "?"
                by_src.setdefault(src, []).append(ev)
        for src, group in by_src.items():
            pipes = sorted({(e.get("RelativeTargetName") or "")
                            for e in group})
            self.findings.append(Finding(
                source="evtlog", category="lateral.named_pipe",
                title=f"Named-pipe lateral access from {src}",
                severity=SEV_CRIT,
                conclusion=(
                    f"Source {src} accessed named pipes "
                    f"{pipes[:5]} on ADMIN$ / IPC$. These pipes are "
                    "the transport for svcctl (service install), "
                    "atsvc (scheduled tasks), winreg (remote registry) "
                    "and srvsvc (share enumeration). Access to them "
                    "from a workstation is the exact fingerprint of "
                    "PsExec / Impacket smbexec / wmiexec lateral "
                    "movement."),
                description="5145 ADMIN$/IPC$ pipe access.",
                evidence={"src_ip": src, "pipes": pipes,
                          "hit_count": len(group)},
                timestamp=group[-1].get("TimeCreated"),
                tags=["T1021.002", "lateral-movement"],
            ))

    # -- PowerShell script-block content -----------------------------

    # Patterns that, by themselves, are high-confidence malicious.
    _PS_MALICIOUS_ALONE = (
        "invoke-mimikatz",
        "invoke-shellcode",
        "invoke-obfuscation",
        "amsiinitfailed",
        "amsiutils",
        "set-mppreference -disable",
        "add-mppreference -exclusionpath",
        "iex(new-object net.webclient",
        "iex (new-object net.webclient",
        "invoke-dcsync",
        "invoke-kerberoast",
        "get-gppassword",
        "invoke-psexec",
        "invoke-wmiexec",
        "invoke-smbexec",
        "sharphound",
        "powerview",
        "bloodhound",
        "$ExecutionContext.SessionState.LanguageMode",
        "[ref].assembly.gettype('system.management.automation.amsi",
    )
    # Weaker patterns; flagged only if 2+ appear together.
    _PS_SUSPICIOUS = (
        "frombase64string(",
        "reflection.assembly]::load(",
        "[system.convert]::frombase64string",
        "downloadstring(",
        "downloadfile(",
        "invoke-expression",
        "-nop -w hidden",
        "-nop -windowstyle hidden",
        "-executionpolicy bypass",
        "-enc ",
        "-encodedcommand",
        "new-object system.net.webclient",
        "system.net.servicepointmanager",
    )

    # Contexts that indicate the script is itself a hunter / detector
    # searching for malicious patterns, not executing them. We skip
    # findings when any of these appear — the "malicious" strings are
    # just quoted indicators in a regex list.
    _PS_DETECTOR_CONTEXT = (
        "$scriptblock -match",
        "scriptblock -match",
        "scriptblock -like",
        "scriptblock -notmatch",
        "regexpattern",
        "processedeventhashes",
        "get-winevent",
        "get-eventlog",
        "$eventkey",
        "$_.providername",
        "$_.recordid",
        "properties[0].value",
        "microsoft-windows-powershell/operational",
        # Common detector assignments
        "$patterns =", "$indicators =", "$rules =",
        "$sigs =", "$signatures =",
    )

    def _investigate_powershell_scriptblock(self) -> None:
        for ev in self.events:
            if ev.get("EventID") != 4104:
                continue
            block = (ev.get("ScriptBlockText") or "").lower()
            if not block:
                continue

            # Skip detector / hunting scripts that contain the bad
            # strings only as indicators of what to search for.
            if any(ctx in block for ctx in self._PS_DETECTOR_CONTEXT):
                continue

            # 1) Unambiguous markers (any one is enough)
            strong_hits = [p for p in self._PS_MALICIOUS_ALONE
                           if p in block]
            # 2) Weak markers: need 2+ to raise a flag
            weak_hits = [p for p in self._PS_SUSPICIOUS if p in block]

            if strong_hits:
                sev = SEV_CRIT if any("amsi" in h or "mimikatz" in h
                                       or "dcsync" in h or "sharphound"
                                       in h for h in strong_hits) \
                      else SEV_HIGH
                title_tag = ("AMSI bypass"
                             if any("amsi" in h for h in strong_hits)
                             else "known offensive PS tooling")
                narrative = (
                    "PowerShell script-block logging captured a "
                    "script containing an unambiguous offensive "
                    f"primitive: {', '.join(strong_hits[:3])}. This is "
                    "not a defensive / installer pattern — it is a "
                    "named offensive tool or a specific evasion "
                    "technique.")
            elif len(weak_hits) >= 2:
                sev = SEV_HIGH
                title_tag = "downloader cradle / obfuscation"
                narrative = (
                    f"Script block combines {len(weak_hits)} "
                    "suspicious patterns simultaneously "
                    f"({', '.join(weak_hits[:3])}). Any one of these "
                    "alone can appear in legitimate installers, but "
                    "the combination is the canonical shape of a "
                    "downloader cradle or in-memory loader.")
            else:
                continue

            self.findings.append(Finding(
                source="evtlog", category="execution.ps_obfuscated",
                title=f"PowerShell script block: {title_tag}",
                severity=sev,
                conclusion=narrative + " The full script block is "
                                       "preserved in evidence.",
                description="4104 script-block analyzed with a "
                            "strong/weak-pattern classifier to avoid "
                            "flagging ordinary installer scripts.",
                evidence={"strong_hits": strong_hits,
                          "weak_hits": weak_hits,
                          "script_block_excerpt": block[:800],
                          "computer": ev.get("Computer"),
                          "time": ev.get("TimeCreated")},
                timestamp=ev.get("TimeCreated"),
                tags=["T1059.001", "T1027", "execution"],
            ))

    # -- Sysmon detectors (if Sysmon Operational was parsed) ---------

    def _investigate_sysmon(self) -> None:
        # Process-creation chains: Office -> LOLBin already covered
        # by _investigate_process_creation; here we add Sysmon-only
        # primitives (hashes, DLL loads, lsass handle, DNS, pipes).
        self._sysmon_lsass_access()
        self._sysmon_dll_sideload()
        self._sysmon_process_tampering()
        self._sysmon_beacon_pipes()
        self._sysmon_dns_ioc()

    def _sysmon_lsass_access(self) -> None:
        """Sysmon EID 10 is the gold-standard lsass-access signal —
        far more reliable than Volatility handle-walk."""
        for ev in self.events:
            if ev.get("EventID") != -10:  # Sysmon 10
                continue
            target_image = (ev.get("TargetImage") or "").lower()
            if "lsass.exe" not in target_image:
                continue
            granted = str(ev.get("GrantedAccess") or "").upper()
            # 0x1010 = PROCESS_VM_READ|QUERY_LIMITED
            # 0x1410 = +DUP_HANDLE
            # 0x1438 = full credential-dump triad
            # 0x143A = same + VM_WRITE
            if not any(x in granted for x in ("0X1010", "0X1410",
                                               "0X1438", "0X143A",
                                               "0X40", "0X10")):
                continue
            source = ev.get("SourceImage") or "?"
            source_base = Path(source).name.lower()
            # Whitelist a few known-legit AV/EDR callers
            benign = ("msmpeng.exe", "smartscreen.exe",
                      "securityhealthservice.exe",
                      "mssense.exe", "mbamservice.exe",
                      "sentinelagent.exe", "sentinelhelperservice.exe",
                      "elastic-agent.exe", "cybereasonransomware.exe",
                      "cybereasonsensor.exe")
            if source_base in benign:
                continue
            self.findings.append(Finding(
                source="evtlog",
                category="credential.lsass_access_sysmon",
                title=f"Sysmon: {source_base} reads lsass memory",
                severity=SEV_CRIT,
                conclusion=(
                    f"Sysmon EID 10 recorded process '{source}' "
                    f"obtaining handle to lsass.exe with access mask "
                    f"{granted}. This is the gold-standard credential-"
                    "dumping primitive — Sysmon catches it even when "
                    "Volatility would miss. Known tools that produce "
                    "this: Mimikatz, procdump, nanodump, "
                    "comsvcs.dll MiniDump."),
                description="Sysmon 10 (ProcessAccess) targeting "
                            "lsass.exe.",
                evidence=ev, timestamp=ev.get("UtcTime"),
                tags=["T1003.001", "credential-access"],
            ))

    def _sysmon_dll_sideload(self) -> None:
        """Sysmon 7: unsigned DLL from user-writable path loaded into
        a signed process = DLL sideload / search-order hijack."""
        for ev in self.events:
            if ev.get("EventID") != -7:
                continue
            img_loaded = (ev.get("ImageLoaded") or "").lower()
            signed = str(ev.get("Signed") or "").lower()
            signature = ev.get("Signature") or ""
            if signed == "true":
                continue
            if not _path_is_suspicious(img_loaded):
                continue
            self.findings.append(Finding(
                source="evtlog",
                category="execution.dll_sideload",
                title=f"Unsigned DLL loaded from {img_loaded}",
                severity=SEV_HIGH,
                conclusion=(
                    f"Sysmon 7 reports loading of unsigned "
                    f"'{img_loaded}' into process "
                    f"'{ev.get('Image', '?')}'. Unsigned DLL loaded "
                    "from a user-writable directory is the shape of a "
                    "DLL sideload / search-order hijack."),
                description="Sysmon ImageLoad of unsigned DLL from "
                            "transient path.",
                evidence=ev, timestamp=ev.get("UtcTime"),
                tags=["T1574.002", "execution"],
            ))

    def _sysmon_process_tampering(self) -> None:
        """Sysmon 25 is the flagship process-hollowing / RunPE
        detector. Every instance is worth attention."""
        for ev in self.events:
            if ev.get("EventID") != -25:
                continue
            image = ev.get("Image") or "?"
            kind = ev.get("Type") or "?"
            self.findings.append(Finding(
                source="evtlog",
                category="vad.process_tampering",
                title=f"Process tampering in {image} ({kind})",
                severity=SEV_CRIT,
                conclusion=(
                    f"Sysmon 25 captured in-memory tampering of "
                    f"process '{image}' (type: {kind}). Process "
                    "hollowing / herpaderp / module-overwriting is the "
                    "canonical form of in-memory PE replacement — "
                    "Sysmon was designed to catch exactly this."),
                description="Sysmon 25 ProcessTampering.",
                evidence=ev, timestamp=ev.get("UtcTime"),
                tags=["T1055.012", "injection"],
            ))

    _CS_PIPE_PATTERNS = (r"\\msagent_", r"\\status_", r"\\postex_")

    def _sysmon_beacon_pipes(self) -> None:
        """Sysmon 17: pipes matching Cobalt Strike default profiles."""
        for ev in self.events:
            if ev.get("EventID") != -17:
                continue
            pipe = (ev.get("PipeName") or "").lower()
            if not any(p.lower() in pipe
                       for p in self._CS_PIPE_PATTERNS):
                continue
            self.findings.append(Finding(
                source="evtlog",
                category="c2.cs_pipe",
                title=f"Cobalt-Strike-shaped pipe: {pipe}",
                severity=SEV_CRIT,
                conclusion=(
                    f"Sysmon 17 recorded creation of named pipe "
                    f"'{pipe}' — this matches the default Cobalt "
                    "Strike Malleable-C2 pipe profiles (msagent_*, "
                    "status_*, postex_*). Unless the team uses CS for "
                    "an authorized pentest, this is an active C2 "
                    "implant."),
                description="Sysmon 17 CS default pipe name.",
                evidence=ev, timestamp=ev.get("UtcTime"),
                tags=["T1071", "c2", "cobalt-strike"],
            ))

    def _sysmon_dns_ioc(self) -> None:
        """Sysmon 22: DNS queries. Flag DGA-looking domains; IoC match
        happens in the correlation stage."""
        # DGA heuristic: the second-level label is long + has high
        # letter entropy + no dictionary hits.
        import math
        def _entropy(s: str) -> float:
            if not s:
                return 0.0
            from collections import Counter
            freq = Counter(s)
            total = len(s)
            return -sum((n / total) * math.log2(n / total)
                        for n in freq.values())
        for ev in self.events:
            if ev.get("EventID") != -22:
                continue
            q = (ev.get("QueryName") or "").lower().rstrip(".")
            if not q or q.count(".") < 1:
                continue
            labels = q.split(".")
            if len(labels) < 2:
                continue
            sld = labels[-2]  # second-level domain
            if len(sld) < 12:
                continue
            ent = _entropy(sld)
            if ent < 3.5:
                continue
            if any(c in sld for c in "-_"):
                # Vendor CDNs often have hyphens; skip.
                continue
            if not re.fullmatch(r"[a-z0-9]+", sld):
                continue
            self.findings.append(Finding(
                source="evtlog", category="c2.dga_domain",
                title=f"DGA-shaped DNS query: {q}",
                severity=SEV_MED,
                conclusion=(
                    f"Sysmon 22 observed a DNS query to '{q}'. The "
                    f"second-level label '{sld}' has high entropy "
                    f"({ent:.1f}) and no hyphens, a profile consistent "
                    "with Domain Generation Algorithms used by modern "
                    "botnets and loaders."),
                description="Sysmon 22 query with DGA-shaped SLD.",
                evidence=ev, timestamp=ev.get("UtcTime"),
                tags=["T1568.002", "c2"],
            ))

    # -- Account lockouts -------------------------------------------

    def _investigate_account_lockout(self) -> None:
        locked: Dict[str, List[Dict[str, Any]]] = {}
        for ev in self.events:
            if ev.get("EventID") != 4740:
                continue
            user = ev.get("TargetUserName") or "?"
            locked.setdefault(user, []).append(ev)
        for user, group in locked.items():
            self.findings.append(Finding(
                source="evtlog", category="auth.lockout",
                title=f"Account locked out: {user} ({len(group)}x)",
                severity=SEV_MED if len(group) == 1 else SEV_HIGH,
                conclusion=(
                    f"Account '{user}' was locked out {len(group)} "
                    "time(s). Lockouts are direct evidence that "
                    "someone is trying to authenticate with wrong "
                    "passwords — the volume of 4625/4771 leading "
                    "into each 4740 is the brute-force evidence."),
                description="4740 account lockout.",
                evidence={"target_user": user, "count": len(group),
                          "last": group[-1].get("TimeCreated")},
                timestamp=group[-1].get("TimeCreated"),
                tags=["T1110", "credential-access"],
            ))


# ---------------------------------------------------------------------------
# Registry artifacts (Amcache, Shimcache, UserAssist).
# ---------------------------------------------------------------------------

class RegistryArtifacts:
    def __init__(self, hive_paths: Dict[str, Optional[Path]],
                 logger: logging.Logger):
        self.hive_paths = hive_paths
        self.logger = logger
        self.results: Dict[str, List[Dict[str, Any]]] = {
            "amcache": [], "shimcache": [], "userassist": []}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, List[Dict[str, Any]]], List[Finding]]:
        try:
            from Registry import Registry
        except ImportError:
            self.logger.warning("python-registry missing")
            return self.results, self.findings
        am = self.hive_paths.get("amcache")
        if _safe_exists(am):
            self._parse_amcache(Registry, am)
        sys_h = self.hive_paths.get("system")
        if _safe_exists(sys_h):
            self._parse_shimcache(Registry, sys_h)
        nt = self.hive_paths.get("ntuser")
        if _safe_exists(nt):
            self._parse_userassist(Registry, nt)
        self._analyze()
        return self.results, self.findings

    def _parse_amcache(self, Registry, path: Path) -> None:
        self.logger.info("Parsing Amcache: %s", path.name)
        try:
            reg = Registry.Registry(str(path))
            for sub in (r"Root\InventoryApplicationFile", r"Root\File"):
                try:
                    key = reg.open(sub)
                except Registry.RegistryKeyNotFoundException:
                    continue
                for k in key.subkeys():
                    entry = {"_subkey": k.name()}
                    for v in k.values():
                        try:
                            entry[v.name()] = v.value()
                        except Exception:
                            entry[v.name()] = "<unreadable>"
                    self.results["amcache"].append(entry)
        except Exception as exc:
            self.logger.warning("  amcache failed: %s", exc)

    def _parse_shimcache(self, Registry, path: Path) -> None:
        self.logger.info("Parsing Shimcache from SYSTEM")
        try:
            reg = Registry.Registry(str(path))
            sel = reg.open("Select")
            current = sel.value("Current").value()
            css = reg.open(
                f"ControlSet{int(current):03d}\\Control\\Session Manager"
                f"\\AppCompatCache")
            blob = css.value("AppCompatCache").value()
        except Exception as exc:
            self.logger.warning("  shimcache failed: %s", exc)
            return
        text = blob.decode("utf-16le", errors="ignore")
        for m in re.finditer(r"[A-Za-z]:\\[^\x00]{4,}?\.(?:exe|dll|sys)",
                             text, flags=re.IGNORECASE):
            self.results["shimcache"].append({"path": m.group(0)})

    def _parse_userassist(self, Registry, path: Path) -> None:
        self.logger.info("Parsing UserAssist: %s", path.name)
        try:
            reg = Registry.Registry(str(path))
            root = reg.open(
                r"Software\Microsoft\Windows\CurrentVersion"
                r"\Explorer\UserAssist")
        except Exception as exc:
            self.logger.warning("  userassist failed: %s", exc)
            return

        def _rot13(s):
            return s.translate(str.maketrans(
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
                "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm"))
        for guid in root.subkeys():
            try:
                cnt = guid.subkey("Count")
            except Registry.RegistryKeyNotFoundException:
                continue
            for v in cnt.values():
                try:
                    data = v.value()
                except Exception:
                    continue
                if not isinstance(data, bytes) or len(data) < 8:
                    continue
                run_count = struct.unpack("<I", data[4:8])[0]
                self.results["userassist"].append({
                    "program": _rot13(v.name()),
                    "run_count": run_count,
                })

    def _analyze(self) -> None:
        for entry in self.results["amcache"]:
            full = str(entry.get("LowerCaseLongPath")
                       or entry.get("Name") or "").lower()
            if full and _path_is_suspicious(full):
                self.findings.append(Finding(
                    source="registry",
                    category="execution.amcache_tempexec",
                    title=f"Amcache: execution from {full}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Amcache confirms binary at '{full}' was executed "
                        "on this host. The path is user-writable, "
                        "consistent with a dropper."),
                    description="Amcache records all executed binaries.",
                    evidence=entry, tags=["T1059"]))
        for entry in self.results["shimcache"]:
            p = entry["path"].lower()
            if _path_is_suspicious(p):
                self.findings.append(Finding(
                    source="registry",
                    category="execution.shimcache_tempexec",
                    title=f"Shimcache: {p}",
                    severity=SEV_LOW,
                    conclusion=(
                        f"Shimcache retained '{p}'. Windows touched the "
                        "binary; combined with Amcache/4688 this "
                        "confirms execution from a transient path."),
                    description="Shimcache execution trace.",
                    evidence=entry, tags=["execution"]))


# ---------------------------------------------------------------------------
# Autoruns (HKLM Run / RunOnce / Winlogon + Services pulled live).
# ---------------------------------------------------------------------------

class AutorunsAnalyzer:
    # Every registry autorun location classic Windows malware uses for
    # persistence. Every one of these should be walked live.
    LIVE_KEYS = [
        # Classic Run keys
        r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run",
        r"HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx",
        r"HKLM\Software\Wow6432Node\Microsoft\Windows"
        r"\CurrentVersion\Run",
        r"HKLM\Software\Wow6432Node\Microsoft\Windows"
        r"\CurrentVersion\RunOnce",
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnceEx",
        # Winlogon shell / userinit hijack
        r"HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon",
        r"HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon",
        # AppInit_DLLs (inject DLL into every user32-linked process)
        r"HKLM\Software\Microsoft\Windows NT\CurrentVersion\Windows",
        r"HKLM\Software\Wow6432Node\Microsoft\Windows NT"
        r"\CurrentVersion\Windows",
        # Shell hooks
        r"HKLM\Software\Microsoft\Windows\CurrentVersion"
        r"\Explorer\SharedTaskScheduler",
        r"HKLM\Software\Microsoft\Windows\CurrentVersion"
        r"\Explorer\ShellExecuteHooks",
    ]

    # Value names that are transient OS/installer state, NOT
    # persistence vectors. Always skip.
    _SKIP_VALUE_NAMES = {
        "pendingfilerenameoperations",
        "pendingfilerenameoperations2",
        "setupexecute", "bootexecute",  # default autochk only
        "allowprotectedrenames",
        "blocksettingsslowdownnotifications",
    }

    # Image File Execution Options — Debugger hijack lives here. Every
    # subkey gets a Debugger value check.
    IFEO_BASE = (r"Software\Microsoft\Windows NT\CurrentVersion"
                 r"\Image File Execution Options")

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.entries, self.findings
        try:
            import winreg
        except ImportError:
            return self.entries, self.findings

        self._enumerate_run_keys(winreg)
        self._enumerate_ifeo(winreg)
        self._enumerate_startup_folders()
        self._analyze()
        self.logger.info(
            "Autoruns: %d entries scanned, %d findings",
            len(self.entries), len(self.findings))
        return self.entries, self.findings

    def _enumerate_run_keys(self, winreg) -> None:
        root_map = {
            "HKLM": winreg.HKEY_LOCAL_MACHINE,
            "HKCU": winreg.HKEY_CURRENT_USER,
        }
        for key_path in self.LIVE_KEYS:
            root_name, subpath = key_path.split("\\", 1)
            root = root_map.get(root_name)
            if root is None:
                continue
            try:
                with winreg.OpenKey(root, subpath) as k:
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(k, i)
                        except OSError:
                            break
                        self.entries.append({
                            "hive": key_path, "name": name,
                            "value": str(value),
                            "category": self._categorize_key(key_path),
                        })
                        i += 1
            except OSError:
                continue

    def _enumerate_ifeo(self, winreg) -> None:
        # Image File Execution Options — any subkey with a "Debugger"
        # value is an IFEO hijack (debugger runs whenever the parent
        # exe is launched). Common attacker persistence / EDR-kill.
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 self.IFEO_BASE) as root:
                i = 0
                while True:
                    try:
                        subname = winreg.EnumKey(root, i)
                    except OSError:
                        break
                    i += 1
                    try:
                        with winreg.OpenKey(root, subname) as sub:
                            try:
                                dbg, _ = winreg.QueryValueEx(
                                    sub, "Debugger")
                                if dbg:
                                    self.entries.append({
                                        "hive": f"HKLM\\{self.IFEO_BASE}"
                                                f"\\{subname}",
                                        "name": "Debugger",
                                        "value": str(dbg),
                                        "category": "ifeo",
                                        "hijacked_image": subname,
                                    })
                            except FileNotFoundError:
                                pass
                    except OSError:
                        continue
        except OSError:
            pass

    def _enumerate_startup_folders(self) -> None:
        candidates = [
            Path(os.environ.get("APPDATA", ""))
            / "Microsoft" / "Windows" / "Start Menu"
            / "Programs" / "Startup",
            Path(os.environ.get("ProgramData", ""))
            / "Microsoft" / "Windows" / "Start Menu"
            / "Programs" / "StartUp",
        ]
        for folder in candidates:
            if not folder.exists():
                continue
            for item in folder.iterdir():
                try:
                    self.entries.append({
                        "hive": str(folder),
                        "name": item.name,
                        "value": str(item.resolve()),
                        "category": "startup-folder",
                        "mtime": dt.datetime.fromtimestamp(
                            item.stat().st_mtime,
                            tz=dt.timezone.utc).isoformat(),
                    })
                except (OSError, PermissionError):
                    continue

    @staticmethod
    def _categorize_key(key_path: str) -> str:
        kp = key_path.lower()
        if "runonce" in kp:
            return "runonce"
        if "\\run" in kp:
            return "run"
        if "winlogon" in kp:
            return "winlogon"
        if "\\windows" in kp and "currentversion" in kp:
            return "appinit"
        if "sharedtaskscheduler" in kp or "shellexecutehooks" in kp:
            return "shell-hook"
        if "session manager" in kp:
            return "session-manager"
        return "other"

    def _analyze(self) -> None:
        for e in self.entries:
            v = (e.get("value") or "").lower()
            name = (e.get("name") or "")
            cat = e.get("category")
            if name.lower() in self._SKIP_VALUE_NAMES:
                continue

            # --- IFEO hijack (any Debugger value) -------------------
            if cat == "ifeo":
                hijacked = e.get("hijacked_image")
                is_bad = True
                # Verifier.exe / GFlags legit users still reach here
                # but they are admin-policy tools — flag at High, not
                # Critical, unless the debugger is in a user path.
                sev = (SEV_CRIT if _path_is_suspicious(v) or
                       _has_encoded_cmd(v) else SEV_HIGH)
                self.findings.append(Finding(
                    source="autoruns",
                    category="persistence.ifeo_hijack",
                    title=(f"IFEO Debugger set for "
                           f"'{hijacked}'"),
                    severity=sev,
                    conclusion=(
                        f"Image File Execution Options for "
                        f"'{hijacked}' has a Debugger value "
                        f"('{v[:140]}'). Whenever '{hijacked}' is "
                        "launched, Windows runs the Debugger instead. "
                        "This is a classic persistence + AV-kill trick "
                        "(target legitimate security tools) and a "
                        "known sticky-key backdoor primitive."),
                    description="IFEO Debugger hijack.",
                    evidence=e,
                    tags=["T1546.012", "persistence"]))
                continue

            # --- Encoded command in an autorun --------------------
            if _has_encoded_cmd(v):
                self.findings.append(Finding(
                    source="autoruns",
                    category="persistence.run_encoded",
                    title=f"Encoded autorun: {name} ({cat})",
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Autorun entry '{name}' in '{e['hive']}' "
                        f"executes an encoded / hidden command "
                        f"('{e['value'][:140]}'). This is malware "
                        "persistence — encoded autoruns do not exist "
                        "in legitimate installers."),
                    description="Encoded PowerShell / hidden invocation "
                                "in autorun.",
                    evidence=e,
                    tags=["T1547.001", "persistence"]))
                continue

            # --- Suspicious path ---------------------------------
            if _path_is_suspicious(v):
                self.findings.append(Finding(
                    source="autoruns",
                    category="persistence.run_tempexec",
                    title=f"Autorun from transient path: {name} ({cat})",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Autorun '{name}' under '{e['hive']}' points "
                        f"at '{e['value']}'. Legitimate autoruns do "
                        "not launch from TEMP / AppData / Public. "
                        "Triage the binary before allowing it to "
                        "persist."),
                    description="Autorun binary in user-writable path.",
                    evidence=e,
                    tags=["T1547.001", "persistence"]))
                continue

            # --- Winlogon Userinit / Shell tampering ----------------
            if cat == "winlogon" and name.lower() in (
                    "userinit", "shell"):
                default_userinit = r"c:\windows\system32\userinit.exe"
                default_shell = "explorer.exe"
                expected = (default_userinit if name.lower() ==
                            "userinit" else default_shell)
                if expected not in v:
                    self.findings.append(Finding(
                        source="autoruns",
                        category="persistence.winlogon_hijack",
                        title=f"Winlogon {name} hijacked",
                        severity=SEV_CRIT,
                        conclusion=(
                            f"Winlogon '{name}' value is '{e['value']}' "
                            f"(expected '{expected}'). Modified Userinit "
                            "or Shell values persist an attacker-"
                            "controlled process at every user logon "
                            "— a top-tier Windows persistence mechanism."),
                        description="Non-default Winlogon Userinit/Shell.",
                        evidence=e,
                        tags=["T1547.004", "persistence"]))

            # --- AppInit_DLLs tampering -----------------------------
            if cat == "appinit" and name.lower() == "appinit_dlls" \
                    and v.strip():
                self.findings.append(Finding(
                    source="autoruns",
                    category="persistence.appinit_dll",
                    title="AppInit_DLLs populated",
                    severity=SEV_CRIT,
                    conclusion=(
                        f"AppInit_DLLs = '{e['value']}'. Any DLL "
                        "listed here is forcibly loaded into every "
                        "user32-linked process on the host — a "
                        "global DLL injection primitive. Rarely used "
                        "by legitimate software on modern Windows."),
                    description="AppInit_DLLs non-empty.",
                    evidence=e,
                    tags=["T1546.010", "persistence"]))


# ---------------------------------------------------------------------------
# BAM / DAM (Background / Desktop Activity Moderator).
# ---------------------------------------------------------------------------

class BAMAnalyzer:
    """
    HKLM\\SYSTEM\\CurrentControlSet\\Services\\bam\\State\\UserSettings\\<SID>
    (or ...\\dam\\...) holds a value per executable path that was
    run under the user, with a QWORD FILETIME as last-run timestamp.
    Critical for post-incident reconstruction: shows every program
    that ran and when, even after prefetch has aged out.
    """

    def __init__(self, system_hive: Optional[Path],
                 logger: logging.Logger):
        self.system_hive = system_hive
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if self.system_hive is None \
                or not _safe_exists(self.system_hive):
            return self.entries, self.findings
        try:
            from Registry import Registry
        except ImportError:
            return self.entries, self.findings
        try:
            reg = Registry.Registry(str(self.system_hive))
        except Exception as exc:
            self.logger.warning("BAM: hive load failed: %s", exc)
            return self.entries, self.findings

        candidates = []
        for cur in ("ControlSet001", "ControlSet002",
                     "CurrentControlSet"):
            for svc in ("bam", "dam"):
                candidates.append(f"{cur}\\Services\\{svc}"
                                   f"\\State\\UserSettings")
                candidates.append(f"{cur}\\Services\\{svc}"
                                   f"\\UserSettings")
        seen_paths = set()
        for subpath in candidates:
            try:
                key = reg.open(subpath)
            except Exception:
                continue
            for sid_key in key.subkeys():
                sid = sid_key.name()
                for v in sid_key.values():
                    name = v.name()
                    if name in ("Version", "SequenceNumber"):
                        continue
                    try:
                        data = v.value()
                    except Exception:
                        continue
                    ts = None
                    if isinstance(data, bytes) and len(data) >= 8:
                        raw = struct.unpack("<Q", data[:8])[0]
                        ts = _filetime_to_iso(raw)
                    if name in seen_paths:
                        continue
                    seen_paths.add(name)
                    self.entries.append({
                        "sid": sid, "path": name, "last_run": ts,
                    })
        self._analyze()
        self.logger.info("BAM/DAM: %d entries, %d findings",
                         len(self.entries), len(self.findings))
        return self.entries, self.findings

    def _analyze(self) -> None:
        for e in self.entries:
            path = (e.get("path") or "").lower()
            if _path_is_suspicious(path):
                self.findings.append(Finding(
                    source="bam", category="execution.bam_tempexec",
                    title=f"BAM: execution from transient path "
                          f"({Path(path).name})",
                    severity=SEV_MED,
                    conclusion=(
                        f"BAM recorded execution of '{e['path']}' on "
                        f"{e.get('last_run')}. The path is user-"
                        "writable, consistent with a dropper. BAM "
                        "records the OS's own view of every run "
                        "binary and survives after prefetch ages out."),
                    description="BAM entry for binary in transient path.",
                    evidence=e, timestamp=e.get("last_run"),
                    tags=["T1059", "execution"],
                ))


# ---------------------------------------------------------------------------
# SRUM (System Resource Usage Monitor) — stub.
# ---------------------------------------------------------------------------
# Full SRUM parsing requires an ESE/JET database reader (libesedb or
# dissect.esedb). Bundling one is out of scope for this file; the
# analyzer below reports whether SRUDB.dat is present and its size so
# the responder knows to run a dedicated tool (srum-dump, dissect) in
# follow-up.

class SRUMAnalyzer:
    def __init__(self, logger: logging.Logger,
                 override_path: Optional[Path] = None):
        self.logger = logger
        self.path = override_path or Path(
            r"C:\Windows\System32\SRU\SRUDB.dat")
        self.entries: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if not _safe_exists(self.path):
            return self.entries, self.findings
        try:
            size = self.path.stat().st_size
        except (OSError, PermissionError):
            return self.entries, self.findings
        self.entries = {"path": str(self.path), "size": size}
        self.findings.append(Finding(
            source="srum", category="srum.available",
            title=f"SRUM database present ({size / 1024 / 1024:.0f} MB)",
            severity=SEV_INFO,
            conclusion=(
                "SRUDB.dat is available on this host. SRUM keeps ~60 "
                "days of per-process network bytes, energy usage, "
                "application usage and push-notification activity — "
                "an IR goldmine especially when prefetch has aged "
                "out. Full parsing is out of scope for this tool "
                "(ESE/JET reader required); run a dedicated tool "
                "(srum-dump, dissect-esedb, KAPE) against the path "
                "in evidence."),
            description="SRUDB.dat presence report.",
            evidence=self.entries,
            tags=["srum", "follow-up"]))
        return self.entries, self.findings


# ---------------------------------------------------------------------------
# WMI Event Subscription persistence (__EventFilter + *EventConsumer).
# ---------------------------------------------------------------------------

class WMIPersistenceAnalyzer:
    """
    WMI event-subscription persistence is classic APT tradecraft
    (APT29, FIN7, equation-group-level actors) — a filter watches
    for a trigger (login, interval, file write) and a consumer runs
    a command. It survives reboots, hides from autoruns, and lives
    entirely outside the registry HKLM\\Run world.

    We enumerate __EventFilter, __EventConsumer, __FilterToConsumerBinding
    objects in the root\\subscription namespace via PowerShell.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: Dict[str, List[Dict[str, Any]]] = {
            "filters": [], "consumers": [], "bindings": []}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, List[Dict[str, Any]]],
                            List[Finding]]:
        if os.name != "nt":
            return self.entries, self.findings
        ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not ps:
            return self.entries, self.findings
        # Use ConvertTo-Json so we get structured output
        script = (
            "$out = @{};"
            "$out.filters = @(Get-WmiObject -Namespace root\\subscription "
            "-Class __EventFilter -ErrorAction SilentlyContinue | "
            "Select-Object Name,Query,QueryLanguage,EventNamespace);"
            "$out.consumers = @(Get-WmiObject -Namespace root\\subscription "
            "-Class __EventConsumer -ErrorAction SilentlyContinue | "
            "Select-Object __CLASS,Name,CommandLineTemplate,"
            "ExecutablePath,ScriptText,ScriptingEngine);"
            "$out.bindings = @(Get-WmiObject -Namespace root\\subscription "
            "-Class __FilterToConsumerBinding -ErrorAction SilentlyContinue | "
            "Select-Object Filter,Consumer);"
            "$out | ConvertTo-Json -Depth 4 -Compress"
        )
        try:
            result = subprocess.run(
                [ps, "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=60)
        except (subprocess.TimeoutExpired, OSError) as exc:
            self.logger.debug("WMI enumeration failed: %s", exc)
            return self.entries, self.findings

        try:
            data = json.loads(result.stdout or "{}")
        except json.JSONDecodeError:
            return self.entries, self.findings

        def _norm(x):
            if x is None:
                return []
            if isinstance(x, list):
                return x
            return [x]

        self.entries["filters"] = _norm(data.get("filters"))
        self.entries["consumers"] = _norm(data.get("consumers"))
        self.entries["bindings"] = _norm(data.get("bindings"))
        self._analyze()
        self.logger.info(
            "WMI persistence: %d filter(s), %d consumer(s), "
            "%d binding(s), %d findings",
            len(self.entries["filters"]),
            len(self.entries["consumers"]),
            len(self.entries["bindings"]),
            len(self.findings))
        return self.entries, self.findings

    _BENIGN_CONSUMER_NAME_PREFIX = (
        "bvtconsumer",  # Windows testing
        "scm event log consumer",
        "bvtfilter",
    )

    def _analyze(self) -> None:
        for c in self.entries["consumers"]:
            klass = (c.get("__CLASS") or "").lower()
            name = (c.get("Name") or "")
            # Skip well-known Windows SCM defaults
            if any(name.lower().startswith(p)
                   for p in self._BENIGN_CONSUMER_NAME_PREFIX):
                continue
            action = (c.get("CommandLineTemplate")
                      or c.get("ExecutablePath")
                      or c.get("ScriptText") or "")
            if not action:
                continue
            low = str(action).lower()
            is_scriptlike = (klass == "activescripteventconsumer"
                             or "scripttext" in str(c).lower())
            is_suspicious = (_has_encoded_cmd(low)
                             or _path_is_suspicious(low)
                             or is_scriptlike
                             or "powershell" in low
                             or "mshta" in low)
            sev = SEV_CRIT if is_suspicious else SEV_HIGH
            self.findings.append(Finding(
                source="wmi",
                category="persistence.wmi_subscription",
                title=(f"WMI event consumer: {name}"
                       + (" (scripted)" if is_scriptlike else "")),
                severity=sev,
                conclusion=(
                    f"A WMI event-subscription consumer named '{name}' "
                    f"(class '{klass}') is registered to run "
                    f"'{str(action)[:160]}'. WMI subscriptions are "
                    "a top-shelf APT persistence mechanism: they "
                    "survive reboots, are invisible to the classic "
                    "autoruns view, and execute whenever the paired "
                    "filter fires. Unless the security team "
                    "registered this, remove it immediately."),
                description="__EventConsumer registered in "
                            "root\\subscription.",
                evidence=c, tags=["T1546.003", "persistence"],
            ))


# ---------------------------------------------------------------------------
# Windows Defender tamper detection (live).
# ---------------------------------------------------------------------------

class DefenderAnalyzer:
    """
    Attackers routinely add exclusions to Windows Defender or disable
    it outright. We read the running configuration via Get-MpPreference
    and the tamper-relevant registry values.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        ps = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not ps:
            return self.state, self.findings
        # Split preference and status queries so one failing doesn't
        # kill the other. Also: import the Defender module explicitly
        # (in some session contexts it's not auto-loaded).
        script = r"""
$ErrorActionPreference = 'SilentlyContinue'
Import-Module Defender -ErrorAction SilentlyContinue
$p = Get-MpPreference
$s = Get-MpComputerStatus
$result = [ordered]@{}
if ($p) {
    foreach ($prop in 'DisableRealtimeMonitoring','DisableBehaviorMonitoring',
                      'DisableIOAVProtection','DisableScriptScanning',
                      'DisableBlockAtFirstSeen','MAPSReporting',
                      'SubmitSamplesConsent','ExclusionPath',
                      'ExclusionProcess','ExclusionExtension') {
        if ($p.PSObject.Properties[$prop]) {
            $result[$prop] = $p.$prop
        }
    }
}
if ($s) {
    foreach ($prop in 'AntivirusEnabled','RealTimeProtectionEnabled',
                      'AMServiceEnabled','OnAccessProtectionEnabled',
                      'IoavProtectionEnabled','IsTamperProtected',
                      'AntispywareEnabled','BehaviorMonitorEnabled',
                      'NISEnabled','AMProductVersion','AMEngineVersion') {
        if ($s.PSObject.Properties[$prop]) {
            $result[$prop] = $s.$prop
        }
    }
}
$result | ConvertTo-Json -Depth 3 -Compress
"""
        try:
            result = subprocess.run(
                [ps, "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=45)
        except (subprocess.TimeoutExpired, OSError):
            return self.state, self.findings
        out = (result.stdout or "").strip()
        if not out:
            self.logger.debug("Defender: empty PS output; stderr=%s",
                              (result.stderr or "")[:200])
            return self.state, self.findings
        try:
            self.state = json.loads(out)
        except json.JSONDecodeError:
            self.logger.debug("Defender: non-JSON output: %s",
                              out[:200])
            return self.state, self.findings
        # Normalize list-like fields that PS collapses to scalar when
        # they contain a single item.
        for k in ("ExclusionPath", "ExclusionProcess",
                   "ExclusionExtension"):
            v = self.state.get(k)
            if v is None:
                self.state[k] = []
            elif not isinstance(v, list):
                self.state[k] = [v]
        self._analyze()
        self.logger.info(
            "Defender: AV=%s RTP=%s Tamper=%s Excl=%d path / %d proc",
            self.state.get("AntivirusEnabled"),
            self.state.get("RealTimeProtectionEnabled"),
            self.state.get("IsTamperProtected"),
            len(self.state.get("ExclusionPath") or []),
            len(self.state.get("ExclusionProcess") or []))
        return self.state, self.findings

    def _analyze(self) -> None:
        s = self.state
        # --- RTP / AV disabled ---------------------------------
        if s.get("AntivirusEnabled") is False \
                and not self._other_av_present(s):
            self.findings.append(Finding(
                source="defender", category="defender.av_disabled",
                title="Windows Defender AntivirusEnabled = False",
                severity=SEV_HIGH,
                conclusion=(
                    "Windows Defender Antivirus reports "
                    "AntivirusEnabled=False and no third-party AV is "
                    "registered on this host. The endpoint is unshielded "
                    "— either through administrative policy or as an "
                    "attacker-driven tamper."),
                description="Get-MpComputerStatus.AntivirusEnabled.",
                evidence=s, tags=["T1562.001", "defense-evasion"]))
        if s.get("DisableRealtimeMonitoring") is True:
            self.findings.append(Finding(
                source="defender", category="defender.rtp_disabled",
                title="Defender real-time protection disabled",
                severity=SEV_HIGH,
                conclusion=(
                    "DisableRealtimeMonitoring=True. Real-time scanning "
                    "is OFF. This is a common attacker step "
                    "(Set-MpPreference -DisableRealtimeMonitoring "
                    "$true) before dropping a payload."),
                description="Get-MpPreference.DisableRealtimeMonitoring.",
                evidence=s, tags=["T1562.001", "defense-evasion"]))
        if s.get("DisableScriptScanning") is True:
            self.findings.append(Finding(
                source="defender", category="defender.script_disabled",
                title="Defender script scanning disabled",
                severity=SEV_HIGH,
                conclusion=(
                    "AMSI / script-scanning is disabled. PowerShell, "
                    "JScript and VBS will run unexamined — a precondition "
                    "for in-memory script malware."),
                description="DisableScriptScanning=True.",
                evidence=s, tags=["T1562.001", "defense-evasion"]))
        if s.get("IsTamperProtected") is False:
            # Informational: just means tamper protection is off by
            # configuration. Not automatically malicious.
            self.findings.append(Finding(
                source="defender", category="defender.tamper_off",
                title="Defender tamper protection is OFF",
                severity=SEV_LOW,
                conclusion=(
                    "Tamper Protection is not enabled. Enabling it "
                    "prevents local admins (and malware running as "
                    "admin) from silencing Defender via PowerShell or "
                    "registry. Recommend enabling organization-wide."),
                description="Get-MpComputerStatus.IsTamperProtected.",
                evidence=s, tags=["defender", "hardening"]))

        # --- Exclusions ---------------------------------------
        for path in (s.get("ExclusionPath") or []):
            low = str(path).lower()
            if _path_is_suspicious(low) or low in (
                    "c:\\", "c:\\users", "c:\\programdata"):
                sev = SEV_CRIT if _path_is_suspicious(low) else SEV_HIGH
                self.findings.append(Finding(
                    source="defender",
                    category="defender.exclusion_path",
                    title=f"Suspicious Defender exclusion: {path}",
                    severity=sev,
                    conclusion=(
                        f"Defender has '{path}' on its path-exclusion "
                        "list. Files inside this directory are never "
                        "scanned. Attackers add such exclusions before "
                        "dropping their payload so it never lights up."),
                    description="Get-MpPreference.ExclusionPath.",
                    evidence={"exclusion": path},
                    tags=["T1562.001", "defense-evasion"]))
        for proc in (s.get("ExclusionProcess") or []):
            low = str(proc).lower()
            name = Path(low).name
            if name in ("powershell.exe", "pwsh.exe", "cmd.exe",
                         "wscript.exe", "cscript.exe", "mshta.exe",
                         "rundll32.exe", "regsvr32.exe"):
                self.findings.append(Finding(
                    source="defender",
                    category="defender.exclusion_process",
                    title=f"LOLBin excluded in Defender: {name}",
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Defender is configured to skip scanning when "
                        f"'{name}' runs. Every LOLBin excluded is an "
                        "attacker-enabled covert-execution primitive. "
                        "No legitimate policy excludes these from AV."),
                    description="Get-MpPreference.ExclusionProcess.",
                    evidence={"exclusion": proc},
                    tags=["T1562.001", "defense-evasion"]))

    @staticmethod
    def _other_av_present(s: Dict[str, Any]) -> bool:
        # Best-effort: Defender disabling itself in favor of 3rd-party
        # AV is a normal pattern. We don't try to enumerate WMI
        # AntiVirusProduct (the user may not have admin on all systems).
        return False


# ---------------------------------------------------------------------------
# Registry fingerprint + delta detector.
# ---------------------------------------------------------------------------

class RegistryFingerprintAnalyzer:
    """
    Fingerprint high-value persistence registry locations, save to
    a JSON snapshot, and on next run diff against it. Only entries
    that match malicious-looking heuristics (suspicious path,
    encoded command, IFEO Debugger hijack, Winlogon tamper,
    AppInit_DLLs populated, etc.) are promoted to findings. Silent
    benign adds / removes keep the snapshot fresh for the next
    comparison without drowning the analyst in noise.

    Workflow:
      * Run #1 → no prior snapshot → saves current state, emits 0
        findings.
      * Run #2+ → prior snapshot present → diffs, emits findings
        for NEW/CHANGED malicious entries, then overwrites the
        snapshot with the new state.
    """

    # (HKEY, subkey, label, enumerate_values_recursively)
    TRACKED_KEYS: List[Tuple[str, str, str, bool]] = [
        ("HKLM", r"Software\Microsoft\Windows\CurrentVersion\Run",
            "Run (HKLM)", False),
        ("HKLM",
            r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
            "RunOnce (HKLM)", False),
        ("HKLM",
            r"Software\Microsoft\Windows\CurrentVersion\RunOnceEx",
            "RunOnceEx (HKLM)", False),
        ("HKLM", r"Software\Wow6432Node\Microsoft\Windows"
                  r"\CurrentVersion\Run",
            "Run (Wow6432Node)", False),
        ("HKLM", r"Software\Wow6432Node\Microsoft\Windows"
                  r"\CurrentVersion\RunOnce",
            "RunOnce (Wow6432Node)", False),
        ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Run",
            "Run (HKCU)", False),
        ("HKCU",
            r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
            "RunOnce (HKCU)", False),
        ("HKLM", r"Software\Microsoft\Windows NT\CurrentVersion"
                  r"\Winlogon",
            "Winlogon (HKLM)", False),
        ("HKLM", r"Software\Microsoft\Windows NT\CurrentVersion"
                  r"\Windows",
            "AppInit/Windows (HKLM)", False),
        ("HKLM", r"Software\Wow6432Node\Microsoft\Windows NT"
                  r"\CurrentVersion\Windows",
            "AppInit (Wow6432Node)", False),
        ("HKLM", r"Software\Microsoft\Windows\CurrentVersion"
                  r"\Explorer\SharedTaskScheduler",
            "SharedTaskScheduler (HKLM)", False),
        ("HKLM", r"Software\Microsoft\Windows\CurrentVersion"
                  r"\Explorer\ShellExecuteHooks",
            "ShellExecuteHooks (HKLM)", False),
    ]

    # Image File Execution Options — iterate subkeys, check Debugger
    IFEO_BASE = (r"Software\Microsoft\Windows NT\CurrentVersion"
                 r"\Image File Execution Options")

    # Values under Winlogon whose absence / modification matters
    WINLOGON_BASELINE = {
        "userinit": "userinit.exe",
        "shell": "explorer.exe",
    }

    def __init__(self, workdir: Path, logger: logging.Logger,
                 snapshot_path: Optional[Path] = None):
        self.workdir = workdir
        self.logger = logger
        self.snapshot_path = (snapshot_path
                               or workdir / "registry-snapshot.json")
        self.state: Dict[str, Dict[str, Any]] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        try:
            current = self._collect_current()
        except Exception as exc:
            self.logger.debug("registry fingerprint failed: %s", exc)
            return self.state, self.findings
        baseline = self._load_baseline()
        baseline_ts = (baseline.get("timestamp") or "unknown") \
            if baseline else None
        if baseline:
            self._diff(baseline.get("entries", {}), current,
                        baseline_ts)
        self._save_snapshot(current)
        self.state = {"entries": current, "snapshot_path":
                       str(self.snapshot_path),
                       "baseline_timestamp": baseline_ts}
        self.logger.info(
            "Registry fingerprint: %d keys tracked, baseline=%s, "
            "%d malicious diffs",
            len(current), baseline_ts or "none",
            len(self.findings))
        return self.state, self.findings

    # -- Snapshot IO -------------------------------------------------

    def _load_baseline(self) -> Optional[Dict[str, Any]]:
        if not _safe_exists(self.snapshot_path):
            return None
        try:
            return json.loads(
                self.snapshot_path.read_text(encoding="utf-8"))
        except (OSError, PermissionError, json.JSONDecodeError):
            return None

    def _save_snapshot(self, current: Dict[str, Any]) -> None:
        data = {
            "format": 1,
            "timestamp": _iso(_now_utc()),
            "host": platform.node(),
            "entries": current,
        }
        try:
            self.snapshot_path.parent.mkdir(parents=True,
                                              exist_ok=True)
            self.snapshot_path.write_text(
                json.dumps(data, indent=2, default=str),
                encoding="utf-8")
        except (OSError, PermissionError) as exc:
            self.logger.debug("snapshot write failed: %s", exc)

    # -- State collection -------------------------------------------

    def _collect_current(self) -> Dict[str, Dict[str, str]]:
        try:
            import winreg
        except ImportError:
            return {}
        root_map = {"HKLM": winreg.HKEY_LOCAL_MACHINE,
                     "HKCU": winreg.HKEY_CURRENT_USER}

        out: Dict[str, Dict[str, str]] = {}
        # Regular tracked keys
        for hive, sub, label, _ in self.TRACKED_KEYS:
            root = root_map.get(hive)
            if root is None:
                continue
            path = f"{hive}\\{sub}"
            out[path] = {}
            try:
                with winreg.OpenKey(root, sub) as k:
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(k, i)
                        except OSError:
                            break
                        out[path][name] = str(value)
                        i += 1
            except OSError:
                continue

        # IFEO — iterate subkeys, only record Debugger values (if set)
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 self.IFEO_BASE) as root_key:
                i = 0
                while True:
                    try:
                        sub_name = winreg.EnumKey(root_key, i)
                    except OSError:
                        break
                    i += 1
                    try:
                        with winreg.OpenKey(root_key, sub_name) as sk:
                            try:
                                dbg, _ = winreg.QueryValueEx(
                                    sk, "Debugger")
                                path = (f"HKLM\\{self.IFEO_BASE}"
                                         f"\\{sub_name}")
                                out.setdefault(path,
                                                {})["Debugger"] = \
                                    str(dbg)
                            except (FileNotFoundError, OSError):
                                pass
                    except OSError:
                        continue
        except OSError:
            pass
        return out

    # -- Diff + malicious filter ------------------------------------

    def _diff(self, base: Dict[str, Dict[str, str]],
              current: Dict[str, Dict[str, str]],
              baseline_ts: str) -> None:
        for path, values in current.items():
            base_values = base.get(path, {})
            for name, data in values.items():
                old = base_values.get(name)
                if old is None:
                    verdict = self._classify(path, name, data,
                                              None)
                    if verdict:
                        self._emit(path, name, data, None,
                                    verdict, baseline_ts,
                                    change_kind="NEW")
                elif old != data:
                    verdict = self._classify(path, name, data, old)
                    if verdict:
                        self._emit(path, name, data, old,
                                    verdict, baseline_ts,
                                    change_kind="CHANGED")

    def _classify(self, path: str, name: str, data: str,
                   old: Optional[str]) -> Optional[Dict[str, Any]]:
        """Return {reason, severity, technique} if the entry looks
        malicious, else None. Only malicious-shaped changes become
        findings — benign adds stay silent."""
        low = str(data).lower()
        name_low = name.lower()
        path_low = path.lower()

        # 1. Encoded / hidden PowerShell in the value
        if _has_encoded_cmd(low):
            return {
                "severity": SEV_CRIT,
                "technique": "T1547.001",
                "reason": (
                    "The value launches an encoded or hidden "
                    "command line (-EncodedCommand / -NoProfile / "
                    "IEX downloader cradle). This is the canonical "
                    "shape of in-memory PowerShell malware "
                    "persistence and does not exist in legitimate "
                    "installers."),
            }

        # 2. Binary in a user-writable / transient path
        if _path_is_suspicious(low):
            return {
                "severity": SEV_HIGH,
                "technique": "T1547.001",
                "reason": (
                    "The value launches a binary from a user-"
                    "writable directory (TEMP / AppData / Public "
                    "/ ProgramData user subdir). Legitimate "
                    "autoruns do not persist from these locations."),
            }

        # 3. IFEO Debugger hijack
        if "image file execution options" in path_low \
                and name_low == "debugger":
            return {
                "severity": SEV_CRIT,
                "technique": "T1546.012",
                "reason": (
                    "An IFEO Debugger value was added or changed. "
                    "When the target image is launched, Windows "
                    "runs the Debugger value INSTEAD. Classic "
                    "persistence, AV-killer, and sticky-keys "
                    "backdoor mechanism."),
            }

        # 4. Winlogon Userinit / Shell tampering
        if "winlogon" in path_low and name_low in \
                self.WINLOGON_BASELINE:
            expected = self.WINLOGON_BASELINE[name_low]
            if expected not in low:
                return {
                    "severity": SEV_CRIT,
                    "technique": "T1547.004",
                    "reason": (
                        f"Winlogon '{name}' value no longer "
                        f"contains the default '{expected}'. The "
                        "replaced / appended process will run on "
                        "every interactive logon — top-tier "
                        "Windows persistence."),
                }

        # 5. AppInit_DLLs populated
        if name_low == "appinit_dlls" and low.strip():
            return {
                "severity": SEV_CRIT,
                "technique": "T1546.010",
                "reason": (
                    "AppInit_DLLs is now populated. Every DLL "
                    "listed is force-loaded into every user32-"
                    "linked process on the host — a global DLL "
                    "injection primitive rarely used by "
                    "legitimate software on modern Windows."),
            }

        # 6. LoadAppInit_DLLs toggled to 1
        if name_low == "loadappinit_dlls" and low.strip() == "1":
            return {
                "severity": SEV_HIGH,
                "technique": "T1546.010",
                "reason": (
                    "LoadAppInit_DLLs was enabled. By itself it "
                    "does not persist anything, but it ENABLES "
                    "the AppInit_DLLs injection mechanism — "
                    "precursor to persistence payload delivery."),
            }

        # 7. RequireSignedAppInit_DLLs toggled to 0
        if name_low == "requiresignedappinit_dlls" \
                and low.strip() == "0":
            return {
                "severity": SEV_HIGH,
                "technique": "T1546.010",
                "reason": (
                    "RequireSignedAppInit_DLLs was disabled — "
                    "unsigned DLLs can now be loaded via AppInit. "
                    "Unambiguous attacker preparation step."),
            }

        return None

    def _emit(self, path: str, name: str, data: str,
              old: Optional[str], verdict: Dict[str, Any],
              baseline_ts: str, change_kind: str) -> None:
        title = (f"{change_kind} registry entry: "
                 f"{path.split(chr(92))[-1]} \\ {name}")
        conclusion_parts = [
            (f"Since the baseline snapshot at "
             f"{baseline_ts}, a {change_kind} value was detected:"),
            f"    Location: {path}\\{name}",
            f"    New data: '{data}'",
        ]
        if old is not None:
            conclusion_parts.append(
                f"    Previous:  '{old}'")
        conclusion_parts.append("")
        conclusion_parts.append(
            f"Why it matters: {verdict['reason']}")
        self.findings.append(Finding(
            source="regdiff",
            category=(f"persistence.registry_"
                      f"{change_kind.lower()}"),
            title=title,
            severity=verdict["severity"],
            conclusion="\n".join(conclusion_parts),
            description=(
                "Registry-fingerprint delta vs prior snapshot. "
                "Only malicious-shaped changes become findings; "
                "benign adds are silently saved to the new "
                "snapshot."),
            evidence={
                "change_kind": change_kind,
                "registry_path": path,
                "value_name": name,
                "new_data": data,
                "old_data": old,
                "baseline_timestamp": baseline_ts,
                "classification_reason": verdict["reason"],
            },
            timestamp=_iso(_now_utc()),
            tags=[verdict.get("technique", ""),
                  "registry-delta", "persistence"]))


# ---------------------------------------------------------------------------
# Scheduled Tasks (XML under C:\Windows\System32\Tasks).
# ---------------------------------------------------------------------------

class ScheduledTasksAnalyzer:
    def __init__(self, root: Path, logger: logging.Logger):
        self.root = root
        self.logger = logger
        self.tasks: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if not _safe_exists(self.root):
            return self.tasks, self.findings
        for p in self.root.rglob("*"):
            if not p.is_file():
                continue
            try:
                txt = p.read_text(encoding="utf-16", errors="ignore")
                if "<?xml" not in txt and "<Task" not in txt:
                    txt = p.read_text(encoding="utf-8", errors="ignore")
                if "<Task" not in txt:
                    continue
            except (OSError, PermissionError):
                continue
            try:
                root = ET.fromstring(txt)
            except ET.ParseError:
                continue
            ns = "{http://schemas.microsoft.com/windows/2004/02/mit/task}"
            author_el = root.find(f"{ns}RegistrationInfo/{ns}Author")
            author = author_el.text if author_el is not None else None
            actions = root.find(f"{ns}Actions")
            cmds: List[str] = []
            if actions is not None:
                for a in actions.iter():
                    if a.tag.endswith("Command") and a.text:
                        cmds.append(a.text)
                    if a.tag.endswith("Arguments") and a.text:
                        cmds.append(a.text)
            rec = {
                "path": str(p.relative_to(self.root)),
                "author": author,
                "commands": cmds,
            }
            self.tasks.append(rec)

        self._analyze()
        self.logger.info("Scheduled tasks: %d scanned, %d findings",
                         len(self.tasks), len(self.findings))
        return self.tasks, self.findings

    def _analyze(self) -> None:
        for t in self.tasks:
            blob = " ".join(t.get("commands") or []).lower()
            if not blob:
                continue
            if _has_encoded_cmd(blob):
                self.findings.append(Finding(
                    source="schtask",
                    category="persistence.schtask_encoded",
                    title=f"Task with encoded command: {t['path']}",
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Scheduled task '{t['path']}' executes an "
                        "encoded / hidden command. Malicious persistence "
                        "via scheduler."),
                    description="Encoded PowerShell action.",
                    evidence=t,
                    tags=["T1053.005", "persistence"]))
                continue
            if _path_is_suspicious(blob):
                self.findings.append(Finding(
                    source="schtask",
                    category="persistence.schtask_tempexec",
                    title=f"Task launches from transient path: "
                          f"{t['path']}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Task '{t['path']}' runs a binary from "
                        "TEMP/AppData/Public. No legitimate task uses "
                        "those directories."),
                    description="Task action points into user-writable "
                                "directory.",
                    evidence=t,
                    tags=["T1053.005", "persistence"]))


# ---------------------------------------------------------------------------
# Prefetch (binary format: MAM / SCCA).
# ---------------------------------------------------------------------------

class PrefetchAnalyzer:
    def __init__(self, prefetch_dir: Path, logger: logging.Logger):
        self.prefetch_dir = prefetch_dir
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if not _safe_exists(self.prefetch_dir):
            return self.entries, self.findings
        count = 0
        for p in self.prefetch_dir.glob("*.pf"):
            try:
                with open(p, "rb") as fh:
                    head = fh.read(16)
            except (OSError, PermissionError):
                continue
            # Format detection: uncompressed PF header starts with
            # "SCCA" at offset 4. MAM-compressed starts with 'MAM\x04'.
            compressed = head[:4] == b"MAM\x04"
            name = p.name
            entry = {
                "name": name, "compressed": compressed,
                "size": p.stat().st_size,
                "mtime": dt.datetime.fromtimestamp(
                    p.stat().st_mtime,
                    tz=dt.timezone.utc).isoformat(),
            }
            self.entries.append(entry)
            count += 1
        self._analyze()
        self.logger.info("Prefetch: %d entries, %d findings",
                         count, len(self.findings))
        return self.entries, self.findings

    def _analyze(self) -> None:
        # Prefetch entry name format: <BINARY>-<HASH>.pf
        known_bad_exes = {
            "mimikatz.exe", "procdump.exe", "nanodump.exe",
            "psexec.exe", "psexec64.exe", "rclone.exe",
            "anydesk.exe", "teamviewer.exe", "ngrok.exe",
            "plink.exe", "lazagne.exe", "winpeas.exe",
            "sharphound.exe", "seatbelt.exe",
            "adfind.exe", "bloodhound.exe",
        }
        for e in self.entries:
            base = e["name"].lower()
            # strip trailing -HASH.pf
            stripped = re.sub(r"-[0-9a-f]{8,}\.pf$", "", base)
            exe_name = stripped + ".exe" if not stripped.endswith(".exe") \
                else stripped
            if exe_name in known_bad_exes:
                self.findings.append(Finding(
                    source="prefetch",
                    category="execution.tool_of_interest",
                    title=f"Prefetch records execution of {exe_name}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Prefetch '{e['name']}' proves '{exe_name}' was "
                        f"executed on this host (last run on disk: "
                        f"{e['mtime']}). This binary name is on the "
                        "offensive-tooling / dual-use hotlist — "
                        "investigate who ran it and why."),
                    description="Execution artifact for a hotlisted "
                                "binary name.",
                    evidence=e,
                    timestamp=e["mtime"],
                    tags=["T1059", "tool-of-interest"]))


# ---------------------------------------------------------------------------
# Live process-tree anomaly engine.
# ---------------------------------------------------------------------------

class ProcessTreeAnalyzer:
    """
    Walks live processes and flags parent-child anomalies, suspicious
    working directories, and network-talking transients. Replaces the
    previous `live_triage` one-liner.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.snapshot: Dict[str, Any] = {
            "processes": [], "connections": []}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        try:
            import psutil
        except ImportError:
            return self.snapshot, self.findings

        procs: Dict[int, Dict[str, Any]] = {}
        for p in psutil.process_iter(attrs=["pid", "ppid", "name",
                                              "exe", "cmdline",
                                              "username",
                                              "create_time"]):
            try:
                info = p.info
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            info["create_time_iso"] = dt.datetime.fromtimestamp(
                info.get("create_time") or 0,
                tz=dt.timezone.utc).isoformat()
            procs[info["pid"]] = info
            self.snapshot["processes"].append(info)

        # Resolve parent names
        for pid, p in procs.items():
            parent = procs.get(p.get("ppid"))
            p["parent_name"] = ((parent.get("name") or "").lower()
                                if parent else None)

        # Connections
        conns: List[Dict[str, Any]] = []
        try:
            for c in psutil.net_connections(kind="inet"):
                try:
                    conns.append({
                        "laddr": f"{c.laddr.ip}:{c.laddr.port}"
                                 if c.laddr else None,
                        "raddr": f"{c.raddr.ip}:{c.raddr.port}"
                                 if c.raddr else None,
                        "status": c.status, "pid": c.pid,
                    })
                except AttributeError:
                    continue
        except (psutil.AccessDenied, OSError):
            pass
        self.snapshot["connections"] = conns
        conn_by_pid: Dict[int, List[Dict[str, Any]]] = {}
        for c in conns:
            if c.get("pid"):
                conn_by_pid.setdefault(c["pid"], []).append(c)

        for pid, p in procs.items():
            self._check_process(p, conn_by_pid.get(pid, []))

        self.logger.info("Process tree: %d procs, %d findings",
                         len(procs), len(self.findings))
        return self.snapshot, self.findings

    # Names reserved for Windows system processes. Any process with
    # these names that does NOT execute from System32/SysWOW64 is
    # a masqueraded binary (T1036.005) — an attacker disguising
    # their payload as a trusted Windows process.
    _MASQUERADE_TARGETS = {
        "svchost.exe", "services.exe", "lsass.exe",
        "winlogon.exe", "csrss.exe", "smss.exe",
        "wininit.exe", "spoolsv.exe", "explorer.exe",
        "taskmgr.exe", "conhost.exe", "dwm.exe",
        "lsm.exe", "searchindexer.exe",
    }
    # Note: these are plain (non-raw) strings so "\\" ==> single
    # backslash at runtime, matching real Windows paths.
    _LEGIT_SYSTEM_PATH_PREFIXES = (
        "c:\\windows\\system32\\",
        "c:\\windows\\syswow64\\",
        "\\??\\c:\\windows\\system32\\",
        "\\systemroot\\system32\\",
    )

    def _check_process(self, p: Dict[str, Any],
                       conns: List[Dict[str, Any]]) -> None:
        name = (p.get("name") or "").lower()
        exe = (p.get("exe") or "").lower()
        parent = p.get("parent_name") or ""
        cmdline = " ".join(p.get("cmdline") or [])
        low_cmd = cmdline.lower()

        # Masquerading — reserved Windows process name running from
        # a non-System32 path. Top-tier IoC.
        if name in self._MASQUERADE_TARGETS and exe:
            legit = any(exe.startswith(pre)
                        for pre in self._LEGIT_SYSTEM_PATH_PREFIXES)
            # Special case: explorer.exe is the ONE system process
            # whose legitimate location is C:\Windows\explorer.exe
            # (not System32). Don't flag it there.
            if name == "explorer.exe" and exe in (
                    "c:\\windows\\explorer.exe",
                    "\\??\\c:\\windows\\explorer.exe"):
                legit = True
            if not legit:
                self.findings.append(Finding(
                    source="live",
                    category="proc_tree.masquerade",
                    title=(f"Masqueraded system binary: "
                           f"'{name}' (PID {p.get('pid')})"),
                    severity=SEV_CRIT,
                    conclusion=(
                        f"Process PID {p.get('pid')} is named "
                        f"'{name}' but its executable path is "
                        f"'{exe}'. Legitimate '{name}' binaries "
                        f"live under C:\\Windows\\System32. A "
                        f"non-standard path for a system-reserved "
                        "process name is the canonical fingerprint "
                        "of process-name masquerading — the "
                        "attacker disguises their payload as a "
                        "trusted Windows process to survive casual "
                        "triage."),
                    description="System-name process executing from "
                                "a non-System32 path.",
                    evidence=p,
                    tags=["T1036.005", "masquerade"]))

        # "No exe path" detection: removed — too many legit
        # protected / kernel-adjacent processes (Registry, Secure
        # System, MemCompression, Idle, various system services)
        # can't expose exe without admin rights, producing
        # unavoidable FPs. Re-add with a stricter filter later if
        # we have reliable signal.

        # Parent-child anomalies
        if parent in OFFICE_APPS and name in LOLBINS:
            self.findings.append(Finding(
                source="live", category="proc_tree.office_lolbin",
                title=f"Office app spawned {name} ({parent})",
                severity=SEV_CRIT,
                conclusion=(
                    f"Currently-running PID {p['pid']} ('{name}') is a "
                    f"child of '{parent}'. Macro dropper active right "
                    "now on this host. Kill the process tree and triage "
                    "the source document."),
                description=("Office -> LOLBin live in process tree."),
                evidence=p, tags=["T1059", "macro-dropper"]))
        if parent == "lsass.exe":
            self.findings.append(Finding(
                source="live", category="proc_tree.lsass_child",
                title=f"lsass.exe child: {name}",
                severity=SEV_CRIT,
                conclusion=(
                    f"PID {p['pid']} ('{name}') is running as a child of "
                    "lsass.exe. LSASS does not spawn children normally; "
                    "this is in-memory credential tooling."),
                description="lsass child process.",
                evidence=p, tags=["T1003.001"]))
        if name in ("powershell.exe", "pwsh.exe") and \
                _has_encoded_cmd(low_cmd):
            # Developer-tool context (VSCode, JetBrains, Chocolatey,
            # Scoop) routinely uses -NoProfile / -ExecutionPolicy
            # Bypass. We do NOT silence those — instead we emit at
            # Low severity with an explicit annotation so the analyst
            # can see the full picture without noise polluting the
            # High/Critical lane.
            dev_markers = {
                "\\.vscode\\extensions\\": "VSCode extension",
                "\\.vscode-server\\": "VSCode Server",
                "\\jetbrains\\": "JetBrains IDE",
                "\\chocolatey\\": "Chocolatey package manager",
                "\\scoop\\": "Scoop package manager",
                "windowspowershell\\modules\\pester": "Pester test runner",
                "import-module 'c:\\users\\": "User-scope module import",
                "azureadpreview": "AzureAD PS module",
                "microsoft.graph": "Microsoft Graph PS module",
            }
            matched_context = None
            for m, label in dev_markers.items():
                if m in low_cmd:
                    matched_context = label
                    break
            if matched_context is None:
                self.findings.append(Finding(
                    source="live", category="proc_tree.encoded_ps",
                    title=f"Encoded PowerShell running "
                          f"(PID {p['pid']})",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"PID {p['pid']} runs '{cmdline[:160]}'. "
                        "Encoded / hidden invocation — classic malware "
                        "loader."),
                    description="Encoded PowerShell live.",
                    evidence=p, tags=["T1059.001"]))
            else:
                self.findings.append(Finding(
                    source="live",
                    category="proc_tree.encoded_ps_devtool",
                    title=(f"PowerShell bypass flags in dev-tool "
                           f"context: {matched_context} "
                           f"(PID {p['pid']})"),
                    severity=SEV_LOW,
                    conclusion=(
                        f"PID {p['pid']} runs PowerShell with "
                        "-ExecutionPolicy Bypass / -NoProfile — flags "
                        "commonly used by malware loaders. However the "
                        f"invocation references '{matched_context}' "
                        "which is a legitimate developer-tool "
                        "fingerprint. Recorded at informational level "
                        "for transparency; no action required unless "
                        "the dev-tool context itself is disputed."),
                    description=("Encoded-PowerShell pattern matched "
                                 "but resolved to a known developer-"
                                 "tool context."),
                    evidence={**p, "dev_context": matched_context},
                    tags=["T1059.001", "likely-benign",
                          "dev-tool-context"]))

        # Transient-path exe
        if exe and _path_is_suspicious(exe):
            sev = SEV_HIGH if conns else SEV_MED
            extra = (f" It has {len(conns)} live network connection(s) "
                     "— exfil / C2 suspected." if conns else "")
            self.findings.append(Finding(
                source="live", category="proc_tree.transient_path",
                title=f"Process from transient path: {name}",
                severity=sev,
                conclusion=(f"PID {p['pid']} ('{name}') is executing from "
                            f"'{exe}'.{extra}"),
                description="Running process in user-writable location.",
                evidence={**p, "connections": conns},
                tags=["execution"]))

        # Credential dumping tools by name
        if name in {"mimikatz.exe", "procdump.exe", "nanodump.exe",
                    "lazagne.exe"}:
            self.findings.append(Finding(
                source="live", category="proc_tree.offensive_tool",
                title=f"Offensive tool running: {name}",
                severity=SEV_CRIT,
                conclusion=(
                    f"PID {p['pid']} is '{name}' — a known offensive "
                    "security tool. Unless this is an authorized pentest, "
                    "treat as active intrusion."),
                description="Hotlisted binary live in the process tree.",
                evidence=p, tags=["T1003", "tool-of-interest"]))


# ---------------------------------------------------------------------------
# $MFT triage.
# ---------------------------------------------------------------------------

class MFTAnalyzer:
    RECORD_SIZE = 1024

    def __init__(self, mft_path: Path, logger: logging.Logger,
                 max_records: int = 200_000):
        self.mft_path = mft_path
        self.logger = logger
        self.max_records = max_records
        self.records: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if not _safe_exists(self.mft_path):
            return self.records, self.findings
        self.logger.info("Streaming $MFT: %s", self.mft_path)
        try:
            with open(self.mft_path, "rb") as fh:
                self._parse(fh)
        except OSError as exc:
            self.logger.warning("MFT failed: %s", exc)
        self._analyze()
        return self.records, self.findings

    def _parse(self, fh) -> None:
        count = 0
        while count < self.max_records:
            buf = fh.read(self.RECORD_SIZE)
            if len(buf) < self.RECORD_SIZE:
                break
            if buf[:4] != b"FILE":
                continue
            try:
                rec = self._parse_record(buf)
                if rec:
                    self.records.append(rec)
            except Exception:
                pass
            count += 1

    def _parse_record(self, buf: bytes) -> Optional[Dict[str, Any]]:
        attr_off = struct.unpack_from("<H", buf, 0x14)[0]
        flags = struct.unpack_from("<H", buf, 0x16)[0]
        in_use = bool(flags & 1)
        is_dir = bool(flags & 2)
        offset = attr_off
        name = None
        si: Dict[str, Optional[str]] = {}
        while offset < len(buf) - 8:
            atype = struct.unpack_from("<I", buf, offset)[0]
            if atype == 0xFFFFFFFF:
                break
            length = struct.unpack_from("<I", buf, offset + 4)[0]
            if length == 0:
                break
            noff = struct.unpack_from("<H", buf, offset + 0x14)[0]
            s = offset + noff
            if atype == 0x10 and s + 32 <= len(buf):
                si = {
                    "si_created":  _filetime_to_iso(
                        struct.unpack_from("<Q", buf, s)[0]),
                    "si_modified": _filetime_to_iso(
                        struct.unpack_from("<Q", buf, s + 8)[0]),
                    "si_changed":  _filetime_to_iso(
                        struct.unpack_from("<Q", buf, s + 16)[0]),
                    "si_accessed": _filetime_to_iso(
                        struct.unpack_from("<Q", buf, s + 24)[0]),
                }
            elif atype == 0x30 and s + 0x42 <= len(buf):
                nlen = buf[s + 0x40]
                raw = buf[s + 0x42:s + 0x42 + nlen * 2]
                try:
                    cand = raw.decode("utf-16le", errors="ignore")
                    if not name or len(cand) > len(name):
                        name = cand
                except Exception:
                    pass
            offset += length
        if not name:
            return None
        return {"name": name, "in_use": in_use, "is_dir": is_dir, **si}

    def _analyze(self) -> None:
        sus_ext = (".exe", ".dll", ".sys", ".scr", ".bat",
                   ".ps1", ".vbs", ".js", ".hta")
        for r in self.records:
            n = (r.get("name") or "").lower()
            if any(n.endswith(e) for e in sus_ext) \
                    and _path_is_suspicious(n):
                self.findings.append(Finding(
                    source="mft", category="filesystem.tempexec",
                    title=f"Executable in transient path: {r['name']}",
                    severity=SEV_LOW,
                    conclusion=(
                        f"File '{r['name']}' resides in a transient "
                        f"directory (created {r.get('si_created')}). "
                        "Combined with Amcache / 4688 this becomes a "
                        "dropper artifact."),
                    description="Transient-path executable in MFT.",
                    evidence=r, timestamp=r.get("si_created"),
                    tags=["T1105"]))


# ---------------------------------------------------------------------------
# Correlation engine.
# ---------------------------------------------------------------------------

class CorrelationEngine:
    def __init__(self, mem_res: Dict[str, Any],
                 evt_events: List[Dict[str, Any]],
                 reg_res: Dict[str, List[Dict[str, Any]]],
                 mft_recs: List[Dict[str, Any]],
                 dumps: List[Dict[str, Any]],
                 findings: List[Finding],
                 logger: logging.Logger):
        self.mem_res = mem_res
        self.evt_events = evt_events
        self.reg_res = reg_res
        self.mft_recs = mft_recs
        self.dumps = dumps
        self.findings = findings
        self.logger = logger

    def run(self) -> List[Finding]:
        out: List[Finding] = []
        out += self._mem_vs_disk_log()
        out += self._c2_plus_logclear()
        out += self._credaccess_plus_lolbin()
        out += self._bruteforce_plus_logclear()
        out += self._lsass_dump_plus_lateral()
        return out

    def _mem_vs_disk_log(self) -> List[Finding]:
        out: List[Finding] = []
        suspects: Set[str] = set()
        for f in self.findings:
            if f.source != "memory":
                continue
            ev = f.evidence or {}
            if "process" in ev:
                suspects.add(str(ev["process"]).lower())
            if "name" in ev:
                suspects.add(str(ev["name"]).lower())
        for p in suspects:
            base = Path(p).name
            m4688 = [e for e in self.evt_events
                     if e.get("EventID") == 4688
                     and base in (e.get("NewProcessName") or "").lower()]
            mft = [r for r in self.mft_recs
                   if base in (r.get("name") or "").lower()]
            if m4688 or mft:
                out.append(Finding(
                    source="correlation",
                    category="corr.ram_disk_log",
                    title=f"Suspect '{p}' corroborated across sources",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Memory-flagged process '{p}' also appears in "
                        f"{'logs' if m4688 else ''}"
                        f"{' and ' if m4688 and mft else ''}"
                        f"{'disk' if mft else ''}. This lifts the finding "
                        "from 'anomaly in RAM' to 'provenance-confirmed "
                        "execution on this host'."),
                    description="Triangulation across RAM / log / disk.",
                    evidence={"process": p,
                              "log_events": m4688[:5],
                              "mft_hits": mft[:5]},
                    tags=["correlation", "IoA"]))
        return out

    def _c2_plus_logclear(self) -> List[Finding]:
        hosts = [f.evidence.get("ForeignAddr")
                 for f in self.findings
                 if f.source == "memory"
                 and f.category == "network.c2_artifact"
                 and f.evidence]
        hosts = list({h for h in hosts if h})
        cleared = any(e.get("EventID") == 1102 for e in self.evt_events)
        if hosts and cleared:
            return [Finding(
                source="correlation", category="corr.c2_plus_logclear",
                title="External C2 artifact + audit-log clear",
                severity=SEV_CRIT,
                conclusion=(
                    f"Dormant external sockets to {hosts[:3]} were "
                    "recovered from memory and the Security log was "
                    "cleared on the same image. This is a confirmed "
                    "post-compromise cleanup sequence."),
                description="RAM-resident C2 plus log clear.",
                evidence={"hosts": hosts},
                tags=["IoA", "anti-forensics"])]
        return []

    def _credaccess_plus_lolbin(self) -> List[Finding]:
        if not any(f.category == "credential.lsass_access"
                   for f in self.findings):
            return []
        lolbin_hits = [e for e in self.evt_events
                       if e.get("EventID") == 4688
                       and Path(e.get("NewProcessName") or "").name.lower()
                           in LOLBINS]
        if not lolbin_hits:
            return []
        return [Finding(
            source="correlation",
            category="corr.credaccess_plus_lolbin",
            title="Credential access + LOLBin execution chain",
            severity=SEV_CRIT,
            conclusion=(
                f"LSASS was read from RAM and {len(lolbin_hits)} "
                "LOLBin process-creation events were observed. "
                "Operator-driven credential-dumping stage; lateral "
                "movement is likely imminent."),
            description="Correlated credential + execution IoA.",
            evidence={"lolbin_events": lolbin_hits[:10]},
            tags=["T1003.001", "T1059", "IoA"])]

    def _bruteforce_plus_logclear(self) -> List[Finding]:
        bf_success = [f for f in self.findings
                      if f.category == "auth.bruteforce"
                      and f.evidence.get("success_after_burst")]
        cleared = any(e.get("EventID") == 1102 for e in self.evt_events)
        if bf_success and cleared:
            return [Finding(
                source="correlation",
                category="corr.bruteforce_logclear",
                title="Successful brute-force followed by log-clear",
                severity=SEV_CRIT,
                conclusion=(
                    f"Account '{bf_success[0].evidence.get('target_user')}' "
                    "was brute-forced successfully and the audit log was "
                    "later cleared. Attacker achieved code execution and "
                    "attempted to cover their tracks."),
                description="Brute + log-clear chain.",
                evidence={"user": bf_success[0].evidence.get(
                    "target_user")},
                tags=["IoA", "anti-forensics"])]
        return []

    def _lsass_dump_plus_lateral(self) -> List[Finding]:
        lsass_dump = [d for d in self.dumps
                      if (d.get("process_name") or "").lower()
                          == "lsass.exe"]
        lateral = [f for f in self.findings
                   if f.category == "lateral.smb_service"]
        if lsass_dump and lateral:
            return [Finding(
                source="correlation",
                category="corr.lsass_dump_lateral",
                title="lsass dump present + lateral movement detected",
                severity=SEV_CRIT,
                conclusion=(
                    "A user-mode dump of lsass.exe exists on disk and "
                    "network-logon-to-service-install lateral movement "
                    "was observed on the same host. Credential theft "
                    "followed by pivot — classic ransomware operator "
                    "tradecraft."),
                description="Credential-dump artifact plus lateral.",
                evidence={"lsass_dumps": [d["name"] for d in lsass_dump],
                          "lateral_events": len(lateral)},
                tags=["T1003.001", "T1021.002", "IoA"])]
        return []


# ---------------------------------------------------------------------------
# Windows Defender telemetry (MPLog-*.log).
# ---------------------------------------------------------------------------

class MPLogAnalyzer:
    """
    MPLog records every scan Defender performed, every detection,
    every exclusion that was honored at scan time, and every RTP
    event. Goldmine for "did we ever see this binary before".
    """
    DIR = Path(r"C:\ProgramData\Microsoft\Windows Defender\Support")

    # Lines we care about. Keep the ruleset small and high-signal.
    _RE_DETECT = re.compile(
        r"Detection\s*(?:was\s*added|Type|Source|Name):?\s*(.+)",
        re.IGNORECASE)
    _RE_THREAT = re.compile(
        r"(?:Threat|ThreatName):?\s*([^\r\n,]+)", re.IGNORECASE)
    _RE_EXCLUSION = re.compile(
        r"(?:Exclusion|Excluded)\s*(?:path|process)?:?\s*(.+)",
        re.IGNORECASE)
    _RE_RTP_OFF = re.compile(
        r"(Real-?time\s*protection|RTP)\s*(?:is\s*)?(?:OFF|disabled)",
        re.IGNORECASE)

    def __init__(self, logger: logging.Logger,
                 override_dir: Optional[Path] = None):
        self.dir = override_dir or self.DIR
        self.logger = logger
        self.hits: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if not _safe_exists(self.dir):
            return self.hits, self.findings
        files = sorted(self.dir.glob("MPLog-*.log"))
        total_scanned = 0
        for path in files[-5:]:        # most recent 5 logs is plenty
            try:
                text = path.read_text(
                    encoding="utf-16-le", errors="ignore")
                if "\x00" in text and len(text) < path.stat().st_size / 4:
                    text = path.read_text(
                        encoding="utf-8", errors="ignore")
            except (OSError, PermissionError):
                continue
            total_scanned += len(text.splitlines())
            for line in text.splitlines():
                self._scan_line(line, path.name)
        self.logger.info(
            "MPLog: %d file(s), %d lines scanned, %d findings",
            len(files), total_scanned, len(self.findings))
        return self.hits, self.findings

    def _scan_line(self, line: str, source: str) -> None:
        # Detections
        m = self._RE_DETECT.search(line)
        if m and "Name" in line:
            threat = m.group(1).strip()
            self.hits.append({"kind": "detection", "text": threat,
                              "source_log": source, "line": line[:500]})
            self.findings.append(Finding(
                source="mplog", category="defender.historical_detection",
                title=f"MPLog: prior detection ({threat[:60]})",
                severity=SEV_MED,
                conclusion=(
                    f"MPLog records that Defender previously detected "
                    f"'{threat}'. Even if the detection was handled, "
                    "a prior malware hit on this host is a narrative "
                    "anchor — the incident may not be over."),
                description="Defender MPLog detection entry.",
                evidence={"threat": threat, "source_log": source,
                          "excerpt": line[:400]},
                tags=["defender", "historical-detection"]))
        # Exclusions honored at scan time (attacker-added)
        m = self._RE_EXCLUSION.search(line)
        if m:
            excl = m.group(1).strip()
            low = excl.lower()
            if _path_is_suspicious(low):
                self.findings.append(Finding(
                    source="mplog",
                    category="defender.mplog_exclusion_suspicious",
                    title=f"MPLog: scan skipped under exclusion "
                          f"'{excl[:60]}'",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"MPLog records Defender honoring an exclusion "
                        f"for '{excl}' — a user-writable path. "
                        "Attacker-added path exclusion; the honoring is "
                        "evidence the exclusion was already in place."),
                    description="MPLog exclusion record against "
                                "transient path.",
                    evidence={"exclusion": excl, "source_log": source,
                              "excerpt": line[:400]},
                    tags=["T1562.001", "defense-evasion"]))


# ---------------------------------------------------------------------------
# USB device history (USBSTOR + MountPoints2 + setupapi.dev.log).
# ---------------------------------------------------------------------------

class USBHistoryAnalyzer:
    def __init__(self, system_hive: Optional[Path],
                 ntuser_hive: Optional[Path],
                 logger: logging.Logger):
        self.system_hive = system_hive
        self.ntuser_hive = ntuser_hive
        self.logger = logger
        self.devices: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        try:
            from Registry import Registry
        except ImportError:
            return self.devices, self.findings
        if _safe_exists(self.system_hive):
            self._parse_usbstor(Registry)
        self._parse_setupapi()
        self._analyze()
        self.logger.info("USB history: %d devices, %d findings",
                         len(self.devices), len(self.findings))
        return self.devices, self.findings

    def _parse_usbstor(self, Registry) -> None:
        try:
            reg = Registry.Registry(str(self.system_hive))
        except Exception:
            return
        for cs in ("CurrentControlSet", "ControlSet001",
                    "ControlSet002"):
            try:
                root = reg.open(f"{cs}\\Enum\\USBSTOR")
            except Exception:
                continue
            for vendor in root.subkeys():
                for dev in vendor.subkeys():
                    friendly = None
                    serial = dev.name()
                    try:
                        friendly = dev.value("FriendlyName").value()
                    except Exception:
                        pass
                    self.devices.append({
                        "vendor_product": vendor.name(),
                        "serial": serial,
                        "friendly_name": friendly,
                        "first_installed": _filetime_to_iso(
                            dev.timestamp().timestamp() * 10_000_000
                            + 116444736000000000)
                        if hasattr(dev, "timestamp") else None,
                    })
            break

    def _parse_setupapi(self) -> None:
        # setupapi.dev.log is readable by user on most hosts.
        log = Path(r"C:\Windows\INF\setupapi.dev.log")
        if not log.exists():
            return
        try:
            lines = log.read_text(encoding="utf-8",
                                   errors="ignore").splitlines()
        except OSError:
            return
        cur = None
        for line in lines:
            if ">>>  [Device Install" in line:
                cur = {"raw": line.strip()}
            elif cur is not None and ">>>  Section start" in line:
                m = re.search(r"(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}"
                              r"\.\d+)", line)
                if m:
                    cur["ts"] = m.group(1)
                self.devices.append({
                    "source": "setupapi",
                    "raw": cur.get("raw"),
                    "ts": cur.get("ts")})
                cur = None

    def _analyze(self) -> None:
        if not self.devices:
            return
        self.findings.append(Finding(
            source="usb", category="usb.history_summary",
            title=f"USB device history ({len(self.devices)} records)",
            severity=SEV_INFO,
            conclusion=(
                f"{len(self.devices)} USB/removable device record(s) "
                "were recovered. Each entry is a distinct "
                "vendor+product+serial combination that has ever been "
                "attached. For exfiltration / insider-threat cases, "
                "cross-reference with file-access timelines."),
            description="USBSTOR enum + setupapi.dev.log summary.",
            evidence={"devices": self.devices[:50],
                      "total": len(self.devices)},
            tags=["usb", "media"]))


# ---------------------------------------------------------------------------
# COM hijacking — HKCU overrides of system CLSIDs.
# ---------------------------------------------------------------------------

class COMHijackAnalyzer:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.entries, self.findings
        try:
            import winreg
        except ImportError:
            return self.entries, self.findings

        # For every HKCU\Software\Classes\CLSID\{...}\InprocServer32
        # (or LocalServer32), check: (a) does the same CLSID also
        # exist under HKLM\Software\Classes\CLSID (system definition)?
        # If yes AND HKCU value points at a user-writable DLL, it's a
        # COM hijack.
        try:
            hkcu_clsid = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Classes\CLSID")
        except OSError:
            return self.entries, self.findings

        i = 0
        while True:
            try:
                clsid_name = winreg.EnumKey(hkcu_clsid, i)
            except OSError:
                break
            i += 1
            if not clsid_name.startswith("{"):
                continue
            # Is this CLSID system-defined?
            try:
                with winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        rf"Software\Classes\CLSID\{clsid_name}"):
                    system_defined = True
            except OSError:
                system_defined = False
            for server_sub in ("InprocServer32", "LocalServer32"):
                try:
                    with winreg.OpenKey(
                            hkcu_clsid,
                            f"{clsid_name}\\{server_sub}") as sk:
                        try:
                            default, _ = winreg.QueryValueEx(sk, "")
                        except OSError:
                            continue
                except OSError:
                    continue
                entry = {
                    "clsid": clsid_name,
                    "server": server_sub,
                    "path": str(default),
                    "system_defined": system_defined,
                }
                self.entries.append(entry)
                low = str(default).lower()
                if system_defined and (_path_is_suspicious(low)
                                        or "\\users\\" in low):
                    self.findings.append(Finding(
                        source="com", category="persistence.com_hijack",
                        title=f"COM hijack: HKCU overrides system "
                              f"{clsid_name}",
                        severity=SEV_CRIT,
                        conclusion=(
                            f"HKCU\\Software\\Classes\\CLSID\\"
                            f"{clsid_name}\\{server_sub} = "
                            f"'{default}'. The same CLSID is defined "
                            "system-wide under HKLM, and the user-"
                            "scope override points at a user-writable "
                            "DLL. Whenever a process instantiates "
                            "this COM object, attacker code runs. "
                            "Classic user-mode persistence."),
                        description="HKCU CLSID InprocServer32 "
                                    "override of system CLSID with "
                                    "user-path DLL.",
                        evidence=entry,
                        tags=["T1546.015", "persistence"]))
        self.logger.info("COM hijack: %d HKCU CLSID entries, "
                         "%d findings", len(self.entries),
                         len(self.findings))
        return self.entries, self.findings


# ---------------------------------------------------------------------------
# ETW tampering detection (script-block logging / AMSI / autologger).
# ---------------------------------------------------------------------------

class ETWTamperingAnalyzer:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if os.name != "nt":
            return self.state, self.findings
        try:
            import winreg
        except ImportError:
            return self.state, self.findings
        self._check_psblock(winreg)
        self._check_amsi(winreg)
        self._check_autologger(winreg)
        self.logger.info("ETW tampering: %d findings",
                         len(self.findings))
        return self.state, self.findings

    def _get_val(self, winreg, root, path, name) -> Any:
        try:
            with winreg.OpenKey(root, path) as k:
                return winreg.QueryValueEx(k, name)[0]
        except OSError:
            return None

    def _check_psblock(self, winreg) -> None:
        val = self._get_val(
            winreg, winreg.HKEY_LOCAL_MACHINE,
            r"Software\Policies\Microsoft\Windows\PowerShell"
            r"\ScriptBlockLogging",
            "EnableScriptBlockLogging")
        self.state["PSScriptBlockLogging"] = val
        if val == 0:
            self.findings.append(Finding(
                source="etw", category="etw.psblock_disabled",
                title="PowerShell script-block logging disabled",
                severity=SEV_HIGH,
                conclusion=(
                    "The policy key "
                    "HKLM\\Software\\Policies\\Microsoft\\Windows\\"
                    "PowerShell\\ScriptBlockLogging\\"
                    "EnableScriptBlockLogging = 0. Script-block "
                    "visibility is OFF — attackers routinely flip "
                    "this to run PowerShell payloads without leaving "
                    "4104 artifacts."),
                description="Registry-level PS script-block logging "
                            "disabled.",
                evidence={"value": val},
                tags=["T1562.006", "defense-evasion"]))

    def _check_amsi(self, winreg) -> None:
        # MpPreference controls DisableScriptScanning; also worth
        # checking whether the AMSI provider DLL paths are pointing at
        # attacker-writable locations.
        dis = self._get_val(
            winreg, winreg.HKEY_LOCAL_MACHINE,
            r"Software\Policies\Microsoft\Windows Defender",
            "DisableAntiSpyware")
        self.state["DisableAntiSpyware"] = dis
        if dis == 1:
            self.findings.append(Finding(
                source="etw", category="etw.defender_disabled_policy",
                title="Defender AntiSpyware disabled via policy",
                severity=SEV_HIGH,
                conclusion=(
                    "HKLM\\Software\\Policies\\Microsoft\\"
                    "Windows Defender\\DisableAntiSpyware = 1. "
                    "Defender's anti-spyware engine is OFF at the "
                    "policy level. Valid for some managed fleets but "
                    "high-risk on workstations."),
                description="Policy registry key disables Defender.",
                evidence={"value": dis},
                tags=["T1562.001", "defense-evasion"]))

    def _check_autologger(self, winreg) -> None:
        # The EventLog-Security autologger is a high-value target for
        # tampering — killing it silences the Security channel.
        val = self._get_val(
            winreg, winreg.HKEY_LOCAL_MACHINE,
            r"System\CurrentControlSet\Control\WMI\Autologger"
            r"\EventLog-Security",
            "Start")
        self.state["EventLogSecurity_Autologger_Start"] = val
        if val == 0:
            self.findings.append(Finding(
                source="etw", category="etw.security_autologger_off",
                title="EventLog-Security autologger disabled",
                severity=SEV_CRIT,
                conclusion=(
                    "The EventLog-Security autologger is set to "
                    "Start=0. On next reboot the Security ETW "
                    "channel will not start — the SIEM goes "
                    "blind. This is one of the highest-impact anti-"
                    "forensic actions an attacker can take."),
                description="Autologger start disabled for Security.",
                evidence={"value": val},
                tags=["T1562.002", "defense-evasion"]))


# ---------------------------------------------------------------------------
# WDAC / AppLocker event-log detectors (add channels + inspect).
# ---------------------------------------------------------------------------

WDAC_APPLOCKER_EVTX = [
    r"Microsoft-Windows-CodeIntegrity%4Operational.evtx",
    r"Microsoft-Windows-AppLocker%4EXE and DLL.evtx",
    r"Microsoft-Windows-AppLocker%4MSI and Script.evtx",
]


# ---------------------------------------------------------------------------
# Volume Shadow Copy enumeration.
# ---------------------------------------------------------------------------

class VSSAnalyzer:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.shadows: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.shadows, self.findings
        vssadmin = shutil.which("vssadmin.exe") \
            or r"C:\Windows\System32\vssadmin.exe"
        if not Path(vssadmin).exists():
            return self.shadows, self.findings
        try:
            result = subprocess.run(
                [vssadmin, "list", "shadows"],
                capture_output=True, text=True,
                timeout=30, encoding="cp1252", errors="ignore")
        except (subprocess.TimeoutExpired, OSError):
            return self.shadows, self.findings
        text = result.stdout or ""
        # Parse each shadow block. vssadmin output is verbose but
        # structured enough for regex.
        for block in re.split(r"\r?\n\r?\n", text):
            if "Shadow Copy ID" not in block:
                continue
            entry = {}
            for pat, key in (
                    (r"Shadow Copy ID:\s*({[^}]+})", "id"),
                    (r"Creation time:\s*(.+)", "created"),
                    (r"Original Volume:\s*(.+)", "original_volume"),
                    (r"Shadow Copy Volume:\s*(.+)", "shadow_volume"),
                    (r"Originating Machine:\s*(.+)", "origin"),
                    (r"Provider:\s*(.+)", "provider")):
                m = re.search(pat, block)
                if m:
                    entry[key] = m.group(1).strip()
            if entry:
                self.shadows.append(entry)
        if self.shadows:
            self.findings.append(Finding(
                source="vss", category="vss.enumerated",
                title=f"Volume Shadow Copies available: {len(self.shadows)}",
                severity=SEV_INFO,
                conclusion=(
                    f"{len(self.shadows)} VSS snapshot(s) available "
                    "on this host. Historical versions of key "
                    "forensic files (SYSTEM hive, NTUSER.DAT, "
                    "Amcache.hve, $MFT) can be recovered from these. "
                    "For IR: mount each with mklink and run this "
                    "analyzer against the older state to reconstruct "
                    "the timeline."),
                description="vssadmin list shadows.",
                evidence={"shadows": self.shadows},
                tags=["vss", "follow-up"]))
        self.logger.info("VSS: %d shadow(s)", len(self.shadows))
        return self.shadows, self.findings


# ---------------------------------------------------------------------------
# LNK / JumpList parsing — recent-docs reconstruction.
# ---------------------------------------------------------------------------

class LNKAnalyzer:
    """
    Parses Windows .lnk shortcut files from:
        %APPDATA%\\Microsoft\\Windows\\Recent
        %APPDATA%\\Microsoft\\Office\\Recent
        %APPDATA%\\Microsoft\\Windows\\Recent\\AutomaticDestinations
    Extracts: target path, working dir, arguments, network share,
    MAC timestamps. Maps "what paths did the user touch recently" —
    valuable for exfil / lateral / phishing investigations.
    """
    LNK_MAGIC = b"L\x00\x00\x00"

    # Shell-link header constants
    HAS_LINK_TARGET_IDLIST   = 0x0001
    HAS_LINK_INFO            = 0x0002
    HAS_NAME                 = 0x0004
    HAS_RELATIVE_PATH        = 0x0008
    HAS_WORKING_DIR          = 0x0010
    HAS_ARGUMENTS            = 0x0020
    HAS_ICON_LOCATION        = 0x0040
    IS_UNICODE               = 0x0080

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        roots: List[Path] = []
        appdata = Path(os.environ.get("APPDATA", ""))
        if appdata.exists():
            roots += [
                appdata / "Microsoft" / "Windows" / "Recent",
                appdata / "Microsoft" / "Office" / "Recent",
            ]
        # Per-user Recent paths
        try:
            users_iter = list(Path(r"C:\Users").glob("*"))
        except (OSError, PermissionError):
            users_iter = []
        for user in users_iter:
            try:
                if not user.is_dir():
                    continue
            except (OSError, PermissionError):
                continue
            p = (user / "AppData" / "Roaming" / "Microsoft"
                 / "Windows" / "Recent")
            if _safe_exists(p):
                roots.append(p)
        seen = set()
        for root in roots:
            if root in seen or not root.exists():
                continue
            seen.add(root)
            try:
                for lnk in root.glob("*.lnk"):
                    entry = self._parse_lnk(lnk)
                    if entry:
                        self.entries.append(entry)
            except (OSError, PermissionError):
                continue
        self._analyze()
        self.logger.info("LNK: %d shortcuts parsed, %d findings",
                         len(self.entries), len(self.findings))
        return self.entries, self.findings

    def _parse_lnk(self, path: Path) -> Optional[Dict[str, Any]]:
        try:
            data = path.read_bytes()
        except (OSError, PermissionError):
            return None
        if len(data) < 76 or data[:4] != self.LNK_MAGIC:
            return None
        try:
            link_flags = struct.unpack_from("<I", data, 0x14)[0]
            file_attrs = struct.unpack_from("<I", data, 0x18)[0]
            creation_ft = struct.unpack_from("<Q", data, 0x1C)[0]
            access_ft = struct.unpack_from("<Q", data, 0x24)[0]
            write_ft = struct.unpack_from("<Q", data, 0x2C)[0]
            file_size = struct.unpack_from("<I", data, 0x34)[0]
        except struct.error:
            return None

        offset = 0x4C
        # Skip LinkTargetIDList
        if link_flags & self.HAS_LINK_TARGET_IDLIST:
            if offset + 2 > len(data):
                return None
            idlist_size = struct.unpack_from("<H", data, offset)[0]
            offset += 2 + idlist_size

        local_base_path = None
        common_network_path = None
        if link_flags & self.HAS_LINK_INFO:
            if offset + 4 > len(data):
                return None
            linkinfo_size = struct.unpack_from("<I", data, offset)[0]
            linkinfo = data[offset:offset + linkinfo_size]
            if len(linkinfo) >= 0x20:
                lbp_off = struct.unpack_from("<I", linkinfo, 0x10)[0]
                if 0 < lbp_off < len(linkinfo):
                    end = linkinfo.find(b"\x00", lbp_off)
                    if end > lbp_off:
                        try:
                            local_base_path = linkinfo[
                                lbp_off:end].decode(
                                    "cp1252", errors="ignore")
                        except Exception:
                            pass
                cnp_off = struct.unpack_from("<I", linkinfo, 0x14)[0]
                if 0 < cnp_off < len(linkinfo):
                    end = linkinfo.find(b"\x00", cnp_off)
                    if end > cnp_off:
                        try:
                            nr = linkinfo[cnp_off:end]
                            # Common Network Relative Link is a substruct
                            common_network_path = nr[:200].decode(
                                "cp1252", errors="ignore").strip("\x00")
                        except Exception:
                            pass
            offset += linkinfo_size

        # StringData blocks
        unicode_strings = bool(link_flags & self.IS_UNICODE)
        def _read_string() -> Optional[str]:
            nonlocal offset
            if offset + 2 > len(data):
                return None
            count = struct.unpack_from("<H", data, offset)[0]
            offset += 2
            raw_len = count * (2 if unicode_strings else 1)
            raw = data[offset:offset + raw_len]
            offset += raw_len
            try:
                if unicode_strings:
                    return raw.decode("utf-16-le", errors="ignore")
                return raw.decode("cp1252", errors="ignore")
            except Exception:
                return None

        name = relative_path = working_dir = args = icon_loc = None
        if link_flags & self.HAS_NAME:           name = _read_string()
        if link_flags & self.HAS_RELATIVE_PATH:  relative_path = _read_string()
        if link_flags & self.HAS_WORKING_DIR:    working_dir = _read_string()
        if link_flags & self.HAS_ARGUMENTS:      args = _read_string()
        if link_flags & self.HAS_ICON_LOCATION:  icon_loc = _read_string()

        return {
            "source": str(path),
            "target": local_base_path,
            "network_target": common_network_path,
            "arguments": args,
            "working_dir": working_dir,
            "relative_path": relative_path,
            "name": name,
            "target_created": _filetime_to_iso(creation_ft),
            "target_modified": _filetime_to_iso(write_ft),
            "target_accessed": _filetime_to_iso(access_ft),
            "target_size": file_size,
        }

    def _analyze(self) -> None:
        for e in self.entries:
            # Network share as target = data movement signal
            if e.get("network_target"):
                self.findings.append(Finding(
                    source="lnk", category="data.network_share_lnk",
                    title=f"LNK pointing to network share: "
                          f"{e['network_target'][:60]}",
                    severity=SEV_LOW,
                    conclusion=(
                        f"Recent-docs shortcut '{e.get('name') or e['source']}' "
                        f"points at network share "
                        f"'{e['network_target']}'. Useful pivot "
                        "lead for exfil / lateral investigations."),
                    description="LNK with Common Network Relative Link.",
                    evidence=e, tags=["data", "lateral-movement"]))
                continue
            # Target in transient path
            tgt = (e.get("target") or "").lower()
            if tgt and _path_is_suspicious(tgt):
                self.findings.append(Finding(
                    source="lnk", category="execution.lnk_tempexec",
                    title=f"LNK targets transient path: "
                          f"{Path(tgt).name}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Recent-docs shortcut targets '{tgt}'. User "
                        "was prompted with a file in a user-writable "
                        "path — consistent with a phishing dropper "
                        "the user clicked."),
                    description="LNK with target in TEMP/AppData/Public.",
                    evidence=e, tags=["T1204", "user-execution"]))


# ---------------------------------------------------------------------------
# BITS jobs enumeration (via bitsadmin).
# ---------------------------------------------------------------------------

class BITSAnalyzer:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.jobs: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.jobs, self.findings
        bitsadmin = shutil.which("bitsadmin.exe") \
            or r"C:\Windows\System32\bitsadmin.exe"
        if not Path(bitsadmin).exists():
            return self.jobs, self.findings
        try:
            result = subprocess.run(
                [bitsadmin, "/list", "/allusers", "/verbose"],
                capture_output=True, text=True,
                timeout=60, encoding="cp1252", errors="ignore")
        except (subprocess.TimeoutExpired, OSError):
            return self.jobs, self.findings
        text = result.stdout or ""
        # Each "GUID: {...}" starts a job block.
        blocks = re.split(r"\r?\n(?=GUID:\s*\{)", text)
        for block in blocks:
            if "GUID:" not in block:
                continue
            entry: Dict[str, Any] = {}
            for pat, key in (
                    (r"GUID:\s*(\{[^\}]+\})", "guid"),
                    (r"DISPLAY:\s*'([^']*)'", "display"),
                    (r"TYPE:\s*(\w+)", "type"),
                    (r"STATE:\s*(\w+)", "state"),
                    (r"OWNER:\s*(.+)", "owner"),
                    (r"COMMAND LINE:\s*(.+)", "command"),
                    (r"NOTIFICATION COMMAND LINE:\s*(.+)",
                     "notify_command")):
                m = re.search(pat, block)
                if m:
                    entry[key] = m.group(1).strip()
            # Collect all URLs seen
            urls = re.findall(r"REMOTE URL:\s*(\S+)", block)
            if urls:
                entry["urls"] = urls
            files = re.findall(r"LOCAL FILE:\s*(.+)", block)
            if files:
                entry["local_files"] = [f.strip() for f in files]
            if entry:
                self.jobs.append(entry)
        self._analyze()
        self.logger.info("BITS: %d jobs, %d findings",
                         len(self.jobs), len(self.findings))
        return self.jobs, self.findings

    def _analyze(self) -> None:
        for job in self.jobs:
            state = (job.get("state") or "").upper()
            cmd = job.get("command") or ""
            notify = job.get("notify_command") or ""
            urls = job.get("urls") or []
            files = job.get("local_files") or []
            is_persistent = state in ("SUSPENDED", "TRANSIENT_ERROR",
                                       "ERROR", "QUEUED")
            has_exec_trigger = bool(
                (cmd and cmd.lower() not in ("none", ""))
                or (notify and notify.lower() not in ("none", "")))
            suspicious_url = any(
                u and not ip_is_benign_cloud(
                    re.sub(r"^https?://([^/]+).*", r"\1", u))
                for u in urls
            )
            suspicious_file = any(
                _path_is_suspicious((f or "").lower()) for f in files)

            if has_exec_trigger:
                self.findings.append(Finding(
                    source="bits", category="persistence.bits_job",
                    title=f"BITS job with notification command: "
                          f"{(job.get('display') or job.get('guid'))[:60]}",
                    severity=SEV_HIGH,
                    conclusion=(
                        "BITS job has a notification / completion "
                        f"command configured ('{(cmd or notify)[:120]}'). "
                        "Attackers use BITS jobs with completion "
                        "commands to achieve persistence and to run "
                        "downloaded payloads — this is the classic "
                        "BITSAdmin backdoor pattern."),
                    description="BITS job with post-transfer "
                                "execution trigger.",
                    evidence=job,
                    tags=["T1197", "persistence"]))
            elif suspicious_file or suspicious_url:
                self.findings.append(Finding(
                    source="bits", category="delivery.bits_transient",
                    title=f"BITS job moving to transient path: "
                          f"{(job.get('display') or job.get('guid'))[:60]}",
                    severity=SEV_MED,
                    conclusion=(
                        "BITS job writes to a user-writable location "
                        "or fetches from a non-cloud URL. Worth "
                        f"reviewing: urls={urls[:3]}, files={files[:3]}."),
                    description="BITS transfer profile consistent with "
                                "dropper delivery.",
                    evidence=job,
                    tags=["T1197", "delivery"]))


# ---------------------------------------------------------------------------
# Outlook inbox rules (auto-forward / delete / hidden).
# ---------------------------------------------------------------------------

class OutlookRulesAnalyzer:
    """
    Reads Outlook profile registry for auto-forwarding + inbox-rule
    presence. Deep MAPI / PST parsing is out of scope; this catches
    the 80% of real-world malicious rules by registry fingerprint.
    """
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        if os.name != "nt":
            return self.entries, self.findings
        try:
            import winreg
        except ImportError:
            return self.entries, self.findings
        for version in ("16.0", "15.0", "14.0"):
            try:
                with winreg.OpenKey(
                        winreg.HKEY_CURRENT_USER,
                        rf"Software\Microsoft\Office\{version}"
                        r"\Outlook\Profiles") as profiles:
                    i = 0
                    while True:
                        try:
                            profile_name = winreg.EnumKey(profiles, i)
                        except OSError:
                            break
                        i += 1
                        self.entries.append({
                            "version": version,
                            "profile": profile_name,
                        })
            except OSError:
                continue
        # Check PST files for existence (size / mtime is itself a lead)
        appdata = Path(os.environ.get("LOCALAPPDATA", ""))
        outlook_store = appdata / "Microsoft" / "Outlook"
        if outlook_store.exists():
            for pst in list(outlook_store.glob("*.pst"))[:10]:
                try:
                    st = pst.stat()
                    self.entries.append({
                        "pst_path": str(pst),
                        "size_mb": round(st.st_size / 1024 / 1024, 1),
                        "mtime": dt.datetime.fromtimestamp(
                            st.st_mtime,
                            tz=dt.timezone.utc).isoformat(),
                    })
                except OSError:
                    continue
        self.logger.info("Outlook profiles/PSTs: %d entries",
                         len(self.entries))
        return self.entries, self.findings


# ---------------------------------------------------------------------------
# Chromium password-store status (file existence / DPAPI wrapping).
# ---------------------------------------------------------------------------

class ChromiumPasswordStoreAnalyzer:
    _PRODUCTS = {
        "chrome":  r"Google\Chrome\User Data",
        "edge":    r"Microsoft\Edge\User Data",
        "brave":   r"BraveSoftware\Brave-Browser\User Data",
        "opera":   r"Opera Software\Opera Stable",
    }

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        appdata = Path(os.environ.get("LOCALAPPDATA", ""))
        if not appdata.exists():
            return self.entries, self.findings
        for brand, sub in self._PRODUCTS.items():
            base = appdata / sub
            if not base.exists():
                continue
            local_state = base / "Local State"
            login_db = base / "Default" / "Login Data"
            entry: Dict[str, Any] = {"brand": brand, "base": str(base)}
            if local_state.exists():
                entry["local_state_size"] = local_state.stat().st_size
                entry["local_state_mtime"] = \
                    dt.datetime.fromtimestamp(
                        local_state.stat().st_mtime,
                        tz=dt.timezone.utc).isoformat()
                try:
                    data = json.loads(
                        local_state.read_text(encoding="utf-8"))
                    encrypted_key = data.get("os_crypt", {}).get(
                        "encrypted_key")
                    entry["has_encrypted_key"] = bool(encrypted_key)
                    entry["encrypted_key_len"] = len(encrypted_key
                                                     ) if encrypted_key \
                        else 0
                except (OSError, json.JSONDecodeError):
                    entry["has_encrypted_key"] = None
            if login_db.exists():
                entry["login_db_size"] = login_db.stat().st_size
                entry["login_db_mtime"] = \
                    dt.datetime.fromtimestamp(
                        login_db.stat().st_mtime,
                        tz=dt.timezone.utc).isoformat()
            self.entries.append(entry)
        if self.entries:
            self.findings.append(Finding(
                source="browser",
                category="credential.browser_store_status",
                title=f"Chromium password stores detected "
                      f"({len(self.entries)})",
                severity=SEV_INFO,
                conclusion=(
                    "Chromium-family password stores were found on "
                    "this host. Each 'Local State' file contains a "
                    "DPAPI-wrapped AES key; 'Login Data' SQLite holds "
                    "the ciphertexts. Compare the mtime of these "
                    "files to the incident window — a recent mtime on "
                    "Local State that does not match a browser update "
                    "is an IoC for credential theft."),
                description="Chromium store file inventory.",
                evidence={"stores": self.entries},
                tags=["T1555.003", "browser"]))
        self.logger.info("Chromium stores: %d browsers",
                         len(self.entries))
        return self.entries, self.findings


# ---------------------------------------------------------------------------
# Browser artifacts — history, downloads, cookies (SQLite).
# ---------------------------------------------------------------------------

class BrowserArtifactsAnalyzer:
    """
    Pulls URLs and downloads from Chromium-family and Firefox SQLite
    databases. Files are normally locked by the browser; we copy into
    a temp directory before opening (read-only, immutable).
    """
    def __init__(self, logger: logging.Logger, workdir: Path):
        self.logger = logger
        self.workdir = workdir / "browser"
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.history: List[Dict[str, Any]] = []
        self.downloads: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        import sqlite3
        appdata = Path(os.environ.get("LOCALAPPDATA", ""))
        roaming = Path(os.environ.get("APPDATA", ""))
        targets = []
        for brand, sub in (("chrome", r"Google\Chrome\User Data"),
                           ("edge",   r"Microsoft\Edge\User Data"),
                           ("brave",  r"BraveSoftware\Brave-Browser"
                                      r"\User Data")):
            base = appdata / sub / "Default"
            hist = base / "History"
            if hist.exists():
                targets.append((brand, "chromium", hist))
        # Firefox
        ff_root = roaming / "Mozilla" / "Firefox" / "Profiles"
        if ff_root.exists():
            for prof in ff_root.glob("*"):
                if (prof / "places.sqlite").exists():
                    targets.append(
                        ("firefox", "firefox",
                         prof / "places.sqlite"))
        for brand, kind, db in targets:
            try:
                tmp = self.workdir / f"{brand}-{hash(str(db)) & 0xffff}.sqlite"
                shutil.copy2(db, tmp)
            except (OSError, PermissionError) as exc:
                self.logger.debug("browser: copy %s failed: %s",
                                   db, exc)
                continue
            try:
                con = sqlite3.connect(f"file:{tmp}?mode=ro&immutable=1",
                                       uri=True, timeout=3)
            except sqlite3.Error:
                continue
            try:
                if kind == "chromium":
                    self._pull_chromium(con, brand)
                else:
                    self._pull_firefox(con, brand)
            except sqlite3.Error as exc:
                self.logger.debug("browser: sqlite %s: %s", db, exc)
            finally:
                con.close()
        self._analyze()
        self.logger.info(
            "Browser: %d history rows, %d downloads, %d findings",
            len(self.history), len(self.downloads),
            len(self.findings))
        return ({"history": self.history[:200],
                 "downloads": self.downloads[:200]},
                self.findings)

    def _pull_chromium(self, con, brand: str) -> None:
        # History: urls table
        try:
            cur = con.execute(
                "SELECT url, title, visit_count, last_visit_time "
                "FROM urls ORDER BY last_visit_time DESC LIMIT 500")
            for url, title, vc, lvt in cur:
                self.history.append({
                    "brand": brand, "url": url, "title": title,
                    "visit_count": vc,
                    "last_visit": self._chromium_time(lvt)})
        except Exception:
            pass
        # Downloads table
        try:
            cur = con.execute(
                "SELECT target_path, tab_url, start_time, "
                "total_bytes, mime_type, original_mime_type "
                "FROM downloads ORDER BY start_time DESC LIMIT 500")
            for tp, src, st, total, mime, omime in cur:
                self.downloads.append({
                    "brand": brand, "target_path": tp,
                    "source_url": src,
                    "start": self._chromium_time(st),
                    "size": total,
                    "mime": mime or omime,
                })
        except Exception:
            pass

    def _pull_firefox(self, con, brand: str) -> None:
        try:
            cur = con.execute(
                "SELECT url, title, visit_count, last_visit_date "
                "FROM moz_places ORDER BY last_visit_date DESC "
                "LIMIT 500")
            for url, title, vc, lvt in cur:
                self.history.append({
                    "brand": brand, "url": url, "title": title,
                    "visit_count": vc,
                    "last_visit": self._firefox_time(lvt)})
        except Exception:
            pass

    @staticmethod
    def _chromium_time(x: Optional[int]) -> Optional[str]:
        if not x:
            return None
        try:
            return (dt.datetime(1601, 1, 1, tzinfo=dt.timezone.utc)
                    + dt.timedelta(microseconds=x)).isoformat()
        except (OverflowError, OSError):
            return None

    @staticmethod
    def _firefox_time(x: Optional[int]) -> Optional[str]:
        if not x:
            return None
        try:
            return dt.datetime.fromtimestamp(
                x / 1_000_000, tz=dt.timezone.utc).isoformat()
        except (OverflowError, OSError):
            return None

    # Script / container formats that are almost always malicious when
    # delivered via browser download.
    _BROWSER_HIGH_RISK = (".hta", ".vbs", ".vbe", ".js", ".jse",
                          ".wsf", ".wsh", ".bat", ".ps1", ".psm1",
                          ".cmd", ".lnk", ".scr")
    # Container formats commonly used for HTML-smuggling / ISO-drop.
    _BROWSER_MED_RISK = (".iso", ".img", ".vhd", ".vhdx", ".chm",
                         ".one", ".xll")

    @staticmethod
    def _ip_url_is_private(url: str) -> bool:
        m = re.match(r"^https?://(\d{1,3}(?:\.\d{1,3}){3})(?:[:/]|$)",
                     url)
        if not m:
            return False
        ip = m.group(1)
        if ip.startswith(("127.", "169.254.", "10.",
                          "192.168.", "0.")):
            return True
        if any(ip.startswith(f"172.{i}.")
               for i in range(16, 32)):
            return True
        if ip_is_benign_cloud(ip):
            return True
        return False

    def _analyze(self) -> None:
        # Downloads: ONLY flag scripts/containers. .exe/.msi are
        # normal installer noise — we skip them unless they come
        # from a transient / non-cloud source.
        seen_targets: Set[str] = set()
        for d in self.downloads:
            tp = (d.get("target_path") or "").lower()
            url = (d.get("source_url") or "").lower()
            if not tp or tp in seen_targets:
                continue
            seen_targets.add(tp)
            # Extract domain for cloud-allowlist check
            m = re.match(r"^https?://([^/:]+)", url)
            host = m.group(1) if m else ""
            url_is_cloud = ip_is_benign_cloud(host) if host else False

            high = any(tp.endswith(e) for e in self._BROWSER_HIGH_RISK)
            mid = any(tp.endswith(e) for e in self._BROWSER_MED_RISK)
            if high:
                self.findings.append(Finding(
                    source="browser",
                    category="delivery.browser_script_download",
                    title=f"Script / shortcut downloaded: "
                          f"{Path(tp).name}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Browser ({d.get('brand')}) recorded "
                        f"download of script/shortcut '{tp}' from "
                        f"'{url}' at {d.get('start')}. "
                        "Script / shortcut payloads arriving via "
                        "browser are the canonical first-stage "
                        "phishing payload — triage the file."),
                    description="Browser download with script-family "
                                "extension.",
                    evidence=d,
                    tags=["T1189", "T1204.002", "delivery"]))
            elif mid and not url_is_cloud:
                self.findings.append(Finding(
                    source="browser",
                    category="delivery.browser_container_download",
                    title=f"Container-format download: "
                          f"{Path(tp).name}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Browser downloaded container "
                        f"'{Path(tp).name}' from non-cloud host "
                        f"'{host}' at {d.get('start')}. ISO/IMG/VHD/"
                        "CHM are modern HTML-smuggling payload "
                        "wrappers that bypass MOTW."),
                    description="Container download from non-cloud URL.",
                    evidence=d,
                    tags=["T1027.006", "T1204", "delivery"]))

        # Visits: onion → HIGH; IP-literal URL that is NOT private /
        # localhost / cloud → MED; private IP → skip (dev traffic).
        seen_urls: Set[str] = set()
        for h in self.history:
            url = (h.get("url") or "").lower()
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            if ".onion" in url:
                self.findings.append(Finding(
                    source="browser",
                    category="c2.onion_visit",
                    title=f"Onion domain visited: {url[:80]}",
                    severity=SEV_HIGH,
                    conclusion=(
                        f"Browser recorded visit to onion URL "
                        f"'{url}'. Rare on enterprise endpoints; "
                        "consistent with ransomware payment portals "
                        "or leak sites."),
                    description="History row with .onion URL.",
                    evidence=h,
                    tags=["T1090.003", "c2"]))
            elif re.match(
                    r"^https?://\d{1,3}(?:\.\d{1,3}){3}(?:[:/]|$)",
                    url) and not self._ip_url_is_private(url):
                self.findings.append(Finding(
                    source="browser",
                    category="c2.ip_url_visit",
                    title=f"Browser visit to public-IP URL: "
                          f"{url[:80]}",
                    severity=SEV_MED,
                    conclusion=(
                        f"Browser visited '{url}' — a bare public-IP "
                        "URL rather than a registered domain, and not "
                        "in the cloud-CDN allowlist. Consistent with "
                        "attacker staging infrastructure."),
                    description="History row with public-IP URL.",
                    evidence=h,
                    tags=["T1071", "c2"]))


# ---------------------------------------------------------------------------
# LSA Secrets / SAM access indicators.
# ---------------------------------------------------------------------------

class LSAAccessAnalyzer:
    """
    We don't extract LSA secrets / SAM hashes — that's offline hive
    work. But we surface *indicators of access*: reg saves of
    HKLM\\SECURITY or HKLM\\SAM (4657/4663), openings of the hives
    on disk, and LSA-related handle grabs via Sysmon 10.
    """
    def __init__(self, evt_events: List[Dict[str, Any]],
                 logger: logging.Logger):
        self.events = evt_events
        self.logger = logger
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Finding]]:
        patterns = ("hklm\\security", "hklm\\sam",
                    "\\config\\security", "\\config\\sam")
        for ev in self.events:
            blob = json.dumps(ev, default=str).lower()
            if any(p in blob for p in patterns):
                self.findings.append(Finding(
                    source="evtlog",
                    category="credential.sam_security_access",
                    title="Access to SAM / SECURITY hive referenced",
                    severity=SEV_HIGH,
                    conclusion=(
                        "An event references SAM / SECURITY registry "
                        "paths. Offline access to these hives enables "
                        "password-hash extraction (secretsdump, "
                        "Impacket) and LSA-secret recovery. Validate "
                        "the subject and command line."),
                    description="Registry path referencing SAM/SECURITY.",
                    evidence=ev,
                    timestamp=ev.get("TimeCreated"),
                    tags=["T1003.002", "T1003.004",
                          "credential-access"]))
                # One finding per unique event type is enough
                break
        self.logger.info("LSA/SAM access indicators: %d",
                         len(self.findings))
        return (self.findings,)


# ---------------------------------------------------------------------------
# Simplified Sigma rule engine.
# ---------------------------------------------------------------------------

# Compact, curated ruleset in the simplified Sigma-ish format we
# implement. Full Sigma is larger than we want to pull in as a hard
# dependency; this subset captures the most common detection fields
# (EventID, CommandLine, Image, ParentImage, TargetImage) with
# keyword / contains / endswith / equals matchers.

BUNDLED_SIGMA_RULES = [
    {
        "title": "PsExec Service Registration (svcctl over SMB)",
        "id": "fma-psexec-service",
        "level": "high",
        "mitre": ["T1021.002"],
        "description":
            "A 7045 event where the service runs PSEXESVC.exe — the "
            "execution half of PsExec lateral movement.",
        "logsource": {"service": "System"},
        "detection": {
            "selection": {"EventID": [7045]},
            "imagepath_contains": ["psexesvc", "paexec"],
        },
    },
    {
        "title": "Suspicious New Service by SYSTEM with ImagePath in Temp",
        "id": "fma-svc-sys-temp",
        "level": "critical",
        "mitre": ["T1543.003"],
        "description": "System-context service install with binary in "
                       "TEMP / AppData.",
        "logsource": {"service": "System"},
        "detection": {
            "selection": {"EventID": [7045, 4697]},
            "imagepath_contains": ["\\temp\\", "\\appdata\\"],
        },
    },
    {
        "title": "RDP External Incoming Connection",
        "id": "fma-rdp-external",
        "level": "medium",
        "mitre": ["T1021.001"],
        "description": "Type 10 (RemoteInteractive) logon from a "
                       "non-private IP.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [4624], "LogonType": ["10"]},
            "ip_external": True,
        },
    },
    {
        "title": "Scheduled Task Registered by SYSTEM from User Context",
        "id": "fma-schtask-suspicious",
        "level": "high",
        "mitre": ["T1053.005"],
        "description": "Task creation where SYSTEM is the caller and "
                       "content references user-writable paths.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [4698]},
            "content_contains": ["\\appdata\\", "\\temp\\",
                                 "\\public\\", "-enc "],
        },
    },
    {
        "title": "Security Log Cleared (no reboot cluster)",
        "id": "fma-security-log-clear",
        "level": "critical",
        "mitre": ["T1070.001"],
        "description": "1102 + no matching restart in cluster.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [1102]},
        },
    },
    {
        "title": "WDigest Enabled via Registry (Mimikatz pre-flight)",
        "id": "fma-wdigest-enabled",
        "level": "high",
        "mitre": ["T1003.001"],
        "description": "UseLogonCredential=1 enables cleartext "
                       "credentials in memory. Pre-flight for "
                       "Mimikatz.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [4657]},
            "content_contains": ["wdigest\\uselogoncredential"],
        },
    },
    {
        "title": "LSASS Dump via comsvcs.dll MiniDump",
        "id": "fma-comsvcs-minidump",
        "level": "critical",
        "mitre": ["T1003.001"],
        "description": "rundll32 comsvcs.dll,MiniDump — built-in "
                       "LSASS dump primitive.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [4688]},
            "content_contains": ["comsvcs.dll,minidump",
                                 "comsvcs.dll minidump",
                                 "minidump lsass"],
        },
    },
    {
        "title": "Shadow Copy Deletion (ransomware pre-flight)",
        "id": "fma-vssdelete",
        "level": "critical",
        "mitre": ["T1490"],
        "description": "vssadmin delete shadows / wmic shadowcopy "
                       "delete / wbadmin delete.",
        "logsource": {"service": "Security"},
        "detection": {
            "selection": {"EventID": [4688]},
            "content_contains": ["vssadmin delete shadows",
                                 "wmic shadowcopy delete",
                                 "wbadmin delete", "bcdedit /set "
                                 "{default} recoveryenabled no"],
        },
    },
    {
        "title": "Disable Windows Defender via Set-MpPreference",
        "id": "fma-defender-disable",
        "level": "high",
        "mitre": ["T1562.001"],
        "description": "PowerShell disabling Defender.",
        "logsource": {"service": "PowerShell"},
        "detection": {
            "selection": {"EventID": [4104]},
            "content_contains": ["set-mppreference -disable",
                                 "-disablerealtimemonitoring",
                                 "add-mppreference -exclusionpath"],
        },
    },
    {
        "title": "Suspicious encoded PowerShell with runtime download",
        "id": "fma-ps-download-cradle",
        "level": "high",
        "mitre": ["T1059.001"],
        "description": "Encoded PS with IEX + WebClient download.",
        "logsource": {"service": "PowerShell"},
        "detection": {
            "selection": {"EventID": [4104]},
            "content_contains": [
                "iex(new-object net.webclient",
                "invoke-expression ([system.text.encoding]",
                ".downloadstring(", "frombase64string(",
            ],
        },
    },
]


class SigmaEngine:
    def __init__(self, rules: Optional[List[Dict[str, Any]]],
                 logger: logging.Logger):
        self.rules = rules or BUNDLED_SIGMA_RULES
        self.logger = logger
        self.findings: List[Finding] = []

    def run(self, events: List[Dict[str, Any]]) -> List[Finding]:
        for rule in self.rules:
            try:
                for ev in events:
                    if self._match(rule, ev):
                        self.findings.append(self._to_finding(rule, ev))
            except Exception as exc:
                self.logger.debug("Sigma rule '%s' failed: %s",
                                  rule.get("id"), exc)
        self.logger.info("Sigma: %d rules, %d findings",
                         len(self.rules), len(self.findings))
        return self.findings

    def _match(self, rule: Dict[str, Any],
                 ev: Dict[str, Any]) -> bool:
        det = rule.get("detection", {})
        sel = det.get("selection", {})
        # EventID
        wanted = sel.get("EventID")
        if wanted and ev.get("EventID") not in wanted:
            return False
        # LogonType
        lt = sel.get("LogonType")
        if lt and str(ev.get("LogonType")) not in lt:
            return False
        # content_contains: any-of across the flattened event text
        needles = det.get("content_contains") or []
        if needles:
            blob = json.dumps(ev, default=str).lower()
            if not any(n.lower() in blob for n in needles):
                return False
        # imagepath_contains: any-of against ImagePath/NewProcessName
        ip_needles = det.get("imagepath_contains") or []
        if ip_needles:
            ip_val = (ev.get("ImagePath") or ev.get("NewProcessName")
                      or ev.get("ServiceFileName") or "").lower()
            if not any(n.lower() in ip_val for n in ip_needles):
                return False
        # ip_external
        if det.get("ip_external"):
            ip = (ev.get("IpAddress") or "").strip()
            if not ip or ip in ("-", "127.0.0.1", "::1"):
                return False
            priv_prefixes = ["10."] + [f"172.{i}." for i in
                                       range(16, 32)] + ["192.168."]
            if any(ip.startswith(p) for p in priv_prefixes):
                return False
            if ip_is_benign_cloud(ip):
                return False
        return True

    @staticmethod
    def _to_finding(rule: Dict[str, Any],
                     ev: Dict[str, Any]) -> Finding:
        level = (rule.get("level") or "medium").lower()
        sev = {"informational": SEV_INFO, "low": SEV_LOW,
               "medium": SEV_MED, "high": SEV_HIGH,
               "critical": SEV_CRIT}.get(level, SEV_MED)
        return Finding(
            source="sigma",
            category=f"sigma.{rule.get('id','unknown')}",
            title=f"Sigma: {rule.get('title','?')}",
            severity=sev,
            conclusion=(
                rule.get("description", "?") +
                " — rule matched this event in the parsed log."),
            description="Sigma rule match.",
            evidence={"rule_id": rule.get("id"),
                      "rule_level": level, "event": ev},
            timestamp=ev.get("TimeCreated"),
            tags=list(rule.get("mitre") or []) + ["sigma"])


# ---------------------------------------------------------------------------
# SRUM body parsing — via dissect.esedb if available, else stub.
# ---------------------------------------------------------------------------

class SRUMBodyAnalyzer:
    """
    Parses SRUDB.dat (ESE/JET) to extract per-process network bytes
    and application usage across ~60 days. Requires dissect.esedb
    (optional); if not installed, falls back to the stub behavior
    (presence-only report, which SRUMAnalyzer still emits).
    """
    # Known SRUM table GUIDs (partial list)
    TBL_APP_RESOURCE = "{d10ca2fe-6fcf-4f6d-848e-b2e99266fa89}"
    TBL_NETWORK_USAGE = "{973f5d5c-1d90-4944-be8e-24b94231a174}"
    TBL_NETWORK_CONNECTIVITY = "{dd6636c4-8929-4683-974e-22c046a43763}"

    def __init__(self, path: Optional[Path],
                 logger: logging.Logger):
        self.path = path or Path(
            r"C:\Windows\System32\SRU\SRUDB.dat")
        self.logger = logger
        self.network_usage: List[Dict[str, Any]] = []
        self.app_usage: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        if not _safe_exists(self.path):
            return {}, self.findings
        try:
            from dissect.esedb import EseDB
        except ImportError:
            self.logger.info(
                "SRUM body parse skipped: dissect.esedb not installed")
            return {}, self.findings
        try:
            with open(self.path, "rb") as fh:
                db = EseDB(fh)
                self._parse(db)
        except Exception as exc:
            self.logger.warning("SRUM body parse failed: %s", exc)
            return {}, self.findings
        self._analyze()
        self.logger.info(
            "SRUM body: %d network rows, %d app rows, %d findings",
            len(self.network_usage), len(self.app_usage),
            len(self.findings))
        return ({"network_usage": self.network_usage[:200],
                 "app_usage": self.app_usage[:200]},
                self.findings)

    def _parse(self, db) -> None:
        # Build SID -> user map from SruDbIdMapTable if present
        id_map: Dict[int, str] = {}
        try:
            t = db.table("SruDbIdMapTable")
            for row in t.records():
                try:
                    id_map[row.get("IdIndex")] = str(
                        row.get("IdBlob"))
                except Exception:
                    continue
        except Exception:
            pass

        # Network usage
        try:
            t = db.table(self.TBL_NETWORK_USAGE)
            for row in list(t.records())[:5000]:
                try:
                    self.network_usage.append({
                        "timestamp": str(row.get("TimeStamp")),
                        "app_id": id_map.get(row.get("AppId"),
                                              row.get("AppId")),
                        "user_id": id_map.get(row.get("UserId"),
                                               row.get("UserId")),
                        "bytes_sent": row.get("BytesSent"),
                        "bytes_recvd": row.get("BytesRecvd"),
                    })
                except Exception:
                    continue
        except Exception:
            pass
        # Application usage
        try:
            t = db.table(self.TBL_APP_RESOURCE)
            for row in list(t.records())[:5000]:
                try:
                    self.app_usage.append({
                        "timestamp": str(row.get("TimeStamp")),
                        "app_id": id_map.get(row.get("AppId"),
                                              row.get("AppId")),
                        "user_id": id_map.get(row.get("UserId"),
                                               row.get("UserId")),
                        "foreground_cycle_time":
                            row.get("ForegroundCycleTime"),
                    })
                except Exception:
                    continue
        except Exception:
            pass

    def _analyze(self) -> None:
        # Top-N bandwidth consumers — useful for exfil detection.
        if not self.network_usage:
            return
        by_app: Dict[str, Dict[str, int]] = {}
        for row in self.network_usage:
            key = str(row.get("app_id") or "?")
            slot = by_app.setdefault(key, {"sent": 0, "recvd": 0})
            try:
                slot["sent"] += int(row.get("bytes_sent") or 0)
                slot["recvd"] += int(row.get("bytes_recvd") or 0)
            except (TypeError, ValueError):
                continue
        top = sorted(by_app.items(),
                     key=lambda x: -x[1]["sent"])[:10]
        self.findings.append(Finding(
            source="srum", category="srum.top_bandwidth",
            title=f"SRUM: top {len(top)} bandwidth senders",
            severity=SEV_INFO,
            conclusion=(
                "SRUM aggregated network usage across the observed "
                "window. Top senders are listed; cross-reference "
                "against the normal traffic profile to spot "
                "exfiltration candidates."),
            description="SRUM NetworkUsage table aggregation.",
            evidence={"top_senders": [
                {"app": k, "bytes_sent": v["sent"],
                 "bytes_recvd": v["recvd"]}
                for k, v in top
            ]},
            tags=["srum", "exfil-candidate"]))


# ---------------------------------------------------------------------------
# Finding enrichment: hashes, Authenticode, YARA on referenced files.
# ---------------------------------------------------------------------------

class FindingEnricher:
    """
    For every finding that references a file on disk (service image,
    autorun value, scheduled-task action, carved PE path, SMB share
    lookup, etc.), enrich the evidence with:
      - sha256 (and md5 for compatibility)
      - Authenticode status and signer
      - YARA rule matches
    Attacker intel is most actionable when each flagged artifact is
    individually identified and reputation-ready.
    """

    def __init__(self, logger: logging.Logger,
                 extra_yara: Optional[List[Path]] = None):
        self.logger = logger
        self.extra_yara = extra_yara or []

    def run(self, findings: List[Finding]) -> None:
        for f in findings:
            path = self._extract_path(f)
            if not path:
                continue
            p = Path(path)
            if not p.exists() or not p.is_file():
                continue
            # Avoid enriching gigabyte-files.
            try:
                if p.stat().st_size > 200 * 1024 * 1024:
                    continue
            except OSError:
                continue

            enrichment: Dict[str, Any] = {}
            hashes = hash_file(p, ("sha256", "md5"))
            if hashes:
                enrichment["sha256"] = hashes.get("sha256")
                enrichment["md5"] = hashes.get("md5")
            auth = verify_authenticode(p, self.logger)
            if auth:
                enrichment["authenticode"] = {
                    "status": auth.get("Status"),
                    "signer": auth.get("SignerName"),
                    "issuer": auth.get("Issuer"),
                }
                # If a flagged binary turns out to be signed by a
                # well-known vendor, soften the severity one notch
                # (but only from HIGH -> MED; never silence CRIT).
                signer = (auth.get("SignerName") or "").lower()
                if auth.get("Status") == "Valid" and signer and \
                        _is_known_vendor(signer) and \
                        f.severity == SEV_HIGH and \
                        f.category.startswith("persistence"):
                    f.severity = SEV_MED
                    f.conclusion += (
                        f" NOTE: binary is Authenticode-signed by "
                        f"'{auth.get('SignerName')}' — severity "
                        "softened one notch after signature check.")
            matches = yara_scan_file(p, self.extra_yara)
            if matches:
                enrichment["yara"] = matches
                # A YARA hit on a carved/flagged binary elevates to
                # Critical if it matched a high-signal rule.
                rule_names = {m["rule"] for m in matches}
                if rule_names & {"FMA_Mimikatz", "FMA_Meterpreter_Stager",
                                  "FMA_CobaltStrike_Beacon",
                                  "FMA_PowerSploit_Keywords"}:
                    f.severity = SEV_CRIT
                    f.conclusion += (
                        f" YARA match: {sorted(rule_names)} — content "
                        "inspection confirms offensive tooling.")

            if enrichment:
                f.evidence = {**(f.evidence or {}), **enrichment}

    @staticmethod
    def _extract_path(f: Finding) -> Optional[str]:
        ev = f.evidence or {}
        # Check the usual suspects across analyzer evidence shapes.
        for key in ("path", "image_path", "exe", "ExecutablePath",
                    "NewProcessName", "ImagePath", "file",
                    "faulting_module_path"):
            v = ev.get(key)
            if isinstance(v, str) and v:
                path = _extract_image_path(v)
                if path:
                    return path
        # Autoruns: value often IS the image
        if f.source == "autoruns" and ev.get("value"):
            return _extract_image_path(ev["value"])
        return None


# ---------------------------------------------------------------------------
# IoC matcher.
# ---------------------------------------------------------------------------

class IoCMatcher:
    """
    Correlates a user-supplied IoC set (IPs, domains, hashes, filenames,
    YARA rule files) against every accumulated finding. Each match
    becomes its own Critical finding.
    """

    def __init__(self, iocs: IoCSet, logger: logging.Logger):
        self.iocs = iocs
        self.logger = logger

    def run(self, findings: List[Finding]) -> List[Finding]:
        if self.iocs.is_empty():
            return []
        out: List[Finding] = []
        for f in findings:
            out.extend(self._scan(f))
        if out:
            self.logger.info("IoC matches: %d", len(out))
        return out

    def _scan(self, f: Finding) -> List[Finding]:
        out: List[Finding] = []
        ev = f.evidence or {}
        text = json.dumps(ev, default=str).lower()

        # Hashes
        for h_field in ("sha256", "md5"):
            v = ev.get(h_field)
            if isinstance(v, str) and self.iocs.match_hash(v):
                out.append(self._build_ioc_finding(
                    f, "hash", v,
                    f"File hash {v} matches threat-intel IoC list."))

        # IPs (search the whole evidence serialization)
        for ip in self.iocs.ips:
            if ip and ip in text:
                out.append(self._build_ioc_finding(
                    f, "ip", ip,
                    f"IP {ip} appears in finding evidence and is "
                    "on the threat-intel IoC list."))
        # Domains
        for d in self.iocs.domains:
            if d and d in text:
                out.append(self._build_ioc_finding(
                    f, "domain", d,
                    f"Domain {d} appears in finding evidence and is "
                    "on the threat-intel IoC list."))
        # Filenames
        for fn in self.iocs.filenames:
            if fn and fn in text:
                out.append(self._build_ioc_finding(
                    f, "filename", fn,
                    f"Filename '{fn}' appears in finding evidence and "
                    "is on the threat-intel IoC list."))
        return out

    @staticmethod
    def _build_ioc_finding(f: Finding, kind: str, value: str,
                            conclusion: str) -> Finding:
        return Finding(
            source="ioc",
            category=f"ioc.{kind}_match",
            title=f"IoC match: {kind}={value}",
            severity=SEV_CRIT,
            conclusion=conclusion + (
                f" Original finding: '{f.title}' "
                f"[{f.source}/{f.category}]."),
            description="Correlation between operator-supplied IoC "
                        "list and an accumulated forensic finding.",
            evidence={"ioc_kind": kind, "ioc_value": value,
                      "matched_finding_title": f.title,
                      "matched_finding_source": f.source,
                      "matched_finding_category": f.category},
            tags=["ioc-match", kind],
            confidence="high",
        )


# ---------------------------------------------------------------------------
# Finding normalizer (dedup + noise reduction + decay scoring).
# ---------------------------------------------------------------------------

class FindingNormalizer:
    """
    Consolidates identical findings, collapses known-vendor service noise,
    and produces a list tagged with 'occurrences' so the report and the
    score operate on unique security events, not raw counts.
    """

    def __init__(self, findings: List[Finding]):
        self.findings = findings

    def normalize(self) -> List[Finding]:
        groups: Dict[Tuple[str, ...], List[Finding]] = {}
        for f in self.findings:
            groups.setdefault(f.dedup_key(), []).append(f)

        out: List[Finding] = []
        for key, group in groups.items():
            if len(group) == 1:
                out.append(group[0])
                continue
            # Choose the most severe representative
            rep = max(group, key=lambda g: g.severity)
            rep.evidence = dict(rep.evidence or {})
            rep.evidence["occurrences"] = len(group)
            rep.evidence["first_seen"] = min(
                (g.timestamp for g in group if g.timestamp),
                default=rep.timestamp)
            rep.evidence["last_seen"] = max(
                (g.timestamp for g in group if g.timestamp),
                default=rep.timestamp)
            rep.title = f"{rep.title} (x{len(group)})"
            out.append(rep)
        return out


# ---------------------------------------------------------------------------
# Scoring.
# ---------------------------------------------------------------------------

SEV_WEIGHT = {5: 25, 4: 10, 3: 3, 2: 1, 1: 0}


def compute_threat_score(findings: List[Finding]
                          ) -> Tuple[int, str, Dict[str, int]]:
    """
    Per-category decay:
      first hit    = full weight
      second hit   = 50%
      third+ hit   = 20%
    Stops the score being pinned to 100 by a dozen Medium entries of
    the same flavor.
    """
    by_cat: Dict[str, List[Finding]] = {}
    for f in findings:
        by_cat.setdefault(f.category, []).append(f)

    score = 0.0
    contribs: Dict[str, int] = {}
    for cat, items in by_cat.items():
        items.sort(key=lambda x: -x.severity)
        for idx, f in enumerate(items):
            base = SEV_WEIGHT[f.severity]
            if idx == 0:
                mult = 1.0
            elif idx == 1:
                mult = 0.5
            else:
                mult = 0.2
            contrib = base * mult
            score += contrib
            contribs[cat] = contribs.get(cat, 0) + int(contrib)

    score = min(int(round(score)), 100)
    if score >= 70:
        band = "CRITICAL"
    elif score >= 40:
        band = "HIGH"
    elif score >= 15:
        band = "MEDIUM"
    elif score > 0:
        band = "LOW"
    else:
        band = "CLEAN"
    return score, band, contribs


# ---------------------------------------------------------------------------
# HTML report (with Top Critical + Investigator Conclusions).
# ---------------------------------------------------------------------------

REPORT_CSS = """
:root { --bg:#0b0f17; --panel:#141a26; --panel2:#1b2232;
        --fg:#e6edf3; --fg-dim:#98a2b3; --border:#27303f; }
* { box-sizing:border-box; }
body { margin:0; font-family:'Segoe UI',system-ui,sans-serif;
       background:var(--bg); color:var(--fg); line-height:1.45; }
header { padding:28px 40px; border-bottom:1px solid var(--border);
         background:linear-gradient(120deg,#0d131f,#111827); }
header h1 { margin:0 0 4px 0; font-size:26px; }
header .sub { color:var(--fg-dim); font-size:13px; }
.container { padding:24px 40px; max-width:1320px; margin:auto; }
.grid { display:grid; gap:20px; grid-template-columns:1fr 1fr 1fr; }
.card { background:var(--panel); border:1px solid var(--border);
        border-radius:12px; padding:18px; }
.card h3 { margin-top:0; font-size:13px; text-transform:uppercase;
           letter-spacing:.08em; color:var(--fg-dim); }
.section { margin-top:32px; background:var(--panel);
           border:1px solid var(--border); border-radius:12px;
           overflow:hidden; }
.section h2 { margin:0; padding:14px 20px;
              border-bottom:1px solid var(--border);
              background:var(--panel2); font-size:16px; }
.section-body { padding:16px 20px; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th, td { text-align:left; padding:8px 10px;
         border-bottom:1px solid var(--border); vertical-align:top; }
th { color:var(--fg-dim); font-weight:500; background:var(--panel2); }
tr:hover td { background:#182034; }
.pill { display:inline-block; padding:2px 10px; border-radius:999px;
        font-size:11px; font-weight:600; color:#fff; }
.critfind { border-left:6px solid; padding:16px 20px;
            margin:14px 0; background:#0f1521;
            border-radius:0 10px 10px 0; }
.critfind h4 { margin:0 0 8px 0; font-size:15px; }
.critfind .tagbar { margin-top:8px; }
.critfind .verdict { color:var(--fg);
                     background:#1b2537; padding:10px 14px;
                     border-radius:6px; border-left:3px solid;
                     margin:10px 0; }
details { margin:6px 0; }
details > summary { cursor:pointer; padding:10px 14px; border-radius:8px;
                    background:var(--panel2);
                    border:1px solid var(--border); list-style:none; }
details[open] > summary { border-bottom:none;
                          border-radius:8px 8px 0 0; }
details > div.body { padding:14px 16px;
                     border:1px solid var(--border); border-top:none;
                     border-radius:0 0 8px 8px; background:#0f1521; }
code, pre { background:#0a0f19; border:1px solid var(--border);
            color:#d7dee7; padding:2px 6px; border-radius:4px;
            font-family:Consolas,monospace; font-size:12px;
            overflow-x:auto; }
pre { padding:10px 14px; white-space:pre-wrap; word-break:break-word; }
.tag { display:inline-block; background:#223048; color:#c7d5ea;
       padding:1px 8px; border-radius:4px; font-size:11px;
       margin-right:4px; }
.score-ring { width:130px; height:130px; border-radius:50%;
              display:flex; align-items:center; justify-content:center;
              font-size:36px; font-weight:700;
              box-shadow: inset 0 0 0 6px var(--border); }
footer { text-align:center; padding:24px; color:var(--fg-dim);
         font-size:12px; }
.mitre-grid {
    display:grid; grid-template-columns:repeat(4,1fr); gap:10px;
    margin-top:12px;
}
.mt-phase {
    background:#0f1521; border:1px solid var(--border);
    border-radius:8px; padding:10px 12px;
}
.mt-phase h4 { margin:0 0 8px 0; font-size:11px;
               text-transform:uppercase; letter-spacing:.08em;
               color:var(--fg-dim); }
.mt-phase.mt-empty { opacity:0.35; }
.mt-tech {
    background:#1b2232; border:1px solid var(--border);
    border-radius:4px; padding:4px 8px; margin:3px 0;
    font-size:12px; display:flex; justify-content:space-between;
}
.mt-tech span { color:var(--fg-dim); font-size:11px; }
.mt-none { color:var(--fg-dim); font-size:12px; }
tr.eid-sus > td { background:rgba(230, 126, 34, 0.08); }
tr.eid-sus > td:first-child::before {
    content:"\\26a0  "; color:#e67e22; font-weight:700;
}
ol.findex { margin:6px 0 0 16px; padding:0; }
ol.findex li { margin:4px 0; }
.findex-link {
    color:var(--fg); text-decoration:none;
    padding:6px 10px; display:block; border-radius:6px;
}
.findex-link:hover { background:#1b2232; }
.refbox {
    background:#0f1521; border:1px solid var(--border);
    border-radius:8px; padding:10px 14px; margin-top:4px;
}
.refbox table.refs { font-size:12px; }
.refbox table.refs th {
    text-align:left; background:transparent;
    border:none; color:var(--fg-dim); font-weight:500;
    padding:4px 10px 4px 0;
}
.refbox table.refs td {
    border:none; padding:4px 0; word-break:break-all;
}
.refbox table.refs code { font-size:11px; background:#1b2232; }
.critfind:target {
    box-shadow: 0 0 0 2px #3aa0ff;
    animation: fma-pulse 1.4s ease-out 1;
}
@keyframes fma-pulse {
    0%   { box-shadow: 0 0 0 4px #3aa0ff; }
    100% { box-shadow: 0 0 0 0 transparent; }
}

/* --- v4.0 collapsible-section redesign --- */
details.section > summary {
    list-style: none; cursor: pointer;
    padding: 14px 20px; background: var(--panel2);
    border-bottom: 1px solid var(--border);
    display: flex; justify-content: space-between;
    align-items: center; user-select: none;
}
details.section > summary::-webkit-details-marker { display: none; }
details.section > summary::after {
    content: "+"; color: var(--fg-dim); font-size: 22px;
    font-family: monospace;
}
details.section[open] > summary::after { content: "-"; }
details.section > summary h2 {
    margin: 0; padding: 0; background: transparent;
    border: none; font-size: 16px;
}
details.deep {
    margin: 10px 0; border: 1px solid #27303f;
    border-radius: 6px; background: #0a1018;
}
details.deep > summary {
    cursor: pointer; padding: 8px 12px;
    background: #131927; color: var(--fg-dim);
    font-size: 12px; border-radius: 6px;
    user-select: none;
}
details.deep[open] > summary {
    background: #1a2236; color: var(--fg);
}
details.deep > div.deep-body { padding: 12px 14px; }
.deep-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
    margin-top: 6px;
}
.deep-card {
    background: #0f1521; border: 1px solid var(--border);
    border-radius: 6px; padding: 10px 14px;
}
.deep-card h5 { margin: 0 0 6px 0; color: #3aa0ff;
                font-size: 12px; text-transform: uppercase;
                letter-spacing: .06em; }
.confidence-bar {
    height: 8px; border-radius: 4px; background: #141a26;
    overflow: hidden; margin-top: 6px;
}
.confidence-fill {
    height: 100%; background: linear-gradient(90deg,
        #16a085 0%, #f39c12 50%, #c0392b 100%);
}
.query-box {
    background: #0a0f19; border: 1px solid var(--border);
    border-radius: 4px; padding: 8px 10px; margin: 4px 0;
    font-family: Consolas, monospace; font-size: 11px;
    white-space: pre-wrap; word-break: break-all;
}
.query-lang {
    color: var(--fg-dim); font-size: 10px;
    text-transform: uppercase; letter-spacing: .08em;
}
.triage-state {
    float: right; margin-left: 10px; padding: 3px 8px;
    font-size: 10px; border-radius: 10px;
    background: #1b2232; color: var(--fg-dim);
    border: 1px solid var(--border); cursor: pointer;
}
.triage-state.state-confirmed { background: #7a231b; color: #fff; }
.triage-state.state-fp        { background: #16a085; color: #fff; }
.triage-state.state-dismissed { background: #444; color: #fff; }
.triage-state.state-escalated { background: #e67e22; color: #fff; }
body.rtl { direction: rtl; text-align: right; }
body.rtl table, body.rtl td, body.rtl th { text-align: right; }
body.light {
    --bg:#f6f8fb; --panel:#ffffff; --panel2:#eef1f5;
    --fg:#0b1320; --fg-dim:#6a7280; --border:#d9dee4;
}
.toolbar {
    position: fixed; top: 8px; right: 8px; z-index: 9999;
    display: flex; gap: 6px;
}
.toolbar button {
    background: #1b2232; color: var(--fg); border: 1px solid
    var(--border); border-radius: 16px; padding: 6px 12px;
    font-size: 11px; cursor: pointer;
}
.toolbar button:hover { background: #27303f; }
.ioc-vt-bad { color: #c0392b; font-weight: 700; }
.ioc-vt-ok  { color: #16a085; }

/* --- Process-tree severity filter bar -------------------- */
.proc-filter-btn {
    background: var(--panel2);
    border: 1px solid var(--border);
    color: var(--fg-dim);
    padding: 5px 12px;
    border-radius: 14px;
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
    transition: all 140ms ease;
    user-select: none;
}
.proc-filter-btn:hover {
    background: #27303f;
    color: var(--fg);
    border-color: var(--fg-dim);
}
.proc-filter-btn.active {
    background: rgba(58, 160, 255, 0.15);
    color: #5b9dff;
    border-color: #3aa0ff;
    box-shadow: 0 0 0 2px rgba(58, 160, 255, 0.1);
}

/* --- VT report button (Attack Indicators hash rows) ------ */
a.vt-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: linear-gradient(135deg, #394eff 0%, #5b9dff 100%);
    color: #ffffff !important;
    font-weight: 600;
    padding: 3px 10px;
    border-radius: 5px;
    font-size: 10px;
    text-decoration: none !important;
    letter-spacing: 0.03em;
    margin-left: 6px;
    transition: all 140ms ease;
    box-shadow: 0 1px 3px rgba(58, 78, 255, 0.4);
}
a.vt-btn::before {
    content: "VT";
    font-weight: 800;
    font-family: ui-monospace, Consolas, monospace;
    letter-spacing: 0.05em;
    border-right: 1px solid rgba(255,255,255,0.3);
    padding-right: 5px;
    margin-right: 2px;
}
a.vt-btn:hover {
    filter: brightness(1.15);
    box-shadow: 0 2px 8px rgba(58, 78, 255, 0.6);
    transform: translateY(-1px);
}
a.vt-btn::after {
    content: "\\2197"; /* up-right arrow */
    font-size: 11px;
    margin-left: 2px;
}
"""


# ---------------------------------------------------------------------------
# Attack Indicator aggregator — pulls every IoC-shaped identifier out of
# the findings so the analyst has a single IOC sheet to share with
# upstream / downstream IR.
# ---------------------------------------------------------------------------

class AttackIndicatorAggregator:
    """
    Aggregates all concrete identifiers the analyzer emitted into
    per-type tables: IPs, domains, hashes, URLs, users, file paths,
    MITRE techniques — each with a back-link to every finding that
    referenced it.
    """

    def __init__(self, findings: List[Finding]):
        self.findings = findings

    def run(self) -> Dict[str, List[Dict[str, Any]]]:
        ips: Dict[str, List[Tuple[str, str]]] = {}
        domains: Dict[str, List[Tuple[str, str]]] = {}
        sha256s: Dict[str, List[Tuple[str, str]]] = {}
        md5s: Dict[str, List[Tuple[str, str]]] = {}
        paths: Dict[str, List[Tuple[str, str]]] = {}
        users: Dict[str, List[Tuple[str, str]]] = {}
        urls: Dict[str, List[Tuple[str, str]]] = {}
        mitre: Dict[str, List[Tuple[str, str]]] = {}

        for f in self.findings:
            anchor = f.anchor_id()
            pair = (anchor, f.title)
            ev = f.evidence or {}

            # IPs
            for k in ("IpAddress", "ForeignAddr", "src_ip",
                      "DestinationIp", "SourceIp"):
                v = ev.get(k)
                if isinstance(v, str) and v and v not in (
                        "-", "::", "0.0.0.0", "127.0.0.1", "::1"):
                    ips.setdefault(v, []).append(pair)
            for v in (ev.get("src_ips") or []):
                if isinstance(v, str) and v:
                    ips.setdefault(v, []).append(pair)

            # URLs + derived domains
            for k in ("url", "source_url", "QueryName", "raddr"):
                v = ev.get(k)
                if isinstance(v, str) and v:
                    urls.setdefault(v, []).append(pair)
                    m = re.match(
                        r"^https?://([^/:]+)(?:[:/]|$)", v.lower())
                    if m:
                        domains.setdefault(m.group(1), []).append(pair)
                    elif "." in v and not v.startswith("http") \
                            and "/" not in v:
                        domains.setdefault(
                            v.lower(), []).append(pair)

            # Hashes
            if ev.get("sha256"):
                sha256s.setdefault(ev["sha256"], []).append(pair)
            if ev.get("md5"):
                md5s.setdefault(ev["md5"], []).append(pair)

            # File paths (trim to the actual exe path)
            for k in ("path", "image_path", "ImagePath",
                      "NewProcessName", "TargetImage",
                      "SourceImage", "exe", "ExecutablePath",
                      "faulting_module"):
                v = ev.get(k)
                if isinstance(v, str) and v:
                    p = _extract_image_path(v)
                    if p and p.endswith((".exe", ".dll", ".sys",
                                          ".ps1", ".vbs", ".bat",
                                          ".lnk")):
                        paths.setdefault(p, []).append(pair)

            # Users
            for k in ("target_user", "TargetUserName",
                      "SubjectUserName", "username", "subject"):
                v = ev.get(k)
                if isinstance(v, str) and v and v != "-" and \
                        not v.endswith("$"):
                    users.setdefault(v.lower(), []).append(pair)

            # MITRE
            for t in f.tags:
                if isinstance(t, str) and re.match(r"^T\d{4}", t):
                    mitre.setdefault(t, []).append(pair)

        def _dumped(bag):
            return [
                {"value": k, "count": len(v),
                 "references": [{"anchor": a, "title": t}
                                 for a, t in v[:8]]}
                for k, v in sorted(bag.items(),
                                    key=lambda x: -len(x[1]))
            ]

        return {
            "ips": _dumped(ips),
            "domains": _dumped(domains),
            "urls": _dumped(urls),
            "sha256": _dumped(sha256s),
            "md5": _dumped(md5s),
            "paths": _dumped(paths),
            "users": _dumped(users),
            "mitre": _dumped(mitre),
        }


def build_super_timeline(findings: List[Finding],
                          evt_events: List[Dict[str, Any]],
                          bam_entries: List[Dict[str, Any]],
                          prefetch_entries: List[Dict[str, Any]],
                          dump_records: List[Dict[str, Any]],
                          max_items: int = 500) -> List[Dict[str, Any]]:
    """
    Unified chronological view across every time-bearing source.
    Output entries: {ts, source, kind, summary, severity}
    """
    tl: List[Dict[str, Any]] = []

    def _push(ts: Optional[str], source: str, kind: str,
              summary: str, severity: int = SEV_INFO):
        if not ts:
            return
        tl.append({"ts": ts, "source": source, "kind": kind,
                   "summary": summary, "severity": severity})

    # Findings with a timestamp
    for f in findings:
        if f.timestamp:
            _push(f.timestamp, f.source,
                  f.category, f.title, f.severity)

    # High-signal events
    high_signal_eids = {1102, 104, 1100, 4719, 4648, 4624,
                        4625, 4688, 4697, 4698, 7045, 4740,
                        4720, 4728, 4732, 4724, 4722}
    for e in evt_events:
        eid = e.get("EventID")
        if eid in high_signal_eids:
            meta = EVENT_CATALOG.get(eid, {})
            user = (e.get("TargetUserName")
                    or e.get("SubjectUserName")
                    or e.get("NewProcessName")
                    or e.get("ServiceName") or "-")
            _push(e.get("TimeCreated"), "evtlog",
                  f"evid.{eid}",
                  f"{meta.get('name','?')}  -  {user}", SEV_INFO)

    # BAM entries
    for b in bam_entries:
        if b.get("last_run"):
            _push(b["last_run"], "bam", "exec",
                  f"Executed: {b.get('path','?')}", SEV_INFO)

    # Prefetch entries
    for p in prefetch_entries:
        if p.get("mtime"):
            _push(p["mtime"], "prefetch", "exec",
                  f"Prefetched: {p.get('name','?')}", SEV_INFO)

    # Crash dump timestamps
    for d in dump_records:
        if d.get("timestamp"):
            exc = (d.get("exception") or {}).get("code_name") or "?"
            _push(d["timestamp"], "dump", "crash",
                  f"Crash: {d.get('process_name','?')} ({exc})",
                  SEV_LOW)

    tl.sort(key=lambda x: x.get("ts") or "")
    return tl[-max_items:]


class ReportGenerator:
    def __init__(self, findings: List[Finding],
                 metadata: Dict[str, Any], output_path: Path,
                 event_overview: Optional[Dict[int, Dict[str, Any]]]
                 = None,
                 timeline: Optional[List[Dict[str, Any]]] = None):
        self.findings = sorted(findings,
                               key=lambda f: (-f.severity, f.source))
        self.metadata = metadata
        self.output_path = output_path
        self.event_overview = event_overview or {}
        self.timeline = timeline or []
        # Pre-build attack indicators so they are available to
        # multiple sections
        self.indicators = AttackIndicatorAggregator(
            self.findings).run()

    def render(self) -> Path:
        score, band, contribs = compute_threat_score(self.findings)
        ring = {"CRITICAL": "#c0392b", "HIGH": "#e67e22",
                "MEDIUM": "#f39c12", "LOW": "#16a085",
                "CLEAN": "#6c7a89"}[band]

        malicious = [f for f in self.findings if f.severity >= SEV_HIGH]
        observations = [f for f in self.findings
                        if f.severity == SEV_MED]
        informational = [f for f in self.findings
                         if f.severity <= SEV_LOW]

        # Tag every section output with a close marker so the
        # collapse-pass finds the exact </div> that closes it.
        _mk = self._mark_section
        parts: List[str] = [
            "<!doctype html><html><head><meta charset='utf-8'>",
            f"<title>{TOOL_NAME} Report</title>",
            f"<style>{REPORT_CSS}</style></head><body>",
            self._header(),
            "<div class='container'>",
            # Executive summary + findings-first ordering: every
            # finding lives at the top of the report with the
            # "what is malicious" quote visible by default and the
            # technical deep-dive one click away.
            _mk(self._executive_briefing(score, band, ring,
                                           malicious, observations)),
            self._executive(score, band, ring, malicious,
                            observations, informational),
            # Findings Index merged into Executive Summary above.
            _mk(self._malicious_section(malicious)),
            _mk(self._observations_section(observations,
                                            collapsed=False)),
            _mk(self._memory_forensics_section()),
            _mk(self._attack_indicators_section()),
            _mk(self._mitre_heatmap(malicious + observations)),
            # Supporting evidence + host context below
            _mk(self._system_profile_section()),
            _mk(self._persistence_inventory_section()),
            _mk(self._network_activity_section()),
            _mk(self._process_tree_section()),
            _mk(self._domain_intel_section()),
            _mk(self._darknet_leak_section()),
            _mk(self._security_events_section()),
            _mk(self._timeline_section()),
        ]
        if informational:
            parts.append(_mk(self._informational_section(
                informational)))
        parts.append(_mk(self._remediation(band, self.findings)))
        parts.append(_mk(self._metadata_section()))
        parts.append("</div><footer>")
        parts.append(f"Generated by {TOOL_NAME} v{TOOL_VERSION} on "
                     f"{_iso(_now_utc())}")
        parts.append("</footer>")
        parts.append(self._interactive_js())
        parts.append("</body></html>")
        doc = "\n".join(parts)
        # Convert every <div class="section"> into a collapsible
        # <details> so the analyst can open only what they need.
        doc = self._collapse_sections(doc)
        self.output_path.write_text(doc, encoding="utf-8")
        return self.output_path

    @staticmethod
    def _mark_section(section_html: str) -> str:
        """Inject a unique closing marker after a section method's
        outermost </div> so the collapse-pass can find the real
        end without being fooled by nested </div></div>."""
        if not section_html:
            return section_html
        s = section_html.rstrip()
        if s.endswith("</div>"):
            return s[:-6] + "</div><!--/fma-section-->"
        return section_html

    @staticmethod
    def _collapse_sections(doc: str) -> str:
        # Every section method emits:
        #   <div class="section"><h2>TITLE</h2> ... </div>
        # and render() appends a <!--/fma-section--> marker so we
        # know exactly where the section closes (avoids the nested
        # </div></div> ambiguity that a naive regex hits).
        pattern = re.compile(
            r'<div class="section">\s*<h2>(?P<title>.*?)</h2>\s*'
            r'(?P<body>.*?)</div><!--/fma-section-->',
            flags=re.DOTALL)
        num_re = re.compile(r'^\s*\d+[a-z]?\.\s*')

        counter = [0]

        def _repl(m: re.Match) -> str:
            title = m.group("title")
            body = m.group("body")
            title_clean = num_re.sub("", title).lstrip()
            counter[0] += 1
            new_title = f"{counter[0]}. {title_clean}"
            closed_by_default = any(kw in new_title for kw in (
                "Informational", "Super-Timeline",
                "Running Processes", "Event ID Overview",
                "Network Activity", "System Information"))
            open_attr = "" if closed_by_default else " open"
            return (f'<details class="section"{open_attr}>'
                    f'<summary><h2>{new_title}</h2></summary>'
                    f'{body}</details>')

        return pattern.sub(_repl, doc)

    # -- MITRE ATT&CK heatmap ------------------------------------------

    def _mitre_heatmap(self, items: List[Finding]) -> str:
        # Map phase -> {technique: count}
        phase_counts: Dict[str, Dict[str, int]] = {}
        for f in items:
            for t in f.tags:
                if not re.match(r"^T\d{4}", str(t)):
                    continue
                phase = self._technique_phase(t)
                phase_counts.setdefault(phase, {}).setdefault(t, 0)
                phase_counts[phase][t] += 1
        if not phase_counts:
            return ""

        cells: List[str] = []
        for phase in ATTACK_PHASES:
            techs = phase_counts.get(phase, {})
            tcells = ""
            if techs:
                for tech, cnt in sorted(techs.items(),
                                         key=lambda x: -x[1]):
                    tcells += (
                        f"<div class='mt-tech' title='{tech}'>"
                        f"<b>{html.escape(tech)}</b>"
                        f"<span>×{cnt}</span></div>")
            cells.append(textwrap.dedent(f"""
                <div class="mt-phase{' mt-empty' if not techs else ''}">
                  <h4>{html.escape(phase.replace('-', ' '))}</h4>
                  {tcells or '<div class="mt-none">—</div>'}
                </div>
            """))
        return textwrap.dedent(f"""
            <div class="section">
              <h2>7. MITRE ATT&amp;CK Coverage</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Techniques referenced by confirmed findings, grouped
                  by tactic. Phases without hits show a dash.
                </p>
                <div class="mitre-grid">{''.join(cells)}</div>
              </div>
            </div>
        """)

    @staticmethod
    def _technique_phase(t: str) -> str:
        # Minimal mapping; covers the techniques we actually emit.
        phase_map = {
            "T1078": "initial-access",
            "T1110": "credential-access",
            "T1558": "credential-access",
            "T1134": "credential-access",
            "T1550": "credential-access",
            "T1555": "credential-access",
            "T1003": "credential-access",
            "T1087": "discovery",
            "T1069": "discovery",
            "T1059": "execution",
            "T1105": "execution",
            "T1027": "defense-evasion",
            "T1036": "defense-evasion",
            "T1070": "defense-evasion",
            "T1562": "defense-evasion",
            "T1098": "persistence",
            "T1136": "persistence",
            "T1543": "persistence",
            "T1547": "persistence",
            "T1546": "persistence",
            "T1053": "persistence",
            "T1021": "lateral-movement",
            "T1014": "defense-evasion",
            "T1055": "defense-evasion",
            "T1071": "command-and-control",
            "T1568": "command-and-control",
            "T1531": "impact",
            "T1574": "persistence",
            "T1112": "defense-evasion",
        }
        base = t.split(".")[0]
        return phase_map.get(base, "other")

    # -- Timeline section ---------------------------------------------

    def _timeline_section(self) -> str:
        if not self.timeline:
            return ""
        rows = []
        for item in reversed(self.timeline):    # most recent first
            sev = item.get("severity", SEV_INFO)
            color = SEV_COLOR[sev]
            ts = html.escape(str(item.get("ts") or ""))
            src = html.escape(str(item.get("source") or ""))
            kind = html.escape(str(item.get("kind") or ""))
            summary = html.escape(str(item.get("summary") or ""))
            rows.append(textwrap.dedent(f"""
                <tr class='tl-row' data-severity='{sev}'>
                  <td style="white-space:nowrap;font-family:Consolas,
                             monospace;font-size:12px;">{ts}</td>
                  <td><span class='pill' style='background:{color}'>
                      {SEV_LABEL[sev]}</span></td>
                  <td style="color:var(--fg-dim);font-size:12px;">
                      {src} / {kind}</td>
                  <td>{summary}</td>
                </tr>
            """))
        return textwrap.dedent(f"""
            <div class="section">
              <h2>11. Super-Timeline &mdash; Chronological View</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Unified chronological view across findings, event
                  logs, BAM, prefetch and crash dumps. Most recent
                  events appear first.
                </p>
                <div style="max-height:560px;overflow:auto;">
                <table>
                  <thead><tr>
                    <th style="width:180px">Timestamp (UTC)</th>
                    <th style="width:90px">Severity</th>
                    <th style="width:180px">Source</th>
                    <th>Summary</th>
                  </tr></thead>
                  <tbody>{''.join(rows)}</tbody>
                </table>
                </div>
              </div>
            </div>
        """)

    # -- Interactive JS (client-side filter, ATT&CK styling) ---------

    def _interactive_js(self) -> str:
        lang = (self.metadata.get("lang") or "en").lower()
        rtl_init = "true" if lang == "he" else "false"
        return textwrap.dedent(f"""
            <script>
            (function() {{
                // ---- Filter (bottom-right) --------------------
                function makeFilter() {{
                    var input = document.createElement('input');
                    input.type = 'text';
                    input.placeholder = 'Filter...';
                    input.style.cssText =
                        'position:fixed;bottom:16px;right:16px;'+
                        'padding:8px 12px;border-radius:20px;'+
                        'background:#1b2232;color:#e6edf3;'+
                        'border:1px solid #27303f;width:260px;'+
                        'font-size:13px;z-index:9999;';
                    input.addEventListener('input', function() {{
                        var needle = input.value.toLowerCase();
                        var nodes = document.querySelectorAll(
                            'tr, details, .critfind');
                        nodes.forEach(function(n) {{
                            if (!needle) {{ n.style.display = ''; return; }}
                            var text = (n.textContent || '').toLowerCase();
                            n.style.display = text.indexOf(needle) >= 0
                                ? '' : 'none';
                        }});
                    }});
                    document.body.appendChild(input);
                }}

                // ---- Toolbar --------------------------------
                function makeToolbar() {{
                    var bar = document.createElement('div');
                    bar.className = 'toolbar';
                    function btn(label, handler) {{
                        var b = document.createElement('button');
                        b.textContent = label;
                        b.addEventListener('click', handler);
                        bar.appendChild(b);
                    }}
                    btn('Expand all', function() {{
                        document.querySelectorAll('details').forEach(
                            function(d) {{ d.open = true; }});
                    }});
                    btn('Collapse all', function() {{
                        document.querySelectorAll('details.section, '+
                            'details.deep').forEach(
                            function(d) {{ d.open = false; }});
                    }});
                    btn('Theme', function() {{
                        document.body.classList.toggle('light');
                        try {{ localStorage.setItem('fma-light',
                            document.body.classList.contains('light')
                            ? '1':'0'); }} catch(e) {{}}
                    }});
                    btn('RTL', function() {{
                        document.body.classList.toggle('rtl');
                        try {{ localStorage.setItem('fma-rtl',
                            document.body.classList.contains('rtl')
                            ? '1':'0'); }} catch(e) {{}}
                    }});
                    btn('Export JSON', function() {{
                        var data = {{ triage: collectTriage() }};
                        var blob = new Blob(
                            [JSON.stringify(data, null, 2)],
                            {{ type: 'application/json' }});
                        var a = document.createElement('a');
                        a.href = URL.createObjectURL(blob);
                        a.download = 'triage-export.json';
                        a.click();
                    }});
                    document.body.appendChild(bar);
                }}

                // ---- Triage state per finding --------------
                var STATES = ['open', 'confirmed', 'fp', 'dismissed',
                               'escalated'];
                var STATE_LABEL = {{
                    'open':'Open', 'confirmed':'Confirmed',
                    'fp':'False-Positive', 'dismissed':'Dismissed',
                    'escalated':'Escalated'
                }};
                function collectTriage() {{
                    var out = {{}};
                    try {{
                        Object.keys(localStorage).forEach(function(k) {{
                            if (k.indexOf('fma-triage-') === 0) {{
                                out[k.slice(11)] =
                                    localStorage.getItem(k);
                            }}
                        }});
                    }} catch(e) {{}}
                    return out;
                }}
                function attachTriage() {{
                    document.querySelectorAll('.critfind[id]').forEach(
                        function(card) {{
                            var anchor = card.id;
                            var lsKey = 'fma-triage-' + anchor;
                            var state;
                            try {{ state = localStorage.getItem(lsKey)
                                        || 'open'; }}
                            catch(e) {{ state = 'open'; }}
                            var btn = document.createElement('span');
                            btn.className = 'triage-state state-' + state;
                            btn.textContent = 'Triage: ' +
                                STATE_LABEL[state];
                            btn.title = 'Click to cycle: ' +
                                STATES.join(' -> ');
                            btn.addEventListener('click', function() {{
                                var i = STATES.indexOf(state);
                                state = STATES[(i + 1) %
                                    STATES.length];
                                try {{ localStorage.setItem(lsKey,
                                    state); }} catch(e) {{}}
                                btn.className =
                                    'triage-state state-' + state;
                                btn.textContent = 'Triage: ' +
                                    STATE_LABEL[state];
                            }});
                            var h4 = card.querySelector('h4');
                            if (h4) h4.appendChild(btn);
                        }});
                }}

                // ---- Restore preferences --------------------
                try {{
                    if (localStorage.getItem('fma-light') === '1')
                        document.body.classList.add('light');
                    if (localStorage.getItem('fma-rtl') === '1' ||
                        {rtl_init})
                        document.body.classList.add('rtl');
                }} catch(e) {{}}

                // ---- Process-tree severity filter ---------
                function initProcFilter() {{
                    document.querySelectorAll('.proc-filter-bar')
                        .forEach(function(bar) {{
                            var buttons = bar.querySelectorAll(
                                '.proc-filter-btn');
                            // Scope the rows to the nearest table
                            var sec = bar.closest(
                                'details.section') || document;
                            var rows = sec.querySelectorAll(
                                '.proc-tree-table tbody tr');
                            buttons.forEach(function(b) {{
                                b.addEventListener('click',
                                function() {{
                                    var filter = b.dataset.filter;
                                    rows.forEach(function(r) {{
                                        var flag = r.dataset.flag
                                            || '0';
                                        var sev =
                                            r.getAttribute(
                                              'data-flag-sev')
                                            || '0';
                                        var show = true;
                                        if (filter === 'flagged')
                                            show = (flag === '1');
                                        else if (filter !== 'all')
                                            show = (sev === filter);
                                        r.style.display = show
                                            ? '' : 'none';
                                    }});
                                    buttons.forEach(function(bb) {{
                                        bb.classList.toggle(
                                            'active', bb === b);
                                    }});
                                    // Auto-open the collapsible
                                    // when user filters
                                    var det = bar.parentElement
                                        .querySelector('details');
                                    if (det && filter !== 'all')
                                        det.open = true;
                                }});
                            }});
                        }});
                }}

                initProcFilter();
                makeToolbar();
                makeFilter();
                attachTriage();
            }})();
            </script>
        """)

    @staticmethod
    def _pretty_source(s: str) -> str:
        return {
            "memory":      "Memory Forensics (RAM)",
            "dump":        "Crash-Dump Analysis",
            "evtlog":      "Event Log Investigation",
            "autoruns":    "Autoruns (Registry + Startup)",
            "wmi":         "WMI Persistence",
            "defender":    "Windows Defender Configuration",
            "schtask":     "Scheduled Tasks",
            "prefetch":    "Prefetch (Execution Trace)",
            "live":        "Live Process-Tree Anomalies",
            "registry":    "Registry Artifacts",
            "mft":         "$MFT Filesystem Evidence",
            "correlation": "Cross-Source Correlation (IoA)",
            "mplog":       "Defender MPLog History",
            "usb":         "USB Device History",
            "com":         "COM Hijack Analysis",
            "etw":         "ETW Tampering Checks",
            "vss":         "Volume Shadow Copies",
            "lnk":         "LNK / Recent Docs",
            "bits":        "BITS Jobs",
            "browser":     "Browser Artifacts",
            "lsa":         "LSA / SAM Access",
            "sigma":       "Sigma Rule Matches",
            "bam":         "BAM/DAM Execution History",
            "srum":        "SRUM Resource Usage",
            "ioc":         "IoC Feed Matches",
        }.get(s, s)

    def _header(self) -> str:
        img = html.escape(self.metadata.get("image", "n/a"))
        host = html.escape(self.metadata.get("host", platform.node()))
        return textwrap.dedent(f"""
            <header>
              <h1>{TOOL_NAME}</h1>
              <div class="sub">
                Host: <b>{host}</b> &nbsp;|&nbsp;
                Image: <b>{img}</b> &nbsp;|&nbsp;
                Version: v{TOOL_VERSION}
              </div>
            </header>
        """)

    def _executive_briefing(self, score: int, band: str,
                              ring_color: str,
                              malicious: List[Finding],
                              observations: List[Finding]) -> str:
        """One-page management briefing that sits ABOVE the
        analyst-facing Executive Summary. Plain-language,
        traffic-light style, top-3 actions, business-risk
        framing. This is what a CISO/manager reads in 60
        seconds to decide whether to escalate."""
        sp = self.metadata.get("system_profile") or {}
        host = html.escape(sp.get("ComputerName")
                            or self.metadata.get("host") or "?")
        domain = html.escape(sp.get("Domain") or "-")
        os_cap = html.escape(sp.get("os_caption") or "?")
        ext_ip = html.escape(sp.get("external_ip") or "-")
        n_crit = sum(1 for f in malicious if f.severity == SEV_CRIT)
        n_high = sum(1 for f in malicious if f.severity == SEV_HIGH)
        n_med = len(observations)

        # Traffic light
        if band == "CRITICAL":
            tl_color = "#c0392b"; tl_label = "RED — ACTIVE INCIDENT"
            tl_msg = ("The host is showing confirmed signs of an "
                      "active or recent compromise. Stop using it, "
                      "isolate it from the network, and escalate "
                      "to incident response now.")
        elif band == "HIGH":
            tl_color = "#e67e22"; tl_label = "AMBER — URGENT REVIEW"
            tl_msg = ("The host has multiple high-severity findings "
                      "that need immediate investigation. Treat the "
                      "credentials on this host as untrusted until "
                      "the items below are explained.")
        elif band == "MEDIUM":
            tl_color = "#f39c12"; tl_label = "YELLOW — REVIEW"
            tl_msg = ("The host has notable findings that warrant "
                      "review. No immediate compromise indicators, "
                      "but a few items deserve a second look before "
                      "the end of the day.")
        else:
            tl_color = "#16a085"; tl_label = "GREEN — NO ISSUES"
            tl_msg = ("The host appears clean. All triaged signals "
                      "resolved to ordinary system behavior or "
                      "application bugs.")

        # Business risk translation
        cats = {f.category for f in malicious}
        business_risks: List[str] = []
        if any("credential" in c for c in cats):
            business_risks.append(
                "Credentials harvested — any password used on this "
                "endpoint may already be in attacker possession.")
        if any("injection" in c or "hollow" in c or "rootkit" in c
                or "integrity.pe_tamper" in c for c in cats):
            business_risks.append(
                "Host kernel / process integrity compromised — "
                "the endpoint cannot be trusted; rebuild from "
                "known-good media.")
        if any("lateral" in c for c in cats):
            business_risks.append(
                "Lateral movement detected — assume at least one "
                "other host in the environment is compromised.")
        if any("defender" in c for c in cats):
            business_risks.append(
                "Endpoint protection weakened — the attacker "
                "disabled Defender or added exclusions. The "
                "usual safety net is GONE on this host.")
        if any("darknet" in c or "exfil" in c for c in cats):
            business_risks.append(
                "Data likely exfiltrated to attacker "
                "infrastructure — consider legal / regulatory "
                "notification obligations.")
        if any(f.category == "auth.bruteforce" and
                (f.evidence or {}).get("success_after_burst")
                for f in malicious):
            business_risks.append(
                "Successful brute-force on an endpoint account — "
                "revoke the account and rotate its password "
                "immediately.")
        if not business_risks:
            business_risks.append(
                "No direct business-critical risk identified. "
                "The findings above are informational.")

        # Top-3 action items for the manager
        actions: List[str] = []
        if band in ("CRITICAL", "HIGH"):
            actions.append(
                "Isolate this host from the network (disable NIC "
                "or pull cable) while preserving RAM.")
            actions.append(
                "Reset passwords for every account that has "
                "logged into this host in the last 30 days.")
        if any("persistence" in c for c in cats):
            actions.append(
                "Remove the attacker's persistence entries "
                "(listed in the Persistence Inventory section) "
                "before re-enabling the host.")
        if any("lateral" in c for c in cats):
            actions.append(
                "Begin parallel triage on the source host of the "
                "network logon recorded in the Lateral findings.")
        if any("defender" in c for c in cats):
            actions.append(
                "Restore Defender real-time protection and "
                "investigate who disabled it.")
        if not actions:
            actions = [
                "No immediate action required.",
                "Retain this report and forensic artifacts for "
                "the standard retention window.",
                "Re-run with `--baseline previous.json` periodically "
                "to catch NEW persistence-shaped changes.",
            ]

        risks_html = "".join(
            f"<li style='margin:4px 0;'>{html.escape(r)}</li>"
            for r in business_risks[:5])
        actions_html = "".join(
            f"<li style='margin:4px 0;'>{html.escape(a)}</li>"
            for a in actions[:5])

        return textwrap.dedent(f"""
            <div class="section">
              <h2>Executive Briefing &mdash; 60-Second Read</h2>
              <div class="section-body">
                <!-- Traffic-light banner -->
                <div style='background:{tl_color};
                            padding:14px 20px;border-radius:10px;
                            color:#fff;margin-bottom:16px;
                            box-shadow:0 2px 8px rgba(0,0,0,.3);'>
                  <div style='font-size:11px;
                               text-transform:uppercase;
                               letter-spacing:0.08em;
                               font-weight:700;opacity:0.9;'>
                    Overall posture
                  </div>
                  <div style='font-size:24px;font-weight:700;
                               margin-top:4px;'>
                    {tl_label}
                  </div>
                  <div style='margin-top:6px;font-size:13px;
                               line-height:1.5;opacity:0.95;'>
                    {html.escape(tl_msg)}
                  </div>
                </div>

                <!-- KPIs in a row -->
                <div style='display:grid;
                            grid-template-columns:repeat(5,1fr);
                            gap:10px;margin-bottom:16px;'>
                  <div style='background:var(--panel2);
                               padding:10px 14px;border-radius:8px;
                               text-align:center;'>
                    <div style='font-size:10px;
                                 text-transform:uppercase;
                                 color:var(--fg-dim);
                                 letter-spacing:.06em;'>Critical</div>
                    <div style='font-size:26px;font-weight:700;
                                 color:#c0392b;'>{n_crit}</div>
                  </div>
                  <div style='background:var(--panel2);
                               padding:10px 14px;border-radius:8px;
                               text-align:center;'>
                    <div style='font-size:10px;
                                 text-transform:uppercase;
                                 color:var(--fg-dim);
                                 letter-spacing:.06em;'>High</div>
                    <div style='font-size:26px;font-weight:700;
                                 color:#e67e22;'>{n_high}</div>
                  </div>
                  <div style='background:var(--panel2);
                               padding:10px 14px;border-radius:8px;
                               text-align:center;'>
                    <div style='font-size:10px;
                                 text-transform:uppercase;
                                 color:var(--fg-dim);
                                 letter-spacing:.06em;'>Medium</div>
                    <div style='font-size:26px;font-weight:700;
                                 color:#f39c12;'>{n_med}</div>
                  </div>
                  <div style='background:var(--panel2);
                               padding:10px 14px;border-radius:8px;
                               text-align:center;'>
                    <div style='font-size:10px;
                                 text-transform:uppercase;
                                 color:var(--fg-dim);
                                 letter-spacing:.06em;'>Score</div>
                    <div style='font-size:26px;font-weight:700;
                                 color:{ring_color};'>
                      {score}<span style='font-size:14px;
                                            color:var(--fg-dim);'>/100</span>
                    </div>
                  </div>
                  <div style='background:var(--panel2);
                               padding:10px 14px;border-radius:8px;
                               text-align:center;'>
                    <div style='font-size:10px;
                                 text-transform:uppercase;
                                 color:var(--fg-dim);
                                 letter-spacing:.06em;'>Band</div>
                    <div style='font-size:18px;font-weight:700;
                                 color:{ring_color};
                                 margin-top:6px;'>{band}</div>
                  </div>
                </div>

                <!-- The endpoint (identity line) -->
                <div style='background:var(--panel2);
                            padding:10px 14px;border-radius:8px;
                            font-size:12px;
                            color:var(--fg-dim);
                            margin-bottom:16px;'>
                  <b style='color:var(--fg);'>Endpoint:</b>
                  {host} &nbsp; · &nbsp;
                  <b style='color:var(--fg);'>OS:</b> {os_cap}
                  &nbsp; · &nbsp;
                  <b style='color:var(--fg);'>Domain:</b> {domain}
                  &nbsp; · &nbsp;
                  <b style='color:var(--fg);'>External IP:</b>
                  {ext_ip}
                </div>

                <!-- Business risk -->
                <div style='display:grid;
                            grid-template-columns:1fr 1fr;
                            gap:16px;'>
                  <div style='background:var(--panel2);
                               padding:14px 18px;border-radius:8px;
                               border-left:3px solid #e67e22;'>
                    <div style='font-size:11px;
                                 text-transform:uppercase;
                                 letter-spacing:.06em;
                                 color:#fbbf24;font-weight:700;
                                 margin-bottom:6px;'>
                      Business risk
                    </div>
                    <ul style='margin:0;padding-left:18px;
                                font-size:13px;line-height:1.55;'>
                      {risks_html}
                    </ul>
                  </div>
                  <div style='background:var(--panel2);
                               padding:14px 18px;border-radius:8px;
                               border-left:3px solid #16a085;'>
                    <div style='font-size:11px;
                                 text-transform:uppercase;
                                 letter-spacing:.06em;
                                 color:#4ade80;font-weight:700;
                                 margin-bottom:6px;'>
                      Recommended actions
                    </div>
                    <ol style='margin:0;padding-left:18px;
                                font-size:13px;line-height:1.55;'>
                      {actions_html}
                    </ol>
                  </div>
                </div>

                <p style='color:var(--fg-dim);font-size:11px;
                          margin-top:14px;text-align:right;'>
                  Detail below &mdash; every item is clickable
                  and linked to its forensic evidence.
                </p>
              </div>
            </div>
        """)

    def _executive(self, score: int, band: str, color: str,
                   malicious: List[Finding],
                   observations: List[Finding],
                   informational: List[Finding]) -> str:
        verdict_line = self._verdict_line(malicious, band)
        # Unified findings block — all severities, clickable,
        # replaces the separate Findings Index section.
        findings_block = self._exec_findings_block(
            malicious + observations + informational)
        coverage = self._coverage_summary()
        return textwrap.dedent(f"""
            <section class="grid">
              <div class="card" style="grid-column:1 / span 2;">
                <h3>Executive Summary &mdash; Findings</h3>
                <p style="font-size:15px;">{verdict_line}</p>
                {findings_block}
                <p style="color:var(--fg-dim);font-size:12px;
                          margin-top:14px;">
                  Every finding in this report has an investigator
                  conclusion — no "please check X" advisories. Known-
                  vendor services, benign keyboard typos, ordinary app
                  crashes and self-referential detector scripts are
                  actively filtered out.
                </p>
              </div>
              <div class="card" style="text-align:center;">
                <h3>Threat Severity Score</h3>
                <div class="score-ring"
                     style="box-shadow:inset 0 0 0 6px {color};
                            margin:10px auto; color:{color};">
                  {score}
                </div>
                <div style="font-weight:600; color:{color};">{band}</div>
                <div style="color:var(--fg-dim); font-size:11px;
                            margin-top:6px;">
                  Dedup + per-category decay scoring
                </div>
                <div style="margin-top:14px;font-size:12px;
                            color:var(--fg-dim);">
                  <b>{len(malicious)}</b> malicious &middot;
                  <b>{len(observations)}</b> obs &middot;
                  <b>{len(informational)}</b> info
                </div>
              </div>
              <div class="card" style="grid-column:1 / span 3;">
                <h3>Coverage &mdash; What Was Analyzed</h3>
                {coverage}
              </div>
            </section>
        """)

    def _exec_findings_block(self,
                              all_findings: List[Finding]) -> str:
        """Unified Executive Summary: every finding (Critical →
        Informational) rendered as a clickable card that jumps to
        its full forensic report further down. Grouped by severity
        with per-bucket counts so the reader can scan fast."""
        if not all_findings:
            return ("<p style='color:var(--fg-dim);font-size:14px;'>"
                    "No findings produced by this run. All triaged "
                    "signals resolved to ordinary system behavior or "
                    "application bugs after FP filtering.</p>")

        # Group by severity, descending
        by_sev: Dict[int, List[Finding]] = {
            5: [], 4: [], 3: [], 2: [], 1: []}
        for f in all_findings:
            by_sev.setdefault(f.severity, []).append(f)

        # Stable sort inside each bucket
        for s in by_sev:
            by_sev[s].sort(key=lambda f: (f.source, f.category,
                                           f.title))

        def _render_card(f: Finding, compact: bool = False) -> str:
            color = SEV_COLOR[f.severity]
            anchor = f.anchor_id()
            pb = kill_chain_for_finding(f)
            phase = pb.get("phase", "")
            impact = pb.get("impact", "")
            impact_short = impact.split(".")[0] + "." if impact \
                else ""

            if compact:
                # Low / Info → single-line with title + conclusion
                return textwrap.dedent(f"""
                    <li style='margin:6px 0;'>
                      <a href='#{anchor}'
                         style='color:var(--fg);text-decoration:none;
                                display:flex;align-items:center;
                                gap:10px;padding:6px 12px;
                                border-radius:6px;
                                transition:background 120ms ease;'
                         onmouseover="this.style.background=
                             'rgba(91,157,255,0.08)';"
                         onmouseout="this.style.background=
                             'transparent';">
                        <span class='pill'
                              style='background:{color};'>
                          {SEV_LABEL[f.severity]}
                        </span>
                        <b style='font-size:13px;'>
                          {html.escape(f.title)}
                        </b>
                        <span style='color:var(--fg-dim);
                                     font-size:11px;'>
                          [{html.escape(f.source)}/{html.escape(f.category)}]
                        </span>
                        <span style='color:#5b9dff;font-size:11px;
                                     margin-left:auto;'>
                          &#x25b8; jump
                        </span>
                      </a>
                    </li>
                """)

            # Full card for Critical / High / Medium
            return textwrap.dedent(f"""
                <li style='margin:14px 0;'>
                  <a href='#{anchor}'
                     style='color:var(--fg);text-decoration:none;
                            display:block;padding:10px 14px;
                            border-radius:8px;border:1px solid
                            var(--border);
                            transition:background 120ms ease,
                                       border-color 120ms ease;'
                     onmouseover="this.style.background=
                         'rgba(91,157,255,0.08)';this.style.borderColor=
                         'rgba(91,157,255,0.35)';"
                     onmouseout="this.style.background='transparent';
                         this.style.borderColor='';">
                    <div style='display:flex;align-items:center;
                                gap:10px;flex-wrap:wrap;'>
                      <span class='pill' style='background:{color}'>
                        {SEV_LABEL[f.severity]}
                      </span>
                      <b style='font-size:14px;'>
                        {html.escape(f.title)}
                      </b>
                      <span style='color:var(--fg-dim);
                                   font-size:11px;'>
                        [{html.escape(f.source)}/{html.escape(f.category)}]
                      </span>
                      <span style='color:#5b9dff;font-size:11px;
                                   margin-left:auto;'>
                        &#x25b8; jump to finding
                      </span>
                    </div>
                    <div style='margin-top:8px;'>
                      <div style='font-size:10px;font-weight:600;
                                   color:#f87171;
                                   text-transform:uppercase;
                                   letter-spacing:0.05em;
                                   margin-bottom:2px;'>
                        What happened
                      </div>
                      <div style='color:var(--fg);font-size:13px;
                                   line-height:1.5;'>
                        {html.escape(f.conclusion)}
                      </div>
                    </div>
                    <div style='margin-top:8px;'>
                      <div style='font-size:10px;font-weight:600;
                                   color:#fbbf24;
                                   text-transform:uppercase;
                                   letter-spacing:0.05em;
                                   margin-bottom:2px;'>
                        What it means
                      </div>
                      <div style='color:var(--fg-dim);font-size:12px;
                                   line-height:1.45;'>
                        <b>Phase:</b> {html.escape(phase)}
                        {'<br><b>Impact:</b> ' + html.escape(impact_short)
                          if impact_short else ''}
                      </div>
                    </div>
                  </a>
                </li>
            """)

        # Group-by-severity rendering with heading + count
        sev_meta = [
            (5, "CRITICAL", "#c0392b", False),
            (4, "HIGH",     "#e67e22", False),
            (3, "MEDIUM",   "#f39c12", False),
            (2, "LOW",      "#16a085", True),   # compact
            (1, "INFORMATIONAL", "#6c7a89", True),
        ]
        blocks: List[str] = []
        for sev_num, label, color, compact in sev_meta:
            items = by_sev.get(sev_num, [])
            if not items:
                continue
            cards = "".join(_render_card(f, compact=compact)
                            for f in items)
            # Low/Info start collapsed inside a details so the exec
            # summary isn't overwhelmed; Critical/High/Medium are
            # always visible.
            if compact:
                blocks.append(textwrap.dedent(f"""
                    <details style='margin-top:16px;'>
                      <summary style='cursor:pointer;
                                       background:var(--panel2);
                                       padding:8px 12px;
                                       border-radius:6px;
                                       font-weight:600;
                                       color:{color};
                                       list-style:none;'>
                        {label} &nbsp;
                        <span style='color:var(--fg-dim);
                                     font-weight:normal;
                                     font-size:12px;'>
                          ({len(items)})
                        </span>
                      </summary>
                      <ol style='margin-top:6px;
                                   padding-left:16px;
                                   list-style:none;'>
                        {cards}
                      </ol>
                    </details>
                """))
            else:
                blocks.append(textwrap.dedent(f"""
                    <div style='margin-top:14px;'>
                      <div style='font-weight:700;font-size:13px;
                                   color:{color};
                                   text-transform:uppercase;
                                   letter-spacing:0.06em;
                                   margin-bottom:4px;'>
                        {label}
                        <span style='color:var(--fg-dim);
                                     font-weight:normal;
                                     font-size:12px;'>
                          ({len(items)})
                        </span>
                      </div>
                      <ol style='margin:4px 0 0;padding-left:22px;'>
                        {cards}
                      </ol>
                    </div>
                """))
        return "\n".join(blocks)

    def _coverage_summary(self) -> str:
        """Two-column table summarizing which collection modules ran
        and what they produced. Shows the client which artifacts were
        inspected."""
        rows = [
            ("Memory image (Volatility3)",
             "Processed" if self.metadata.get("image") not in
             ("live triage", "n/a", "") else "Not supplied "
             "(live process-tree analysis used instead)"),
            ("Crash dumps (MEMORY.DMP / Minidump / WER)",
             f"{self.metadata.get('dumps_found', 0)} discovered"),
            ("Windows Event Logs",
             html.escape(self.metadata.get(
                 "evtx_inputs", "(none)"))),
            ("Registry hives (Amcache / Shimcache / UserAssist)",
             "Requires admin + offline snapshot "
             "(reg save / VSS)"),
            ("Autoruns — Run / RunOnce / Winlogon / AppInit / IFEO",
             "Live HKLM + HKCU enumeration"),
            ("Startup folders (user + common)",
             "Enumerated"),
            ("WMI event-subscription persistence",
             "Queried root\\subscription"),
            ("Windows Defender (AV / RTP / exclusions / tamper)",
             "Get-MpPreference + Get-MpComputerStatus"),
            ("Scheduled Tasks",
             "Parsed C:\\Windows\\System32\\Tasks XML"),
            ("Prefetch (execution history)",
             "Scanned %SystemRoot%\\Prefetch"),
            ("Live process tree (parent-child anomalies)",
             "psutil snapshot"),
            ("$MFT (filesystem triage)",
             ("Parsed" if self.metadata.get("mft_records", 0)
              else "Not supplied (optional)")),
            ("Cross-source correlation engine",
             "RAM ↔ Log ↔ Disk ↔ Dump"),
        ]
        body = "".join(
            f"<tr><td style='width:45%'><b>{html.escape(k)}</b></td>"
            f"<td style='color:var(--fg-dim);'>"
            f"{v}</td></tr>"
            for k, v in rows)
        return f"<table>{body}</table>"

    @staticmethod
    def _verdict_line(malicious: List[Finding], band: str) -> str:
        if not malicious:
            return ("No malicious activity was confirmed on this host. "
                    "The investigator processed RAM artifacts, crash "
                    "dumps, event logs, registry, scheduled tasks, "
                    "autoruns, prefetch, $MFT and the live process "
                    "tree without finding high-confidence indicators "
                    "of compromise.")
        cats = {f.category for f in malicious}
        narrative: List[str] = []
        if any("credential" in c for c in cats):
            narrative.append("LSASS credential access")
        if any("injection" in c or "hollow" in c for c in cats):
            narrative.append("in-memory code injection")
        if any("rootkit" in c for c in cats):
            narrative.append("rootkit activity")
        if "lateral.smb_service" in cats:
            narrative.append("lateral movement via SMB+service")
        if any(c.startswith("corr.") for c in cats):
            narrative.append("cross-source attack-chain correlation")
        if any("persistence" in c for c in cats):
            narrative.append("attacker persistence")
        if "auth.bruteforce" in cats and any(
                f.category == "auth.bruteforce"
                and f.evidence.get("success_after_burst")
                for f in malicious):
            narrative.append("a successful brute-force login")
        summary = ("The investigator confirmed "
                   + ", ".join(narrative) + "." if narrative
                   else "The investigator confirmed security-relevant "
                   "anomalies on this host.")
        return (f"{summary} Overall threat band: <b>{band}</b>. "
                f"See the sections below for per-finding verdicts and "
                "evidence.")

    @staticmethod
    def _malicious_summary_list(malicious: List[Finding]) -> str:
        if not malicious:
            return ("<p style='color:var(--fg-dim)'>No confirmed "
                    "malicious findings in this run.</p>")
        items = "".join(
            f"<li><span class='pill' "
            f"style='background:{SEV_COLOR[f.severity]}'>"
            f"{SEV_LABEL[f.severity]}</span> &nbsp; "
            f"{html.escape(f.title)}</li>"
            for f in malicious[:8])
        more = (f"<li style='color:var(--fg-dim);'>(+ "
                f"{len(malicious) - 8} more)</li>"
                if len(malicious) > 8 else "")
        return f"<ul style='margin:4px 0 0 16px;padding:0;'>{items}{more}</ul>"

    # -- Memory Forensics section --------------------------------------

    def _memory_forensics_section(self) -> str:
        memory_findings = [f for f in self.findings
                           if f.source == "memory"]
        live_findings = [f for f in self.findings if f.source == "live"]
        dump_findings = [f for f in self.findings if f.source == "dump"]
        image = self.metadata.get("image", "")
        ran_memory_image = image not in ("live triage", "n/a", "")

        # Executive paragraph
        paras: List[str] = []
        if ran_memory_image:
            paras.append(
                f"A memory image ({html.escape(str(image))}) was "
                f"processed with Volatility3. {len(memory_findings)} "
                "memory-forensics finding(s) were produced.")
        else:
            paras.append(
                "No offline memory image was supplied, so "
                "Volatility3-based analysis (injection detection, "
                "rootkit detection, LSASS handle sweeps, carved-PE "
                "extraction) was not run. "
                "The investigator fell back to live process-tree "
                f"analysis, which produced {len(live_findings)} "
                "process-tree finding(s).")
        paras.append(
            f"Auto-discovered crash dumps on this host: "
            f"<b>{self.metadata.get('dumps_found', 0)}</b>. After "
            "filtering out known-benign application crashes "
            "(runtime asserts in flaky apps), "
            f"<b>{len(dump_findings)}</b> crash finding(s) remained.")
        para_html = "".join(f"<p>{p}</p>" for p in paras)

        # Key indicators (categories) grouped by RAM / live / dump.
        def _group(items: List[Finding], label: str) -> str:
            if not items:
                return (f"<div style='margin:8px 0;color:var(--fg-dim)'>"
                        f"{label}: no findings.</div>")
            blocks = [self._malicious_card(f) for f in items
                      if f.severity >= SEV_HIGH]
            if not blocks:
                tbl_rows = "".join(
                    f"<tr><td><span class='pill' "
                    f"style='background:{SEV_COLOR[f.severity]}'>"
                    f"{SEV_LABEL[f.severity]}</span></td>"
                    f"<td><b>{html.escape(f.title)}</b><br>"
                    f"<span style='color:var(--fg-dim);font-size:12px;'>"
                    f"{html.escape(f.conclusion)[:260]}</span></td></tr>"
                    for f in items)
                return (f"<h3 style='margin-top:14px'>{label}</h3>"
                        f"<table>{tbl_rows}</table>")
            return (f"<h3 style='margin-top:18px'>{label}</h3>"
                    + "".join(blocks))

        body = "".join([
            _group(memory_findings, "RAM / Volatility3"),
            _group(live_findings, "Live Process Tree"),
            _group(dump_findings, "Crash Dumps"),
        ])

        return textwrap.dedent(f"""
            <div class="section">
              <h2>8. Memory Forensics &mdash; Executive Summary</h2>
              <div class="section-body">
                {para_html}
                {body}
              </div>
            </div>
        """)

    # -- Malicious-findings body ---------------------------------------

    def _malicious_section(self, malicious: List[Finding]) -> str:
        if not malicious:
            return textwrap.dedent("""
                <div class="section">
                  <h2>Confirmed Malicious Findings</h2>
                  <div class="section-body">
                    <p style="color:var(--fg-dim)">None surfaced after
                    false-positive filtering.</p>
                  </div>
                </div>
            """)
        # Skip memory/live/dump findings here — already shown in the
        # dedicated Memory Forensics section. Avoid double presentation.
        body_findings = [f for f in malicious
                         if f.source not in ("memory", "live", "dump")]
        if not body_findings:
            return ""
        blocks = "".join(self._malicious_card(f) for f in body_findings)
        return textwrap.dedent(f"""
            <div class="section">
              <h2>9. Confirmed Malicious Findings &mdash; Investigator
                  Conclusions</h2>
              <div class="section-body">{blocks}</div>
            </div>
        """)

    def _malicious_card(self, f: Finding) -> str:
        color = SEV_COLOR[f.severity]
        anchor = f.anchor_id()
        tags = " ".join(f"<span class='tag'>{html.escape(t)}</span>"
                        for t in f.tags)
        ev_table = self._render_evidence_table(f.summary_evidence())
        refs_block = self._render_forensic_refs(f)
        deep_block = self._render_deep_dive(f)
        quote_block = self._render_malicious_quote(f)
        corr = ""
        if f.correlated:
            rows = "".join(
                f"<tr><td>{html.escape(str(c.get('TimeCreated', '')))}</td>"
                f"<td>{html.escape(str(c.get('EventID', '')))}</td>"
                f"<td>{html.escape(str(c.get('IpAddress', '')))}</td>"
                f"<td>{html.escape(str(c.get('LogonType', '')))}</td></tr>"
                for c in f.correlated[:8])
            corr = ("<h4 style='margin-top:14px'>Correlated events</h4>"
                    "<table><thead><tr><th>Time</th><th>EventID</th>"
                    "<th>IP</th><th>LogonType</th></tr></thead>"
                    f"<tbody>{rows}</tbody></table>")
        raw = html.escape(json.dumps(f.evidence, indent=2,
                                      default=str))
        return textwrap.dedent(f"""
          <div id="{anchor}" class="critfind"
               style="border-color:{color};">
            <h4>
              <span class='pill' style='background:{color}'>
                {SEV_LABEL[f.severity]}
              </span>
              &nbsp;{html.escape(f.title)}
              <span style="color:var(--fg-dim);font-size:12px;">
                &nbsp; [{f.source}/{f.category}]
                &nbsp; <a href="#{anchor}"
                          style="color:var(--fg-dim);
                                 text-decoration:none;"
                          title="permalink">#</a>
              </span>
            </h4>
            <div class="verdict" style="border-left-color:{color};">
              <b>Investigator Conclusion:</b>
              {html.escape(f.conclusion)}
            </div>
            {quote_block}
            <div style="color:var(--fg-dim);font-size:12px;
                        margin-top:8px;">
              {html.escape(f.description)}
            </div>
            <div class="tagbar" style="margin-top:8px;">{tags}</div>
            {refs_block}
            {deep_block}
            <h4 style="margin-top:14px">Key evidence</h4>
            {ev_table}
            {corr}
            <details style="margin-top:10px;"><summary>Raw data (JSON)
              </summary>
              <div class='body'><pre>{raw}</pre></div></details>
          </div>
        """)

    @staticmethod
    def _render_malicious_quote(f: Finding) -> str:
        """Render the 'smoking gun' quote — the specific string /
        path / command that constitutes the malicious behavior.
        Very prominent so the analyst sees what is malicious at
        first glance."""
        q = f.malicious_quote()
        if not q:
            return ""
        value = str(q.get("value") or "")[:800]
        label = str(q.get("label") or "")
        context = str(q.get("context") or "")
        context_html = (
            f"<div style='color:var(--fg-dim);font-size:11px;"
            f"margin-top:6px;'>{html.escape(context)}</div>"
            if context else "")
        return textwrap.dedent(f"""
            <div style='margin:10px 0; background:#2a1212;
                 border:1px solid #7a231b;
                 border-left:3px solid #c0392b;
                 padding:10px 14px; border-radius:6px;'>
              <div style='font-size:10px; color:#f87171;
                          text-transform:uppercase;
                          letter-spacing:.06em;
                          font-weight:600; margin-bottom:6px;'>
                What is malicious · {html.escape(label)}
              </div>
              <code style='display:block;
                            white-space:pre-wrap;
                            word-break:break-all;
                            font-size:12px;
                            background:transparent;
                            border:none; padding:0;
                            color:#fca5a5;'>
                {html.escape(value)}
              </code>
              {context_html}
            </div>
        """)

    @staticmethod
    def _render_deep_dive(f: Finding) -> str:
        """Deep-dive analysis block — collapsible. Attack-chain
        phase, confidence score, impact, MITRE detail, hunting
        queries, remediation playbook."""
        deep = f.deep_analysis()
        confidence = deep["confidence"]
        # Confidence bar
        bar = (f"<div class='confidence-bar'>"
               f"<div class='confidence-fill' "
               f"style='width:{confidence}%;'></div></div>")
        conf_reasons = "".join(
            f"<li>{html.escape(r)}</li>"
            for r in deep["confidence_reasons"]) \
            or "<li>Base score only.</li>"

        # MITRE detail
        mitre_rows = ""
        for t in deep["mitre"]:
            mitre_rows += (
                f"<tr><td><code><a href='{t['url']}' "
                f"target='_blank' rel='noopener'>"
                f"{html.escape(t['id'])}</a></code></td>"
                f"<td>{html.escape(t['name'])}</td>"
                f"<td style='color:var(--fg-dim);font-size:11px;'>"
                f"{html.escape(t['tactic'])}</td></tr>")
        mitre_block = (
            f"<table style='font-size:12px;'>"
            f"<thead><tr><th>ID</th><th>Technique</th>"
            f"<th>Tactic</th></tr></thead>"
            f"<tbody>{mitre_rows}</tbody></table>"
            if mitre_rows else
            "<p style='color:var(--fg-dim)'>No MITRE tags.</p>")

        # Hunting queries
        queries = deep.get("queries") or {}
        queries_html = ""
        for lang, q in queries.items():
            queries_html += (
                f"<div class='query-lang'>"
                f"{html.escape(lang.upper())}</div>"
                f"<div class='query-box'>{html.escape(q)}</div>")
        if not queries_html:
            queries_html = (
                "<p style='color:var(--fg-dim);font-size:12px;'>"
                "No pre-canned hunt query for this category — "
                "use the IOCs panel to build one.</p>")

        # Immediate / hardening lists
        immediate_html = "".join(
            f"<li>{html.escape(s)}</li>"
            for s in deep["immediate_actions"])
        hardening_html = "".join(
            f"<li>{html.escape(s)}</li>"
            for s in deep["hardening"])

        # Threat-intel block if present
        ti = (f.evidence or {}).get("threat_intel") or {}
        ti_html = ""
        if ti:
            vt = ti.get("virustotal") or {}
            if vt:
                bad = vt.get("malicious", 0)
                sus = vt.get("suspicious", 0)
                hh = vt.get("harmless", 0)
                und = vt.get("undetected", 0)
                css = "ioc-vt-bad" if bad >= 3 else "ioc-vt-ok"
                label = vt.get("threat_label") or ""
                families = vt.get("threat_families") or []
                categories = vt.get("threat_categories") or []
                vt_url = vt.get("vt_url") or ""
                top_det = vt.get("top_detections") or []
                det_html = ""
                if top_det:
                    rows = "".join(
                        f"<li style='font-size:11px;'>"
                        f"<code>{html.escape(d)}</code></li>"
                        for d in top_det[:8])
                    det_html = (
                        f"<div style='margin-top:6px;'>"
                        f"<b style='font-size:11px;'>Top detections"
                        f"</b><ul style='margin:4px 0 0 18px;"
                        f"padding:0;'>{rows}</ul></div>")
                link_html = (
                    f"<p style='margin-top:8px;'>"
                    f"<a href='{html.escape(vt_url)}' "
                    f"target='_blank' rel='noopener' "
                    f"style='color:#5b9dff;font-weight:600;"
                    f"text-decoration:none;'>"
                    f"&#x2192; Open VirusTotal report"
                    f"</a></p>"
                    if vt_url else "")
                ti_html += (
                    f"<div class='deep-card'>"
                    f"<h5>VirusTotal</h5>"
                    f"<p><span class='{css}' "
                    f"style='font-size:14px;'>"
                    f"{bad} malicious</span> / "
                    f"{sus} suspicious / "
                    f"{hh} harmless / "
                    f"{und} undetected</p>"
                    + (f"<p style='font-size:12px;'>"
                       f"<b>Threat:</b> "
                       f"{html.escape(label)}</p>"
                       if label else "")
                    + (f"<p style='font-size:11px;'>"
                       f"<b>Families:</b> "
                       f"{html.escape(', '.join(families))}</p>"
                       if families else "")
                    + (f"<p style='font-size:11px;'>"
                       f"<b>Categories:</b> "
                       f"{html.escape(', '.join(categories))}</p>"
                       if categories else "")
                    + f"<p style='color:var(--fg-dim);font-size:11px;'>"
                    + f"Seen as: "
                    + html.escape(
                        ', '.join(vt.get('names') or [])[:200])
                    + f"</p>"
                    + det_html
                    + link_html
                    + f"</div>")
            abuse = ti.get("abuseipdb") or {}
            for ip, a in abuse.items():
                css = "ioc-vt-bad" if a.get("abuse_score",
                                             0) >= 50 else ""
                ti_html += (
                    f"<div class='deep-card'>"
                    f"<h5>AbuseIPDB: {html.escape(ip)}</h5>"
                    f"<p><span class='{css}'>"
                    f"abuse score {a.get('abuse_score',0)}</span>, "
                    f"{a.get('total_reports',0)} reports, "
                    f"country {a.get('country','?')}, "
                    f"ISP {html.escape(a.get('isp') or '?')}"
                    f"</p></div>")
            geo = ti.get("geoip") or {}
            for ip, g in geo.items():
                ti_html += (
                    f"<div class='deep-card'>"
                    f"<h5>GeoIP: {html.escape(ip)}</h5>"
                    f"<p>{html.escape(g.get('country_name') or '?')} "
                    f"({html.escape(g.get('country') or '?')})"
                    + (f", city {html.escape(g.get('city') or '?')}"
                       if g.get('city') else "")
                    + "</p></div>")

        return textwrap.dedent(f"""
            <details class='deep'>
              <summary>&#x1F50D; Deep-Dive Analysis
                &middot; Confidence {confidence}/100
                &middot; {html.escape(str(deep['kill_chain_phase']))}
              </summary>
              <div class='deep-body'>
                <div class='deep-grid'>
                  <div class='deep-card'>
                    <h5>Kill-Chain Position</h5>
                    <p>{html.escape(str(deep['kill_chain_phase']))}</p>
                    <h5 style='margin-top:10px;'>Impact</h5>
                    <p style='font-size:12px;'>
                      {html.escape(deep['impact'])}
                    </p>
                  </div>
                  <div class='deep-card'>
                    <h5>Confidence Score</h5>
                    {bar}
                    <p style='margin-top:6px;font-size:12px;'>
                      <b>{confidence}/100</b>
                    </p>
                    <ul style='font-size:11px;margin:6px 0 0 16px;
                                padding:0;color:var(--fg-dim);'>
                      {conf_reasons}
                    </ul>
                  </div>
                </div>
                {("<div class='deep-grid'>" + ti_html + "</div>")
                  if ti_html else ""}
                <h5 style='margin-top:14px;color:#3aa0ff;'>
                  MITRE ATT&amp;CK Mapping
                </h5>
                {mitre_block}
                <div class='deep-grid' style='margin-top:14px;'>
                  <div class='deep-card'>
                    <h5>Immediate Actions</h5>
                    <ol style='font-size:12px;margin:4px 0 0 18px;
                                padding:0;'>{immediate_html}</ol>
                  </div>
                  <div class='deep-card'>
                    <h5>Hardening (Long-term)</h5>
                    <ol style='font-size:12px;margin:4px 0 0 18px;
                                padding:0;'>{hardening_html
                                or "<li style='color:var(--fg-dim);'>"
                                "General hygiene.</li>"}</ol>
                  </div>
                </div>
                <h5 style='margin-top:14px;color:#3aa0ff;'>
                  Hunting Queries (for the fleet)
                </h5>
                {queries_html}
              </div>
            </details>
        """)

    @staticmethod
    def _render_forensic_refs(f: Finding) -> str:
        refs = f.forensic_references()
        if not refs:
            return ""
        rows = []
        for key, value in refs.items():
            if isinstance(value, list):
                v_html = "<br>".join(
                    f"<code>{html.escape(str(x))}</code>"
                    for x in value)
            elif isinstance(value, dict):
                v_html = "<br>".join(
                    f"<b>{html.escape(k)}:</b> "
                    f"<code>{html.escape(str(v))}</code>"
                    for k, v in value.items())
            else:
                v_html = f"<code>{html.escape(str(value))}</code>"
            rows.append(
                f"<tr><th style='width:150px;vertical-align:top'>"
                f"{html.escape(key)}</th><td>{v_html}</td></tr>")
        return textwrap.dedent(f"""
            <h4 style="margin-top:14px;color:#3aa0ff;">
              Forensic References
            </h4>
            <div class="refbox">
              <table class="refs">{''.join(rows)}</table>
            </div>
        """)

    # -- System Profile section ---------------------------------------

    def _system_profile_section(self) -> str:
        sp = self.metadata.get("system_profile") or {}
        if not sp:
            return ""

        # Primary identifiers
        primary_rows = []
        for label, key in [
            ("Hostname",         "hostname"),
            ("Computer Name",    "ComputerName"),
            ("Domain",           "Domain"),
            ("Workgroup",        "Workgroup"),
            ("Manufacturer",     "Manufacturer"),
            ("Model",            "Model"),
            ("BIOS Serial",      "bios_serial"),
            ("OS",               "os_caption"),
            ("OS Build",         "os_build"),
            ("OS Version",       "os_version"),
            ("Architecture",     "os_arch"),
            ("Install Date",     "os_install_date"),
            ("Last Boot",        "os_last_boot"),
            ("Timezone",         "timezone"),
            ("Total RAM (GB)",   "TotalMemoryGB"),
            ("CPUs",             "NumberOfCPUs"),
            ("External IP",      "external_ip"),
        ]:
            v = sp.get(key)
            if v not in (None, ""):
                primary_rows.append(
                    f"<tr><th style='width:220px'>"
                    f"{html.escape(label)}</th>"
                    f"<td><code>{html.escape(str(v))}</code></td></tr>")

        # Interfaces
        if_rows: List[str] = []
        for iface, info in (sp.get("interfaces") or {}).items():
            v4 = ", ".join(info.get("ipv4") or []) or "-"
            v6 = ", ".join(info.get("ipv6") or [])[:100] or "-"
            mac = info.get("mac") or "-"
            up = info.get("is_up")
            speed = info.get("speed_mbps")
            state = ("UP" if up else "DOWN") + \
                    (f" / {speed} Mb/s" if speed else "")
            if_rows.append(
                f"<tr><td><b>{html.escape(iface)}</b></td>"
                f"<td><code>{html.escape(mac)}</code></td>"
                f"<td><code>{html.escape(v4)}</code></td>"
                f"<td style='color:var(--fg-dim);font-size:11px;'>"
                f"{html.escape(v6)}</td>"
                f"<td>{html.escape(state)}</td></tr>")
        interfaces_html = ""
        if if_rows:
            interfaces_html = textwrap.dedent(f"""
                <h3 style="margin-top:16px;">Network Interfaces</h3>
                <table>
                  <thead><tr>
                    <th>Interface</th><th>MAC</th><th>IPv4</th>
                    <th>IPv6</th><th>State</th>
                  </tr></thead>
                  <tbody>{''.join(if_rows)}</tbody>
                </table>
            """)

        # Logged-on users (psutil) + local users (PS)
        users_html = ""
        psu = sp.get("logged_on_users") or []
        if psu:
            rows = "".join(
                f"<tr><td><b>{html.escape(u.get('name','?'))}</b></td>"
                f"<td>{html.escape(u.get('terminal') or '-')}</td>"
                f"<td>{html.escape(u.get('host') or '-')}</td>"
                f"<td>{html.escape(u.get('started') or '-')}</td>"
                f"</tr>"
                for u in psu)
            users_html += textwrap.dedent(f"""
                <h3 style="margin-top:16px;">Currently Logged-on</h3>
                <table>
                  <thead><tr>
                    <th>User</th><th>Terminal</th>
                    <th>Host</th><th>Since</th>
                  </tr></thead>
                  <tbody>{rows}</tbody>
                </table>
            """)
        locs = sp.get("local_users") or []
        if not isinstance(locs, list):
            locs = [locs]
        if locs:
            rows = []
            for u in locs:
                if not isinstance(u, dict):
                    continue
                rows.append(
                    f"<tr><td><b>{html.escape(str(u.get('Name','?')))}</b></td>"
                    f"<td>{'Enabled' if u.get('Enabled') else 'Disabled'}</td>"
                    f"<td>{html.escape(str(u.get('LastLogon') or '-'))}</td>"
                    f"<td style='color:var(--fg-dim);font-size:11px;'>"
                    f"{html.escape(str(u.get('Description') or ''))[:100]}</td>"
                    f"<td><code style='font-size:11px;'>"
                    f"{html.escape(str(u.get('SID') or ''))}</code></td></tr>")
            if rows:
                users_html += textwrap.dedent(f"""
                    <h3 style="margin-top:16px;">
                      Local User Accounts ({len(rows)})
                    </h3>
                    <table>
                      <thead><tr>
                        <th>User</th><th>State</th>
                        <th>Last Logon</th>
                        <th>Description</th><th>SID</th>
                      </tr></thead>
                      <tbody>{''.join(rows)}</tbody>
                    </table>
                """)

        admins = sp.get("local_administrators") or []
        if not isinstance(admins, list):
            admins = [admins]
        admins_html = ""
        if admins:
            rows = []
            for u in admins:
                if not isinstance(u, dict):
                    continue
                rows.append(
                    f"<tr><td><b>{html.escape(str(u.get('Name','?')))}</b></td>"
                    f"<td>{html.escape(str(u.get('PrincipalSource','?')))}</td>"
                    f"<td>{html.escape(str(u.get('ObjectClass','?')))}</td></tr>")
            if rows:
                admins_html = textwrap.dedent(f"""
                    <h3 style="margin-top:16px;">
                      Members of Local Administrators
                    </h3>
                    <table>
                      <thead><tr>
                        <th>Member</th><th>Source</th><th>Class</th>
                      </tr></thead>
                      <tbody>{''.join(rows)}</tbody>
                    </table>
                """)

        return textwrap.dedent(f"""
            <div class="section">
              <h2>1. System Information &mdash; The Endpoint Under
                  Investigation</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Primary identifiers of this host at report-generation
                  time. Correlate with your asset inventory to confirm
                  ownership, verify expected patch level / build, and
                  note which accounts were active during the incident
                  window.
                </p>
                <table>{''.join(primary_rows)}</table>
                {interfaces_html}
                {users_html}
                {admins_html}
              </div>
            </div>
        """)

    # -- Persistence Inventory ---------------------------------------

    def _persistence_inventory_section(self) -> str:
        persistence_cats = (
            "persistence", "autoruns", "schtask", "wmi",
            "persistence.service", "persistence.schtask",
            "persistence.run_encoded", "persistence.run_tempexec",
            "persistence.winlogon_hijack",
            "persistence.appinit_dll", "persistence.ifeo_hijack",
            "persistence.wmi_subscription",
            "persistence.bits_job", "persistence.com_hijack")
        items = [f for f in self.findings
                 if any(c in f.category for c in
                        ("persistence", "schtask", "autorun", "wmi",
                         "ifeo", "com_hijack", "winlogon", "appinit"))
                 or f.source in ("autoruns", "wmi", "schtask")]
        if not items:
            return ""
        rows = []
        for f in sorted(items, key=lambda x: -x.severity):
            anchor = f.anchor_id()
            ev = f.evidence or {}
            path = (ev.get("image_path") or ev.get("path")
                    or ev.get("value") or ev.get("ExecutablePath")
                    or ev.get("CommandLineTemplate")
                    or ev.get("commands") or "")
            if isinstance(path, list):
                path = " ".join(str(x) for x in path)
            location = (ev.get("hive") or ev.get("source")
                        or ev.get("profile") or "?")
            sha = ev.get("sha256", "")
            auth = ev.get("authenticode") or {}
            auth_status = auth.get("status") if isinstance(auth,
                                                            dict) else ""
            color = SEV_COLOR[f.severity]
            rows.append(textwrap.dedent(f"""
                <tr>
                  <td><span class='pill' style='background:{color}'>
                      {SEV_LABEL[f.severity]}</span></td>
                  <td><a href='#{anchor}'>
                      {html.escape(f.title[:80])}</a></td>
                  <td style='font-size:11px;'>{html.escape(f.source)}</td>
                  <td style='font-size:11px;word-break:break-all;'>
                      <code>{html.escape(str(path)[:220])}</code></td>
                  <td style='font-size:11px;word-break:break-all;'>
                      <code>{html.escape(str(location)[:120])}</code></td>
                  <td style='font-size:11px;'>
                      {html.escape((sha or '')[:12])}</td>
                  <td style='font-size:11px;'>
                      {html.escape(str(auth_status or '-'))}</td>
                </tr>
            """))
        return textwrap.dedent(f"""
            <div class="section">
              <h2>3. Persistence Inventory
                <span style='color:var(--fg-dim);font-size:13px;'>
                  ({len(items)} entries)
                </span>
              </h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Every persistence mechanism the analyzer surfaced —
                  services, scheduled tasks, registry autoruns,
                  Winlogon Userinit, AppInit_DLLs, IFEO debuggers, WMI
                  subscriptions, BITS jobs, startup folders, COM
                  hijacks. Click a row to jump to the full forensic
                  card.
                </p>
                <table>
                  <thead><tr>
                    <th>Sev</th><th>Title</th><th>Source</th>
                    <th>Path / Command</th><th>Location</th>
                    <th>SHA256</th><th>Signed</th>
                  </tr></thead>
                  <tbody>{''.join(rows)}</tbody>
                </table>
              </div>
            </div>
        """)

    # -- Network Activity section -------------------------------------

    def _network_activity_section(self) -> str:
        net = self.metadata.get("network_state") or {}
        if not net:
            return ""
        listening = net.get("listening") or []
        established = net.get("established") or []
        dns = net.get("dns_cache") or []

        def _conn_table(items, headers, extract_row):
            if not items:
                return ""
            body = "".join(extract_row(r) for r in items[:60])
            more = (f"<tr><td colspan='{len(headers)}' "
                    f"style='color:var(--fg-dim);text-align:center;'>"
                    f"... and {len(items) - 60} more</td></tr>"
                    if len(items) > 60 else "")
            head = "".join(f"<th>{h}</th>" for h in headers)
            return (f"<table><thead><tr>{head}</tr></thead>"
                    f"<tbody>{body}{more}</tbody></table>")

        listen_html = _conn_table(
            listening, ["Proto", "Local", "PID", "Process"],
            lambda r: (
                f"<tr><td>{html.escape(str(r.get('proto') or ''))}</td>"
                f"<td><code>{html.escape(str(r.get('laddr') or ''))}</code></td>"
                f"<td>{html.escape(str(r.get('pid') or ''))}</td>"
                f"<td><b>{html.escape(str(r.get('process') or ''))}</b></td></tr>"))
        est_html = _conn_table(
            established,
            ["Proto", "Local", "Remote", "PID", "Process"],
            lambda r: (
                f"<tr><td>{html.escape(str(r.get('proto') or ''))}</td>"
                f"<td><code>{html.escape(str(r.get('laddr') or ''))}</code></td>"
                f"<td><code>{html.escape(str(r.get('raddr') or ''))}</code></td>"
                f"<td>{html.escape(str(r.get('pid') or ''))}</td>"
                f"<td><b>{html.escape(str(r.get('process') or ''))}</b></td></tr>"))

        dns_html = ""
        if dns:
            def _dns_row(r):
                return (f"<tr><td><code>"
                        f"{html.escape(str(r.get('Record Name','')))}</code></td>"
                        f"<td style='color:var(--fg-dim);font-size:11px;'>"
                        f"{html.escape(str(r.get('Record Type','')))}</td>"
                        f"<td><code>"
                        f"{html.escape(str(r.get('A (Host) Record') or r.get('CNAME Record') or r.get('AAAA Record') or '-'))}</code>"
                        f"</td></tr>")
            dns_html = _conn_table(
                dns, ["Domain", "Type", "Answer"], _dns_row)

        return textwrap.dedent(f"""
            <div class="section">
              <h2>4. Network Activity
                <span style='color:var(--fg-dim);font-size:13px;'>
                  (live posture)
                </span>
              </h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Live network inventory: what is the host listening
                  for, who is it talking to right now, and what has
                  the resolver seen recently. External non-cloud
                  endpoints and unusual listeners are promoted to
                  findings above.
                </p>
                <h3 style='margin-top:10px;'>
                  Listening Ports ({len(listening)})
                </h3>
                {listen_html or "<p style='color:var(--fg-dim)'>none</p>"}
                <h3 style='margin-top:14px;'>
                  Established Connections ({len(established)})
                </h3>
                {est_html or "<p style='color:var(--fg-dim)'>none</p>"}
                <h3 style='margin-top:14px;'>
                  DNS Resolver Cache ({len(dns)})
                </h3>
                <details>
                  <summary>Expand {len(dns)} cached DNS records</summary>
                  <div class='body'>{dns_html or '<p>none</p>'}</div>
                </details>
              </div>
            </div>
        """)

    # -- Process Tree section -----------------------------------------

    def _process_tree_section(self) -> str:
        snap = self.metadata.get("live_snapshot") or {}
        procs = snap.get("processes") or []
        if not procs:
            return ""
        # Build PID -> proc map + children map
        by_pid = {p.get("pid"): p for p in procs if p.get("pid")}
        children: Dict[Any, List[Any]] = {}
        for p in procs:
            ppid = p.get("ppid")
            children.setdefault(ppid, []).append(p)

        # Build flagged-PID map from findings (any finding that
        # references a PID via evidence.pid or evidence.PID).
        flagged: Dict[int, List[Finding]] = {}
        for f in self.findings:
            ev = f.evidence or {}
            for k in ("pid", "PID", "ProcessId"):
                v = ev.get(k)
                if v is None:
                    continue
                try:
                    flagged.setdefault(int(v), []).append(f)
                    break
                except (ValueError, TypeError):
                    continue
        total_flagged = len(flagged)

        # Render as a bounded flat tree: roots first, then DFS.
        rendered: List[str] = []
        visited: Set[int] = set()

        def _flag_cell(pid: Optional[int]) -> str:
            if pid is None or pid not in flagged:
                return ""
            fs = flagged[pid]
            max_sev = max(f.severity for f in fs)
            color = SEV_COLOR[max_sev]
            pill = (f"<span class='pill' "
                    f"style='background:{color};margin-left:8px;"
                    f"font-size:10px;'>"
                    f"{SEV_LABEL[max_sev]} FINDING</span>")
            anchor = fs[0].anchor_id()
            title = html.escape(fs[0].title[:60])
            link = (f" <a href='#{anchor}' "
                    f"style='color:{color};font-size:11px;"
                    f"text-decoration:none;' "
                    f"title='{title}'>&#x25b8; jump to "
                    f"finding</a>")
            return pill + link

        def _row_bg(pid: Optional[int]) -> str:
            if pid is None or pid not in flagged:
                return ""
            sev = max(f.severity for f in flagged[pid])
            if sev >= SEV_CRIT:
                return "background:rgba(192,57,43,0.18);"
            if sev >= SEV_HIGH:
                return "background:rgba(230,126,34,0.14);"
            if sev >= SEV_MED:
                return "background:rgba(243,156,18,0.10);"
            return ""

        def _walk(p, depth):
            pid = p.get("pid")
            if pid in visited or pid is None:
                return
            visited.add(pid)
            name = html.escape(str(p.get("name") or "?"))
            user = html.escape(str(p.get("username") or "?"))
            exe = html.escape(str(p.get("exe") or "")[:120])
            cmd = html.escape(
                " ".join(p.get("cmdline") or [])[:160])
            ct = html.escape(str(p.get("create_time_iso") or ""))
            indent = "&rarr; " * depth
            flag_html = _flag_cell(pid)
            bg = _row_bg(pid)
            flag_attr = "1" if pid in flagged else "0"
            sev_attr = str(max(f.severity
                               for f in flagged[pid])) \
                if pid in flagged else "0"
            rendered.append(
                f"<tr data-flag='{flag_attr}' "
                f"data-flag-sev='{sev_attr}' style='{bg}'>"
                f"<td><code>{indent}{name}</code>{flag_html}</td>"
                f"<td>{pid}</td><td>{p.get('ppid','-')}</td>"
                f"<td>{user}</td>"
                f"<td style='font-size:11px;color:var(--fg-dim);'>"
                f"<code>{exe}</code></td>"
                f"<td style='font-size:11px;word-break:break-all;'>"
                f"<code>{cmd}</code></td>"
                f"<td style='font-size:11px;'>{ct}</td></tr>")
            for c in sorted(children.get(pid, []),
                            key=lambda x: x.get("name") or ""):
                _walk(c, depth + 1)

        # Find roots (parents absent from by_pid OR ppid = 0)
        roots = [p for p in procs
                 if p.get("ppid") not in by_pid or p.get("ppid") == 0]
        roots.sort(key=lambda x: x.get("pid") or 0)
        for r in roots:
            _walk(r, 0)
        # Orphans (not walked)
        for p in procs:
            _walk(p, 0)

        # Top banner summarizing how many processes are flagged
        banner = ""
        if total_flagged:
            banner = textwrap.dedent(f"""
                <div style="background:rgba(192,57,43,0.15);
                            border-left:3px solid #c0392b;
                            padding:10px 14px;
                            border-radius:6px;margin:8px 0 16px;">
                  <b style='color:#fca5a5;'>
                    &#x26a0; {total_flagged} process(es) in this
                    tree are flagged by findings above.
                  </b>
                  <div style='color:var(--fg-dim);
                              font-size:12px;margin-top:4px;'>
                    Use the severity filter below to show only
                    flagged processes, or click
                    &ldquo;jump to finding&rdquo; on any
                    highlighted row.
                  </div>
                </div>
            """) if total_flagged else ""

        # Per-severity counts for the filter bar
        sev_counts = {5: 0, 4: 0, 3: 0, 2: 0, 1: 0}
        for pid, fs in flagged.items():
            s = max(f.severity for f in fs)
            sev_counts[s] = sev_counts.get(s, 0) + 1

        def _btn(label: str, data_filter: str,
                  count: int,
                  active: bool = False,
                  color: Optional[str] = None) -> str:
            attrs = (" style='border-color:" + color + ";'"
                     if color else "")
            return (f"<button class='proc-filter-btn"
                    f"{' active' if active else ''}' "
                    f"data-filter='{data_filter}'{attrs}>"
                    f"{label} "
                    f"<span style='opacity:.7;'>({count})</span>"
                    f"</button>")

        filter_bar = textwrap.dedent(f"""
            <div class='proc-filter-bar'
                 style='display:flex;gap:6px;margin:4px 0 14px;
                        flex-wrap:wrap;align-items:center;'>
              <span style='color:var(--fg-dim);font-size:11px;
                            text-transform:uppercase;
                            letter-spacing:0.05em;
                            margin-right:4px;'>
                Filter:
              </span>
              {_btn('All', 'all', len(procs), active=True)}
              {_btn('&#x26a0; Flagged only', 'flagged',
                     total_flagged, color='#c0392b')}
              {_btn('Critical', '5', sev_counts[5],
                     color='#c0392b')}
              {_btn('High', '4', sev_counts[4],
                     color='#e67e22')}
              {_btn('Medium', '3', sev_counts[3],
                     color='#f39c12')}
              {_btn('Low', '2', sev_counts[2],
                     color='#16a085')}
            </div>
        """)

        return textwrap.dedent(f"""
            <div class="section">
              <h2>5. Running Processes &mdash; Parent-Child Tree
                <span style='color:var(--fg-dim);font-size:13px;'>
                  ({len(procs)} processes
                  {', <span style="color:#fca5a5;font-weight:600;">'
                   + str(total_flagged) + ' flagged</span>'
                   if total_flagged else ''})
                </span>
              </h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Live process hierarchy at triage time. Flagged
                  processes (Office&rarr;LOLBin, lsass children,
                  encoded-PS, masqueraded system names, transient-
                  path binaries, offensive tools) are highlighted
                  inline and linked to their full finding cards.
                  Use the filter box (bottom-right) to drill down.
                </p>
                {banner}
                {filter_bar}
                <details{" open" if total_flagged else ""}>
                  <summary>Expand full process tree ({len(procs)})
                  </summary>
                  <div class='body'>
                    <div style="max-height:540px;overflow:auto;">
                      <table class='proc-tree-table'>
                        <thead><tr>
                          <th>Name / Flag</th>
                          <th>PID</th><th>PPID</th>
                          <th>User</th><th>Exe</th>
                          <th>Command Line</th><th>Started</th>
                        </tr></thead>
                        <tbody>{''.join(rendered)}</tbody>
                      </table>
                    </div>
                  </div>
                </details>
              </div>
            </div>
        """)

    # -- Domain Intel section -----------------------------------------

    def _domain_intel_section(self) -> str:
        ds = self.metadata.get("domain_state") or {}
        if not ds:
            return ""
        blocks: List[str] = []

        # Who am I
        wa = ds.get("whoami") or {}
        if wa.get("user"):
            u = wa["user"][0] if wa["user"] else {}
            rows = "".join(
                f"<tr><th style='width:150px'>{html.escape(k)}</th>"
                f"<td><code>{html.escape(str(v))}</code></td></tr>"
                for k, v in u.items())
            blocks.append(
                f"<h3>Current User Token</h3>"
                f"<table>{rows}</table>")
        if wa.get("privileges"):
            privs = [p for p in wa["privileges"]
                     if "Enabled" in p.get("State", "")][:30]
            if privs:
                rows = "".join(
                    f"<tr><td><code>"
                    f"{html.escape(p.get('Privilege Name',''))}</code></td>"
                    f"<td style='color:var(--fg-dim);font-size:12px;'>"
                    f"{html.escape(p.get('Description',''))}</td>"
                    f"<td>{html.escape(p.get('State',''))}</td></tr>"
                    for p in privs)
                blocks.append(
                    f"<h3 style='margin-top:14px;'>"
                    f"Enabled Privileges ({len(privs)})</h3>"
                    f"<table><thead><tr><th>Privilege</th>"
                    f"<th>Description</th><th>State</th></tr></thead>"
                    f"<tbody>{rows}</tbody></table>")

        # Kerberos tickets
        kl = ds.get("klist") or []
        if kl:
            rows = "".join(
                f"<tr><td><code>{html.escape(t.get('client','?'))}</code></td>"
                f"<td><code>{html.escape(t.get('server','?'))}</code></td>"
                f"<td style='font-size:11px;'>"
                f"{html.escape(t.get('enc','?'))}</td>"
                f"<td style='font-size:11px;'>{html.escape(t.get('start',''))}</td>"
                f"<td style='font-size:11px;'>{html.escape(t.get('end',''))}</td>"
                f"</tr>"
                for t in kl[:40])
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Cached Kerberos Tickets ({len(kl)})</h3>"
                f"<table><thead><tr><th>Client</th><th>Server</th>"
                f"<th>Encryption</th><th>Start</th><th>End</th></tr>"
                f"</thead><tbody>{rows}</tbody></table>")

        # Credential Manager
        cm = ds.get("cmdkey") or []
        if cm:
            rows = "".join(
                f"<tr><td><code>"
                f"{html.escape(e.get('target',''))}</code></td>"
                f"<td><code>{html.escape(e.get('user',''))}</code></td>"
                f"<td style='font-size:11px;'>"
                f"{html.escape(e.get('type',''))}</td>"
                f"<td style='font-size:11px;'>"
                f"{html.escape(e.get('persistence',''))}</td></tr>"
                for e in cm[:40])
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Credential Manager Entries ({len(cm)})</h3>"
                f"<table><thead><tr><th>Target</th><th>User</th>"
                f"<th>Type</th><th>Persistence</th></tr></thead>"
                f"<tbody>{rows}</tbody></table>")

        # SMB shares
        shares = ds.get("smb_shares") or []
        if shares:
            rows = "".join(
                f"<tr><td><b>{html.escape(s.get('name',''))}</b></td>"
                f"<td><code>{html.escape(s.get('path',''))}</code></td>"
                f"<td style='color:var(--fg-dim);font-size:12px;'>"
                f"{html.escape(s.get('remark',''))}</td></tr>"
                for s in shares)
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Local SMB Shares ({len(shares)})</h3>"
                f"<table><thead><tr><th>Name</th><th>Path</th>"
                f"<th>Remark</th></tr></thead>"
                f"<tbody>{rows}</tbody></table>")

        # Cached logons count
        if ds.get("cached_logons_count") is not None:
            blocks.append(
                f"<h3 style='margin-top:14px;'>MSCache2 Surface</h3>"
                f"<p><b>CachedLogonsCount:</b> "
                f"{ds['cached_logons_count']} domain-user hashes "
                f"persisted locally for offline logon.</p>")

        # User profiles
        ups = ds.get("user_profiles") or []
        if ups:
            rows = "".join(
                f"<tr><td><b>{html.escape(u.get('name',''))}</b></td>"
                f"<td><code>{html.escape(u.get('path',''))}</code></td>"
                f"<td style='font-size:11px;'>"
                f"{html.escape(u.get('accessed',''))}</td>"
                f"<td style='font-size:11px;'>"
                f"{html.escape(u.get('modified',''))}</td>"
                f"<td>{'yes' if u.get('ntuser_present') else 'no'}</td></tr>"
                for u in ups)
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Local User Profiles ({len(ups)})</h3>"
                f"<table><thead><tr><th>Name</th><th>Path</th>"
                f"<th>Last Access</th><th>Last Modify</th>"
                f"<th>NTUSER.DAT</th></tr></thead>"
                f"<tbody>{rows}</tbody></table>")

        # Nltest DC list / DNS SRV records
        if ds.get("nltest_dclist"):
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Domain Controllers (nltest)</h3>"
                f"<pre>{html.escape(ds['nltest_dclist'])}</pre>")
        if ds.get("dns_domain_srv_records"):
            rec = ", ".join(ds["dns_domain_srv_records"])
            blocks.append(
                f"<h3 style='margin-top:14px;'>"
                f"Domain SRV records in DNS cache</h3>"
                f"<p><code>{html.escape(rec)}</code></p>")

        if not blocks:
            return ""
        return textwrap.dedent(f"""
            <div class="section">
              <h2>6a. Domain Posture &mdash; Credentials, Tickets,
                   Shares, Profiles</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Everything about this host's relationship with the
                  domain: its token, cached Kerberos tickets, stored
                  credentials, local-admin exposure surface,
                  user-profile footprint. An attacker with a
                  foothold here sees exactly this view — so should
                  the defender.
                </p>
                {''.join(blocks)}
              </div>
            </div>
        """)

    # -- Darknet / data-leakage section ------------------------------

    def _darknet_leak_section(self) -> str:
        ds = self.metadata.get("darknet_state") or {}
        dark_findings = [f for f in self.findings
                         if f.source == "darknet"]
        cards: List[str] = []
        if "tor" in ds:
            tor = ds["tor"]
            rows = []
            for kind, items in tor.items():
                if items:
                    rows.append(
                        f"<tr><th>{html.escape(kind)}</th>"
                        f"<td><code>"
                        f"{html.escape(json.dumps(items, default=str)[:400])}</code></td></tr>")
            if rows:
                cards.append(
                    f"<h3>Tor / Anonymity Evidence</h3>"
                    f"<table>{''.join(rows)}</table>")

        # Summary of darknet findings
        if dark_findings:
            rows = []
            for f in dark_findings:
                color = SEV_COLOR[f.severity]
                anchor = f.anchor_id()
                rows.append(
                    f"<tr><td><span class='pill' "
                    f"style='background:{color}'>"
                    f"{SEV_LABEL[f.severity]}</span></td>"
                    f"<td><a href='#{anchor}'>"
                    f"{html.escape(f.title)}</a></td>"
                    f"<td>{html.escape(f.conclusion[:220])}</td></tr>")
            cards.append(
                f"<h3 style='margin-top:14px;'>"
                f"Darknet / Exfiltration Findings "
                f"({len(dark_findings)})</h3>"
                f"<table><thead><tr><th style='width:90px'>Sev</th>"
                f"<th style='width:30%'>Finding</th>"
                f"<th>Conclusion</th></tr></thead>"
                f"<tbody>{''.join(rows)}</tbody></table>")

        if not cards:
            cards.append(
                "<p style='color:var(--fg-dim)'>No Tor / paste-site / "
                "anonymous-upload / stealer / staging indicators "
                "detected on this host.</p>")

        return textwrap.dedent(f"""
            <div class="section">
              <h2>6b. Darknet &amp; Data-Leakage Indicators</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Evidence that data might be moving from this host
                  toward darknet channels or anonymous-publishing
                  infrastructure. Includes: Tor presence, .onion
                  activity, paste-site and anonymous-upload visits,
                  stealer-family drop files, exfil-shaped archive
                  staging, and credential-dumping tools.
                </p>
                {''.join(cards)}
              </div>
            </div>
        """)

    # -- Findings Index (TOC with anchor links) -----------------------

    def _findings_index_section(self, malicious: List[Finding],
                                  observations: List[Finding]) -> str:
        if not (malicious or observations):
            return textwrap.dedent("""
                <div class="section">
                  <h2>Findings Index</h2>
                  <div class="section-body">
                    <p style="color:var(--fg-dim)">No malicious or
                    suspicious findings. Informational items are in
                    the collapsed Informational section below.</p>
                  </div>
                </div>
            """)

        def _block(label: str, items: List[Finding]) -> str:
            if not items:
                return ""
            lines = [f"<h3 style='margin-top:10px;'>{label} "
                     f"({len(items)})</h3>",
                     "<ol class='findex'>"]
            for f in items:
                color = SEV_COLOR[f.severity]
                anchor = f.anchor_id()
                src_tag = (f"<span style='color:var(--fg-dim);"
                           f"font-size:11px;'>"
                           f"[{self._pretty_source(f.source)}]</span>")
                lines.append(
                    f"<li><a href='#{anchor}' class='findex-link'>"
                    f"<span class='pill' "
                    f"style='background:{color}'>"
                    f"{SEV_LABEL[f.severity]}</span>"
                    f" &nbsp;{html.escape(f.title)}"
                    f" &nbsp;{src_tag}</a></li>")
            lines.append("</ol>")
            return "\n".join(lines)

        crit = [f for f in malicious if f.severity == SEV_CRIT]
        high = [f for f in malicious if f.severity == SEV_HIGH]
        return textwrap.dedent(f"""
            <div class="section">
              <h2>2. Findings Index &mdash; Jump to Details</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Clickable index of every malicious / suspicious
                  finding. Click a row to jump to the full forensic
                  card, including hashes, file paths, registry keys,
                  event-log coordinates and timestamps.
                </p>
                {_block("Critical", crit)}
                {_block("High", high)}
                {_block("Medium (Observations)", observations)}
              </div>
            </div>
        """)

    # -- Attack Indicators (IOCs observed) -----------------------------

    def _attack_indicators_section(self) -> str:
        ind = self.indicators
        if not any(ind.values()):
            return ""

        # Build a "suspicion" lookup from:
        #   (a) each IoC referenced by a HIGH+/CRITICAL finding, and
        #   (b) any threat-intel data attached to the finding
        #       (VirusTotal malicious count >= 3, AbuseIPDB score >= 50).
        bad_values: Dict[str, Dict[str, Any]] = {}

        for f in self.findings:
            sev = f.severity
            ev = f.evidence or {}
            ti = ev.get("threat_intel") or {}
            vt = ti.get("virustotal") or {}
            abuse = ti.get("abuseipdb") or {}

            if sev >= SEV_HIGH:
                for v in (ev.get("sha256"), ev.get("md5"),
                          ev.get("IpAddress"), ev.get("ForeignAddr")):
                    if isinstance(v, str) and v:
                        bad_values.setdefault(
                            v.lower(), {})["via_finding"] = True
            if vt.get("malicious", 0) >= 3:
                h = ev.get("sha256")
                if h:
                    slot = bad_values.setdefault(h.lower(), {})
                    slot["vt_malicious"] = vt["malicious"]
                    slot["vt_names"] = vt.get("names", [])
            for ip, a in abuse.items():
                if a.get("abuse_score", 0) >= 50:
                    slot = bad_values.setdefault(ip.lower(), {})
                    slot["abuse_score"] = a["abuse_score"]
                    slot["abuse_country"] = a.get("country")

        # Build hash → VT GUI URL map from threat_intel data
        hash_vt_url: Dict[str, str] = {}
        for f in self.findings:
            ev = f.evidence or {}
            ti = ev.get("threat_intel") or {}
            vt = ti.get("virustotal") or {}
            if vt.get("vt_url"):
                for k in ("sha256", "md5"):
                    h = ev.get(k)
                    if h:
                        hash_vt_url[str(h).lower()] = vt["vt_url"]

        def _suspicion_badge(value: str) -> str:
            b = bad_values.get((value or "").lower())
            tags = []
            if b:
                if b.get("vt_malicious"):
                    tags.append(
                        f"<span class='pill' "
                        f"style='background:#c0392b;'>VT "
                        f"{b['vt_malicious']}</span>")
                if b.get("abuse_score"):
                    tags.append(
                        f"<span class='pill' "
                        f"style='background:#e67e22;'>AbuseIPDB "
                        f"{b['abuse_score']}/100</span>")
                if b.get("via_finding"):
                    tags.append(
                        "<span class='pill' "
                        "style='background:#c0392b;'>SUSPICIOUS</span>")
            # Direct VT link for hashes that have one — styled as
            # a prominent branded button, not a plain link.
            vt_url = hash_vt_url.get((value or "").lower())
            if vt_url:
                tags.append(
                    f"<a href='{html.escape(vt_url)}' "
                    f"target='_blank' rel='noopener' "
                    f"class='vt-btn' "
                    f"title='View full VirusTotal report'>"
                    f"report</a>")
            if not tags:
                return ""
            return " " + " ".join(tags)

        def _ref_links(refs: List[Dict[str, Any]]) -> str:
            if not refs:
                return ""
            out = []
            for r in refs[:6]:
                out.append(f"<a href='#{r['anchor']}'>"
                           f"{html.escape(r['title'][:70])}</a>")
            return "<br>".join(out)

        def _table(label: str, rows: List[Dict[str, Any]],
                    col_name: str, open_by_default: bool = False,
                    hash_mode: bool = False) -> str:
            if not rows:
                return ""
            trs = []
            sus_count = 0
            for r in rows[:30]:
                value = str(r["value"])
                is_bad = value.lower() in bad_values
                if is_bad:
                    sus_count += 1
                row_class = " class='eid-sus'" if is_bad else ""
                badge = _suspicion_badge(value) if hash_mode \
                    or is_bad else ""
                trs.append(
                    f"<tr{row_class}>"
                    f"<td style='font-family:Consolas,monospace;"
                    f"font-size:12px;word-break:break-all;'>"
                    f"{html.escape(value)}{badge}</td>"
                    f"<td style='text-align:right;'>{r['count']}</td>"
                    f"<td style='font-size:12px;'>"
                    f"{_ref_links(r['references'])}</td></tr>")
            more = (f"<tr><td colspan='3' style='color:var(--fg-dim);"
                    f"text-align:center;'>... and "
                    f"{len(rows) - 30} more</td></tr>"
                    if len(rows) > 30 else "")

            # Count-in-summary display: "(N)" plus suspicion count
            sus_sum = (f" <span class='pill' "
                       f"style='background:#c0392b;font-size:10px;'>"
                       f"{sus_count} suspicious</span>"
                       if sus_count else "")

            # Count full suspicious (including any rows beyond 30)
            total_sus = sum(1 for r in rows
                            if str(r["value"]).lower() in bad_values)
            summary_sus = (f" <span class='pill' "
                           f"style='background:#c0392b;font-size:10px;'>"
                           f"{total_sus} suspicious</span>"
                           if total_sus else "")

            open_attr = " open" if (open_by_default
                                      or total_sus > 0) else ""
            return textwrap.dedent(f"""
                <details{open_attr} style="margin-top:12px;">
                  <summary style="cursor:pointer;padding:8px 12px;
                                   background:var(--panel2);
                                   border-radius:6px;
                                   list-style:none;
                                   display:flex;align-items:center;
                                   justify-content:space-between;">
                    <b>{html.escape(label)}</b>
                    <span>
                      <span style='color:var(--fg-dim);font-size:12px;'>
                        ({len(rows)})
                      </span>
                      {summary_sus}
                    </span>
                  </summary>
                  <div style="margin-top:8px;">
                    <table>
                      <thead><tr>
                        <th>{col_name}</th>
                        <th style="width:60px;text-align:right;">
                          Hits</th>
                        <th style="width:40%;">Referenced by</th>
                      </tr></thead>
                      <tbody>{''.join(trs)}{more}</tbody>
                    </table>
                  </div>
                </details>
            """)

        return textwrap.dedent(f"""
            <div class="section">
              <h2>6. Attack Indicators &mdash; IOCs Observed</h2>
              <div class="section-body">
                <p style="color:var(--fg-dim);font-size:13px;">
                  Every concrete identifier any analyzer surfaced on
                  this host. Each group is a click-to-expand card.
                  Hashes / IPs tagged
                  <span class='pill' style='background:#c0392b;'>
                    SUSPICIOUS</span>
                  are referenced by a High/Critical finding or
                  carry a VirusTotal / AbuseIPDB hit. Groups with
                  suspicious entries auto-open.
                </p>
                {_table("External IPs", ind['ips'], "IP address")}
                {_table("Domains", ind['domains'], "Domain")}
                {_table("URLs", ind['urls'], "URL")}
                {_table("SHA256 hashes", ind['sha256'], "SHA256",
                        hash_mode=True)}
                {_table("MD5 hashes", ind['md5'], "MD5",
                        hash_mode=True)}
                {_table("Suspicious file paths", ind['paths'],
                        "Path")}
                {_table("User accounts involved", ind['users'],
                        "User")}
                {_table("MITRE techniques", ind['mitre'],
                        "Technique")}
              </div>
            </div>
        """)

    @staticmethod
    def _render_evidence_table(ev: Dict[str, Any]) -> str:
        if not ev:
            return ("<p style='color:var(--fg-dim)'>No structured "
                    "evidence for this finding.</p>")
        rows = []
        for k, v in ev.items():
            if isinstance(v, list):
                if not v:
                    vs = "(empty)"
                elif len(v) > 5:
                    vs = (", ".join(html.escape(str(x)) for x in v[:5])
                          + f" <i>(+{len(v) - 5} more)</i>")
                else:
                    vs = ", ".join(html.escape(str(x)) for x in v)
            elif isinstance(v, dict):
                vs = html.escape(json.dumps(v, default=str)[:400])
            elif isinstance(v, str) and len(v) > 400:
                vs = html.escape(v[:400]) + " <i>...</i>"
            else:
                vs = html.escape(str(v))
            rows.append(
                f"<tr><th style='width:180px'>"
                f"{html.escape(str(k))}</th><td>{vs}</td></tr>")
        return f"<table>{''.join(rows)}</table>"

    # -- Security Event Overview --------------------------------------

    def _security_events_section(self) -> str:
        if not self.event_overview:
            return ""

        # Group by attack phase
        by_phase: Dict[str, List[Tuple[int, Dict[str, Any]]]] = {}
        total_events = 0
        total_suspicious_instances = 0
        for eid, stats in self.event_overview.items():
            total_events += stats["count"]
            total_suspicious_instances += len(
                stats.get("suspicious_samples") or [])
            meta = EVENT_CATALOG.get(eid, {})
            phase = meta.get("phase", "other")
            by_phase.setdefault(phase, []).append((eid, stats))

        phase_blocks: List[str] = []
        for phase in ATTACK_PHASES + ["other"]:
            items = by_phase.get(phase, [])
            if not items:
                continue
            # Sort: IDs with suspicious samples first, then by count.
            items.sort(
                key=lambda x: (-len(x[1].get("suspicious_samples")
                                    or []), -x[1]["count"]))
            rows = []
            for eid, stats in items:
                rows.append(self._render_eid_row(eid, stats))
            phase_blocks.append(textwrap.dedent(f"""
                <h3 style="margin-top:20px;text-transform:capitalize;">
                  {html.escape(phase.replace('-', ' '))}
                </h3>
                <table>
                  <thead><tr>
                    <th style="width:70px">ID</th>
                    <th>Name</th>
                    <th style="width:80px;text-align:right;">Count</th>
                    <th style="width:80px;text-align:center;">Suspicious</th>
                    <th style="width:130px">MITRE</th>
                    <th>Channel(s)</th>
                    <th style="width:260px">Analyst view &amp; instances</th>
                  </tr></thead>
                  <tbody>{''.join(rows)}</tbody>
                </table>
            """))

        # Lead paragraph
        n_ids = len(self.event_overview)
        anomaly_categories = sorted({
            f.category for f in self.findings
            if f.source == "evtlog"})
        lead = (
            f"The event-log investigator processed <b>{total_events}</b> "
            f"records across <b>{n_ids}</b> distinct Event IDs. "
            f"<b>{total_suspicious_instances}</b> individual instances "
            "were classified as suspicious and are shown inline below "
            "with extracted fields (username, IP, command line, service "
            "name, etc.). Click an Event ID row to expand.")
        if anomaly_categories:
            lead += (f" The investigator also raised "
                     f"<b>{len(anomaly_categories)}</b> aggregate "
                     "anomaly categories — see the Confirmed Malicious "
                     "section above for per-anomaly conclusions.")

        return textwrap.dedent(f"""
            <div class="section">
              <h2>10. Security Event ID Overview &mdash; per-ID
                  Analysis</h2>
              <div class="section-body">
                <p>{lead}</p>
                {''.join(phase_blocks)}
              </div>
            </div>
        """)

    def _render_eid_row(self, eid: int,
                         stats: Dict[str, Any]) -> str:
        meta = EVENT_CATALOG.get(eid, {})
        name = meta.get("name", "?")
        desc = meta.get("description", "")
        when = meta.get("when_suspicious", "")
        mitre = ", ".join(meta.get("mitre", [])) or "-"
        channels = ", ".join(sorted(stats.get("channels", []) or []))
        suspicious = stats.get("suspicious_samples") or []
        benign = stats.get("benign_samples") or []
        sus_count = len(suspicious)
        sus_badge = ("<span class='pill' style='background:#c0392b'>"
                     f"{sus_count}</span>" if sus_count else
                     "<span style='color:var(--fg-dim)'>0</span>")

        # Build instances block
        instances_html = ""
        if suspicious:
            instances_html += (
                "<h5 style='margin:6px 0 4px 0;color:#e67e22;'>"
                f"Suspicious instances ({sus_count}"
                f"{' — showing 25' if sus_count >= 25 else ''}):"
                "</h5>")
            instances_html += self._render_instance_table(
                suspicious, suspicious=True)
        if benign and not suspicious:
            instances_html += (
                "<h5 style='margin:6px 0 4px 0;color:var(--fg-dim);'>"
                f"Recent instances ({len(benign)}):</h5>")
            instances_html += self._render_instance_table(
                benign, suspicious=False)
        elif benign and suspicious:
            instances_html += textwrap.dedent(f"""
                <details style="margin-top:8px;">
                  <summary style="font-size:12px;
                                  color:var(--fg-dim);">
                    Recent benign instances ({len(benign)})
                  </summary>
                  <div class="body">
                    {self._render_instance_table(benign,
                        suspicious=False)}
                  </div>
                </details>
            """)

        row_class = "eid-sus" if suspicious else ""
        return textwrap.dedent(f"""
            <tr class='{row_class}'>
              <td><b>{eid}</b></td>
              <td>{html.escape(name)}</td>
              <td style="text-align:right;">
                <b>{stats['count']}</b>
              </td>
              <td style="text-align:center;">{sus_badge}</td>
              <td><code>{html.escape(mitre)}</code></td>
              <td style="color:var(--fg-dim);font-size:12px;">
                {html.escape(channels)}
              </td>
              <td>
                <details{' open' if suspicious else ''}>
                  <summary>
                    {'analyst view + instances'
                     if suspicious else 'what this ID means'}
                  </summary>
                  <div class="body">
                    <p style="color:var(--fg-dim);font-size:12px;">
                      <b>What this Event ID means:</b>
                      {html.escape(desc)}
                    </p>
                    <p style="color:var(--fg-dim);font-size:12px;">
                      <b>Baseline suspicion pattern:</b>
                      {html.escape(when)}
                    </p>
                    {instances_html}
                    <p style="color:var(--fg-dim);
                              font-size:11px;margin-top:6px;">
                      First seen:
                      {html.escape(stats.get('first') or '?')}
                      &middot; Last seen:
                      {html.escape(stats.get('last') or '?')}
                    </p>
                  </div>
                </details>
              </td>
            </tr>
        """)

    @staticmethod
    def _render_instance_table(samples: List[Dict[str, Any]],
                                 suspicious: bool) -> str:
        if not samples:
            return ""
        # Meta keys we render separately, not as data columns.
        META_KEYS = {"_suspicion", "_correlations"}
        keys: List[str] = []
        for s in samples:
            for k in s.keys():
                if k in META_KEYS:
                    continue
                if k not in keys:
                    keys.append(k)
        priority = ["TimeCreated", "TargetUserName", "SubjectUserName",
                    "IpAddress", "LogonType", "WorkstationName",
                    "NewProcessName", "ParentProcessName",
                    "CommandLine", "ServiceName", "ImagePath",
                    "TaskName", "TargetImage", "SourceImage",
                    "ScriptBlockText", "ShareName",
                    "RelativeTargetName", "ServiceFileName",
                    "AccountName", "MemberName"]
        keys.sort(key=lambda k: (priority.index(k)
                                 if k in priority else 999, k))

        # Build header
        cols: List[str] = []
        if suspicious:
            cols.append(
                "<th style='font-size:11px;color:#e67e22;"
                "width:220px;'>Why suspicious</th>")
            cols.append(
                "<th style='font-size:11px;color:#3aa0ff;"
                "width:240px;'>Related findings</th>")
        for k in keys:
            cols.append(
                f"<th style='font-size:11px;'>"
                f"{html.escape(k)}</th>")

        body_rows = []
        for s in samples:
            cells = []
            if suspicious:
                reason = s.get("_suspicion", "")
                cells.append(
                    f"<td style='font-size:11px;color:#e67e22;'>"
                    f"{html.escape(reason)}</td>")
                corr = s.get("_correlations") or []
                if corr:
                    parts = []
                    for c in corr[:5]:
                        sev = c.get("severity", SEV_INFO)
                        color = SEV_COLOR.get(sev, "#6c7a89")
                        kind = html.escape(
                            str(c.get("kind", "")))
                        title = html.escape(
                            str(c.get("title", ""))[:60])
                        anchor = c.get("anchor", "")
                        parts.append(
                            f"<div style='margin:2px 0;'>"
                            f"<span class='pill' "
                            f"style='background:{color};"
                            f"font-size:10px;'>"
                            f"{SEV_LABEL[sev]}</span> "
                            f"<a href='#{anchor}' "
                            f"style='font-size:11px;'>"
                            f"{title}</a>"
                            f"<br><span style='color:var(--fg-dim);"
                            f"font-size:10px;'>via "
                            f"{kind}</span></div>")
                    cells.append(
                        f"<td style='font-size:11px;"
                        f"vertical-align:top;'>"
                        f"{''.join(parts)}</td>")
                else:
                    cells.append(
                        "<td style='font-size:11px;"
                        "color:var(--fg-dim);'>—</td>")
            for k in keys:
                v = s.get(k, "")
                v_str = html.escape(str(v))[:180]
                cells.append(
                    f"<td style='font-size:11px;"
                    f"vertical-align:top;'>{v_str}</td>")
            body_rows.append(f"<tr>{''.join(cells)}</tr>")

        return textwrap.dedent(f"""
            <div style="max-height:320px;overflow:auto;
                        border:1px solid var(--border);
                        border-radius:6px;margin:4px 0;">
              <table style="font-size:11px;">
                <thead><tr>{''.join(cols)}</tr></thead>
                <tbody>{''.join(body_rows)}</tbody>
              </table>
            </div>
        """)

    # -- Observations + informational ----------------------------------

    def _observations_section(self, items: List[Finding],
                                collapsed: bool = True) -> str:
        if not items:
            return ""
        rows = []
        for f in items:
            color = SEV_COLOR[f.severity]
            anchor = f.anchor_id()
            refs = f.forensic_references()
            refs_compact = ""
            for key in ("File path(s)", "SHA256", "Authenticode",
                        "IP(s)", "URL / Domain", "Registry key(s)",
                        "User(s)", "Event log"):
                if key in refs:
                    v = refs[key]
                    if isinstance(v, list):
                        v = v[0] if v else ""
                    refs_compact += (
                        f"<div style='font-size:11px;'>"
                        f"<b>{html.escape(key)}:</b> "
                        f"<code>{html.escape(str(v))[:120]}</code>"
                        f"</div>")
            rows.append(textwrap.dedent(f"""
                <tr id='{anchor}'>
                  <td><span class='pill' style='background:{color}'>
                      {SEV_LABEL[f.severity]}</span></td>
                  <td><b>{html.escape(f.title)}</b><br>
                      <span style="color:var(--fg-dim);font-size:12px;">
                      {self._pretty_source(f.source)} / {html.escape(f.category)}
                      </span></td>
                  <td>{html.escape(f.conclusion)}{refs_compact}</td>
                </tr>
            """))
        body = textwrap.dedent(f"""
            <table>
              <thead><tr><th style='width:90px'>Sev</th>
                <th style='width:30%'>Finding</th>
                <th>Conclusion &amp; Forensic References</th></tr></thead>
              <tbody>{''.join(rows)}</tbody>
            </table>
        """)
        if collapsed:
            return textwrap.dedent(f"""
                <div class="section">
                  <h2>Additional Observations (Medium)</h2>
                  <div class="section-body">
                    <details>
                      <summary>Expand {len(items)} medium-severity
                        observation(s)</summary>
                      <div class="body">{body}</div>
                    </details>
                  </div>
                </div>
            """)
        return textwrap.dedent(f"""
            <div class="section">
              <h2>12. Additional Observations ({len(items)} medium)</h2>
              <div class="section-body">{body}</div>
            </div>
        """)

    def _informational_section(self, items: List[Finding]) -> str:
        # Anchor every Low/Info finding so Attack Indicators references
        # always resolve to a target.
        rows = "".join(
            f"<tr id='{f.anchor_id()}'><td>{SEV_LABEL[f.severity]}</td>"
            f"<td><b>{html.escape(f.title)}</b>"
            f"<br><span style='color:var(--fg-dim);font-size:11px;'>"
            f"{self._pretty_source(f.source)} / "
            f"{html.escape(f.category)}</span></td>"
            f"<td style='color:var(--fg-dim);font-size:12px;'>"
            f"{html.escape(f.conclusion)[:380]}</td></tr>"
            for f in items)
        return textwrap.dedent(f"""
            <div class="section">
              <h2>13. Informational &amp; Low-Severity Items
                ({len(items)})</h2>
              <div class="section-body">
                <details open>
                  <summary>Expand {len(items)} informational /
                    low-severity item(s) (anchored — referenced by
                    Attack Indicators above)
                  </summary>
                  <div class="body">
                    <table>
                      <thead><tr><th style='width:90px'>Sev</th>
                      <th style='width:30%'>Title</th>
                      <th>Conclusion</th></tr></thead>
                      <tbody>{rows}</tbody>
                    </table>
                  </div>
                </details>
              </div>
            </div>
        """)

    def _remediation(self, band: str,
                      findings: List[Finding]) -> str:
        # Impact assessment
        impact_lines: List[str] = []
        cats = {f.category for f in findings}
        if any("credential" in c for c in cats):
            impact_lines.append(
                "Credential access was observed — assume any password "
                "touched by this host is compromised and must rotate.")
        if any("injection" in c or "hollow" in c or "rootkit" in c
                for c in cats):
            impact_lines.append(
                "In-memory code execution / rootkit indicators "
                "detected — the OS cannot be trusted. Offline "
                "imaging before reinstall is required.")
        if any(c.startswith("persistence") for c in cats):
            impact_lines.append(
                "One or more persistence mechanisms were deployed — "
                "the attacker planned to survive reboot.")
        if any("lateral" in c for c in cats):
            impact_lines.append(
                "Lateral-movement indicators present — the incident "
                "scope is probably larger than this single host.")
        if any(c.startswith("defender") for c in cats):
            impact_lines.append(
                "Endpoint protection was weakened (disabled AV / "
                "script scanning / exclusions) — indicates "
                "attacker-driven tamper or misconfigured policy.")
        if not impact_lines:
            impact_lines.append(
                "No material compromise confirmed. Any residual "
                "observations are documented above for completeness.")

        # Root-cause hints
        cause_lines: List[str] = []
        if any(f.category == "delivery.browser_script_download"
                for f in findings):
            cause_lines.append(
                "Browser-delivered script/shortcut is a strong "
                "phishing / drive-by candidate for initial access.")
        if any("lateral.smb_service" in f.category for f in findings):
            cause_lines.append(
                "Network-logon + service-install pattern suggests the "
                "source host is already compromised. Investigate the "
                "source IP / logon origin.")
        if any("auth.bruteforce" in f.category and
                f.evidence.get("success_after_burst")
                for f in findings):
            cause_lines.append(
                "Successful brute-force against an exposed account "
                "is the entry vector for this compromise.")
        if any(f.category == "credential.lsass_access" or
                f.category == "credential.lsass_access_sysmon"
                for f in findings):
            cause_lines.append(
                "Credential dumping occurred after initial foothold. "
                "Subsequent lateral movement is expected.")
        if any("defender.av_disabled" in f.category
                or "defender.rtp_disabled" in f.category
                for f in findings):
            cause_lines.append(
                "AV / RTP was disabled — confirm whether this "
                "change was policy-driven (before-breach) or "
                "attacker-driven (cause of breach expansion).")
        if not cause_lines:
            cause_lines.append(
                "No clear root-cause chain emerged from this run. "
                "If a breach is suspected, augment this analysis "
                "with a memory image (`--memory`) for deeper RAM "
                "inspection.")

        steps: List[str] = []
        if any(c.startswith("rootkit") for c in cats):
            steps.append(
                "Isolate the host immediately (EDR isolate / "
                "network disable). Rootkit-level findings mean the OS "
                "cannot be trusted; acquire a disk image offline.")
        if any("credential" in c for c in cats):
            steps.append(
                "Rotate passwords for every account that logged on to "
                "this host. For domain accounts: reset krbtgt twice.")
        if "corr.c2_plus_logclear" in cats:
            steps.append(
                "Treat as active-breach incident. Dormant C2 plus "
                "log-clearing indicates live operator presence. "
                "Engage tier-2 IR.")
        if any("injection" in c or "hollow" in c for c in cats):
            steps.append(
                "Reverse-engineer the carved buffers in workdir/"
                "memdumps/ — generate YARA and hunt fleet-wide.")
        if "lateral.smb_service" in cats:
            steps.append(
                "Run the same analysis on the Type-3 logon source host "
                "to chase the attacker's origin.")
        if any(c.startswith("persistence") for c in cats):
            steps.append(
                "Remove malicious autoruns, services and scheduled "
                "tasks captured in the Autoruns / SchTasks / Service "
                "sections. Re-run the analyzer after cleanup.")
        if any(c == "auth.bruteforce" for c in cats):
            steps.append(
                "Enable account-lockout policy and push MFA. Block the "
                "source IPs reported in the brute-force evidence at "
                "the perimeter.")
        if not steps:
            steps.append(
                "No critical actions required. Retain this report and "
                "the raw artifacts for standard retention.")
        impact_html = "".join(
            f"<li>{html.escape(s)}</li>" for s in impact_lines)
        cause_html = "".join(
            f"<li>{html.escape(s)}</li>" for s in cause_lines)
        steps_html = "".join(
            f"<li>{html.escape(s)}</li>" for s in steps)
        return textwrap.dedent(f"""
            <div class="section">
              <h2>14. Remediation Plan &mdash; Impact, Root Cause,
                   Action Items &nbsp;
                   <span style='color:var(--fg-dim);font-size:13px;'>
                     ({band})
                   </span>
              </h2>
              <div class="section-body">
                <h3 style='color:#e67e22;'>Impact Assessment</h3>
                <ul>{impact_html}</ul>
                <h3 style='color:#e67e22;margin-top:14px;'>
                  Root Cause Indicators
                </h3>
                <ul>{cause_html}</ul>
                <h3 style='color:#e67e22;margin-top:14px;'>
                  Action Items
                </h3>
                <ol>{steps_html}</ol>
              </div>
            </div>
        """)

    def _metadata_section(self) -> str:
        # Skip heavy nested blobs that already have their own section.
        skip = {"system_profile", "live_snapshot", "network_state",
                "domain_state", "darknet_state"}
        rows = "".join(
            f"<tr><th>{html.escape(str(k))}</th>"
            f"<td>{html.escape(str(v))[:220]}</td></tr>"
            for k, v in self.metadata.items()
            if k not in skip)
        return textwrap.dedent(f"""
            <div class="section"><h2>15. Run Metadata</h2>
              <div class="section-body">
                <table>{rows}</table>
              </div>
            </div>
        """)


# ===========================================================================
#                          macOS DFIR MODULE
# ===========================================================================
#
# Parallel collection + analysis for macOS endpoints. Normalizes every
# finding to the same `Finding` canonical event used by Windows, so
# the same Super-Timeline, MITRE heatmap, HTML report and JSON export
# work without modification.
#
# Architecture:
#     MacOSDispatcher
#       ├── MacPersistenceAnalyzer    LaunchAgents, LaunchDaemons,
#       │                             LoginItems, Cron, shell profiles
#       ├── MacKextAnalyzer           Kexts + System Extensions
#       ├── MacTCCAnalyzer            TCC.db permissions
#       ├── MacQuarantineAnalyzer     quarantine.sqlite
#       ├── MacSecurityAnalyzer       SIP / Gatekeeper / XProtect
#       ├── MacSSHAnalyzer            authorized_keys / known_hosts
#       ├── MacKnowledgeCAnalyzer     knowledgeC.db (app usage)
#       ├── MacFSEventsAnalyzer       FSEvents logs
#       ├── MacShellHistoryAnalyzer   .zsh_history / .bash_history
#       ├── MacUnifiedLogAnalyzer     `log show` predicates
#       └── MacAuditLogAnalyzer       /var/audit
#
# Libraries (stdlib only where possible):
#     plistlib           - binary + XML plist parsing (stdlib)
#     sqlite3            - SQLite DB parsing (stdlib)
#     subprocess         - `log show`, `kextstat`, `systemextensionsctl`
#     Optional:
#       mac_alias        - resolve alias blobs inside LoginItems plist
#       dissect.apfs     - deep APFS parsing (not required for this
#                          module; we use user-visible paths)
#
# Normalization strategy:
#     Every analyzer emits `Finding` objects with:
#       source=      'mac.persistence' | 'mac.tcc' | 'mac.quarantine'
#                    | 'mac.kext' | 'mac.ssh' | 'mac.shell' | ...
#       category=    'persistence.launchagent_suspicious' | ...
#       timestamp=   from the artifact (st_mtime, plist key, SQLite
#                    column, ULS time) — feeds Super-Timeline
#       evidence=    raw artifact fields (path, plist dict, SQLite row)
#       tags=        MITRE technique IDs (T1543.001 for LaunchAgents)
#     The existing AttackIndicatorAggregator, FindingNormalizer,
#     FindingEnricher, ReportGenerator, HTML/PDF/JSON exports all
#     work unchanged.
# ===========================================================================


def _read_plist(path: Path) -> Optional[Dict[str, Any]]:
    """Parse XML or binary plist, return dict or None on failure."""
    import plistlib
    try:
        with open(path, "rb") as fh:
            return plistlib.load(fh)
    except (plistlib.InvalidFileException, OSError,
            PermissionError, Exception):
        return None


def _iso_from_st(mtime: float) -> str:
    try:
        return dt.datetime.fromtimestamp(
            mtime, tz=dt.timezone.utc).isoformat()
    except (OverflowError, OSError, ValueError):
        return ""


MAC_BENIGN_LABEL_PREFIXES = (
    "com.apple.", "com.microsoft.", "com.google.", "com.adobe.",
    "com.zoom.", "com.spotify.", "com.slack.",
    "com.docker.", "com.sophos.", "com.crowdstrike.",
    "com.jamf.", "com.paloaltonetworks.", "com.sentinelone.",
    "com.cisco.", "com.mcafee.", "com.symantec.",
    "com.kaspersky.", "com.eset.", "com.bitdefender.",
    "com.jetbrains.", "com.github.", "com.dropbox.",
    "com.oracle.", "org.mozilla.",
)


class MacPersistenceAnalyzer:
    """
    Walks the three canonical persistence directories for
    LaunchAgents + LaunchDaemons plus Login Items / cron / shell
    profiles. Every entry is parsed (binary plists supported), and
    malicious-shaped entries (non-standard paths, encoded shell,
    unsigned binaries, suspicious labels) surface as Findings.
    """

    AGENT_DIRS = [
        Path("/Library/LaunchAgents"),
        Path("/Library/LaunchDaemons"),
        Path("/System/Library/LaunchAgents"),
        Path("/System/Library/LaunchDaemons"),
    ]

    SHELL_PROFILE_NAMES = (
        ".bash_profile", ".bashrc", ".bash_login",
        ".profile", ".zshrc", ".zprofile", ".zshenv",
        ".zlogin", ".cshrc", ".tcshrc", ".kshrc",
    )

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        self._collect_launchd()
        self._collect_login_items()
        self._collect_cron()
        self._collect_shell_profiles()
        self.logger.info(
            "macOS persistence: %d entries, %d findings",
            len(self.entries), len(self.findings))
        return self.entries, self.findings

    # -- Launchd (Agents + Daemons) ---------------------------------

    def _collect_launchd(self) -> None:
        # System-level directories
        dirs = list(self.AGENT_DIRS)
        # User-level — every /Users/* has ~/Library/LaunchAgents
        users_root = Path("/Users")
        if _safe_exists(users_root):
            try:
                for u in users_root.iterdir():
                    p = u / "Library" / "LaunchAgents"
                    if _safe_exists(p):
                        dirs.append(p)
            except (OSError, PermissionError):
                pass

        for d in dirs:
            if not _safe_exists(d):
                continue
            try:
                for plist_path in d.glob("*.plist"):
                    self._analyze_plist(plist_path, d)
            except (OSError, PermissionError):
                continue

    def _analyze_plist(self, plist_path: Path,
                        dir_path: Path) -> None:
        data = _read_plist(plist_path)
        if not data:
            return
        label = data.get("Label", "")
        program = data.get("Program")
        program_args = data.get("ProgramArguments") or []
        run_at_load = data.get("RunAtLoad", False)
        keep_alive = data.get("KeepAlive", False)
        start_interval = data.get("StartInterval")
        try:
            mtime = _iso_from_st(plist_path.stat().st_mtime)
        except OSError:
            mtime = ""

        cmd_joined = (" ".join(str(a) for a in program_args)
                      or str(program or ""))
        level = ("system" if "LaunchDaemons" in str(dir_path) or
                 str(dir_path).startswith("/Library") or
                 str(dir_path).startswith("/System") else "user")

        entry = {
            "kind": "launchd",
            "plist_path": str(plist_path),
            "dir": str(dir_path),
            "level": level,
            "label": label,
            "program": program,
            "program_args": program_args,
            "command": cmd_joined,
            "run_at_load": run_at_load,
            "keep_alive": bool(keep_alive) if isinstance(
                keep_alive, bool) else str(keep_alive),
            "start_interval": start_interval,
            "mtime": mtime,
        }
        self.entries.append(entry)

        # Classify
        is_sys_signed = any(label.lower().startswith(p)
                             for p in MAC_BENIGN_LABEL_PREFIXES) \
            or str(dir_path).startswith("/System/")
        cmd_low = cmd_joined.lower()

        suspicious_path_fragments = (
            "/tmp/", "/var/tmp/", "/private/tmp/",
            "/users/shared/", "~/downloads/", "/downloads/",
            "/documents/", "/desktop/",
        )
        script_extensions = (".sh", ".py", ".rb", ".pl", ".js",
                             ".command", ".scpt", ".applescript")
        encoded_markers = (
            "| base64 -d", " | base64 --decode",
            "echo ", "osascript -e",
            "curl ", "wget ", "| sh", "| bash",
            "ncat ", " nc -", " bash -c", " sh -c",
            "python -c", "python3 -c", "perl -e",
        )

        flagged = False
        reasons: List[str] = []
        sev = SEV_LOW
        mitre = ["T1543.001" if level == "user"
                 else "T1543.004"]

        if any(frag in cmd_low for frag in suspicious_path_fragments):
            sev = max(sev, SEV_HIGH)
            reasons.append(
                "Target executable lives in a user-writable / "
                "transient directory (/tmp, /Users/Shared, "
                "Downloads). Legitimate launchd services do not "
                "persist from these paths.")
            flagged = True
        if any(m in cmd_low for m in encoded_markers):
            sev = max(sev, SEV_HIGH)
            reasons.append(
                "Command chain contains base64-decode / curl-pipe-"
                "sh / osascript-inline patterns — canonical shape "
                "of a macOS persistence loader.")
            flagged = True
        if any(cmd_low.endswith(e) or e in cmd_low
                for e in script_extensions) \
                and not is_sys_signed:
            sev = max(sev, SEV_MED)
            reasons.append(
                "ProgramArguments points at a script file "
                "(.sh/.py/.scpt) outside Apple / known-vendor "
                "namespace.")
            flagged = True
        if not is_sys_signed and run_at_load and \
                (keep_alive or start_interval):
            sev = max(sev, SEV_LOW)
            reasons.append(
                "RunAtLoad + KeepAlive / StartInterval combo on a "
                "non-Apple / non-known-vendor label — ensures the "
                "payload relaunches; typical malware posture.")
            flagged = True
        if not flagged:
            return

        self.findings.append(Finding(
            source="mac.persistence",
            category=("persistence.launchagent_suspicious"
                      if level == "user"
                      else "persistence.launchdaemon_suspicious"),
            title=(f"Suspicious launchd {level}: {label or plist_path.name}"),
            severity=sev,
            conclusion=(
                f"Launchd {level} plist at '{plist_path}' "
                f"(label: '{label}') runs: '{cmd_joined}' "
                "at boot / user logon. " + " ".join(reasons)),
            description="macOS launchd plist inspection.",
            evidence=entry,
            timestamp=mtime,
            tags=mitre + ["macos", "persistence"]))

    # -- Login Items ----------------------------------------------

    def _collect_login_items(self) -> None:
        # Modern (post-Big Sur): stored in background-items DB
        # at /Library/Application Support/com.apple.backgroundtaskmanagementagent
        bm_db = Path(
            "/private/var/db/com.apple.backgroundtaskmanagementagent"
            "/BackgroundItems-v*.btm")
        # Legacy: ~/Library/Preferences/com.apple.loginitems.plist
        users_root = Path("/Users")
        if not _safe_exists(users_root):
            return
        try:
            users = list(users_root.iterdir())
        except (OSError, PermissionError):
            users = []
        for u in users:
            legacy = (u / "Library" / "Preferences"
                      / "com.apple.loginitems.plist")
            if not _safe_exists(legacy):
                continue
            data = _read_plist(legacy)
            if not data:
                continue
            for session_list in \
                    data.get("SessionItems", {}).get("CustomListItems", []):
                name = session_list.get("Name", "")
                self.entries.append({
                    "kind": "login_item_legacy",
                    "user": u.name, "name": name,
                    "raw": {k: str(v)[:200]
                            for k, v in session_list.items()},
                })
                if not any(name.lower().startswith(p[:-1])
                             for p in MAC_BENIGN_LABEL_PREFIXES):
                    self.findings.append(Finding(
                        source="mac.persistence",
                        category="persistence.login_item",
                        title=f"Login Item for user {u.name}: {name}",
                        severity=SEV_LOW,
                        conclusion=(
                            f"Legacy Login Item '{name}' is "
                            f"registered to run at user "
                            f"{u.name}'s login. Review whether "
                            "this is a known app."),
                        description="Legacy com.apple.loginitems "
                                    "entry.",
                        evidence={"user": u.name, "name": name},
                        tags=["T1547.007", "macos"]))

    # -- Cron ------------------------------------------------------

    def _collect_cron(self) -> None:
        cron_dirs = [
            Path("/usr/lib/cron/tabs"),
            Path("/var/at/tabs"),
            Path("/etc/cron.d"),
            Path("/etc/crontab"),
            Path("/etc/periodic"),
        ]
        for p in cron_dirs:
            if not _safe_exists(p):
                continue
            try:
                if p.is_file():
                    files = [p]
                else:
                    files = [x for x in p.rglob("*") if x.is_file()]
            except (OSError, PermissionError):
                continue
            for f in files:
                try:
                    content = f.read_text(
                        encoding="utf-8", errors="ignore")
                except (OSError, PermissionError):
                    continue
                self.entries.append({
                    "kind": "cron", "path": str(f),
                    "excerpt": content[:400],
                })
                if any(m in content.lower() for m in
                       ("| base64 -d", "curl ", "wget ",
                        "| sh", "python -c")):
                    self.findings.append(Finding(
                        source="mac.persistence",
                        category="persistence.cron_suspicious",
                        title=f"Suspicious cron entry: {f.name}",
                        severity=SEV_HIGH,
                        conclusion=(
                            f"Cron file '{f}' contains patterns "
                            "consistent with a downloader / "
                            "encoded-payload persistence job "
                            "(base64 decode, curl-pipe-sh, "
                            "python -c)."),
                        description="Cron job with loader pattern.",
                        evidence={"path": str(f),
                                   "excerpt": content[:400]},
                        tags=["T1053.003", "macos"]))

    # -- Shell profiles -----------------------------------------

    def _collect_shell_profiles(self) -> None:
        roots = [Path("/Users"), Path("/var/root")]
        for root in roots:
            if not _safe_exists(root):
                continue
            try:
                users = list(root.iterdir()) \
                    if root.is_dir() else [root]
            except (OSError, PermissionError):
                continue
            for user_dir in users:
                if not user_dir.is_dir():
                    continue
                for prof in self.SHELL_PROFILE_NAMES:
                    p = user_dir / prof
                    if not _safe_exists(p):
                        continue
                    try:
                        content = p.read_text(
                            encoding="utf-8", errors="ignore")
                    except (OSError, PermissionError):
                        continue
                    low = content.lower()
                    triggers = [m for m in (
                        "eval \"$(curl", "| base64 --decode",
                        "| base64 -d", "python -c", "perl -e",
                        "wget ", "nc ", "ncat ") if m in low]
                    if triggers:
                        self.findings.append(Finding(
                            source="mac.persistence",
                            category="persistence.shell_profile",
                            title=(f"Suspicious shell-profile "
                                   f"hook: {user_dir.name}/{prof}"),
                            severity=SEV_HIGH,
                            conclusion=(
                                f"Shell profile '{p}' loads a "
                                f"payload via {', '.join(triggers)} "
                                "— classic user-level persistence "
                                "that fires every time the user "
                                "opens a terminal."),
                            description="Shell profile loader hook.",
                            evidence={
                                "path": str(p),
                                "user": user_dir.name,
                                "triggers": triggers,
                                "excerpt": content[:400],
                            },
                            tags=["T1546.004", "macos",
                                  "persistence"]))
                    else:
                        self.entries.append({
                            "kind": "shell_profile",
                            "path": str(p),
                            "user": user_dir.name,
                            "length": len(content),
                        })


class MacTCCAnalyzer:
    """
    Parses TCC (Transparency, Consent, Control) databases — both
    system-wide and per-user. Every row is a permission grant made
    to an app; unauthorized entries (especially Full Disk Access,
    Accessibility, Camera, Microphone, Screen Recording) are prime
    persistence + espionage indicators.
    """

    SYSTEM_DB = Path(
        "/Library/Application Support/com.apple.TCC/TCC.db")

    # Services that if granted to a non-Apple / non-known-vendor
    # bundle ID are high-risk.
    HIGH_RISK_SERVICES = {
        "kTCCServiceSystemPolicyAllFiles":  "Full Disk Access",
        "kTCCServiceAccessibility":         "Accessibility "
                                             "(keylogger surface)",
        "kTCCServiceScreenCapture":         "Screen Recording",
        "kTCCServiceListenEvent":           "Input Monitoring",
        "kTCCServicePostEvent":             "Input Simulation",
        "kTCCServiceCamera":                "Camera",
        "kTCCServiceMicrophone":            "Microphone",
        "kTCCServiceAppleEvents":           "Control other apps",
        "kTCCServiceDeveloperTool":         "Developer Tool "
                                             "(code-signing bypass)",
    }

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        self._parse_db(self.SYSTEM_DB, level="system")
        # Per-user TCC
        users_root = Path("/Users")
        if _safe_exists(users_root):
            try:
                for u in users_root.iterdir():
                    ud = (u / "Library" / "Application Support"
                          / "com.apple.TCC" / "TCC.db")
                    if _safe_exists(ud):
                        self._parse_db(ud, level="user",
                                        user=u.name)
            except (OSError, PermissionError):
                pass
        self.logger.info(
            "macOS TCC: %d entries, %d findings",
            len(self.entries), len(self.findings))
        return self.entries, self.findings

    def _parse_db(self, db_path: Path, level: str,
                  user: str = "-") -> None:
        if not _safe_exists(db_path):
            return
        import sqlite3
        try:
            # TCC.db is locked by tccd; open read-only via URI +
            # immutable=1 to bypass.
            con = sqlite3.connect(
                f"file:{db_path}?mode=ro&immutable=1",
                uri=True, timeout=3)
        except sqlite3.Error as exc:
            self.logger.debug("TCC connect %s: %s",
                               db_path, exc)
            return
        try:
            try:
                cur = con.execute(
                    "SELECT service, client, client_type, "
                    "auth_value, last_modified FROM access")
            except sqlite3.OperationalError:
                cur = con.execute(
                    "SELECT service, client, client_type, "
                    "allowed, last_modified FROM access")
            for row in cur:
                service = row[0]
                client = row[1] or ""
                client_type = row[2]
                auth = row[3]
                last_mod = row[4]
                ts = None
                try:
                    if last_mod:
                        ts = dt.datetime.fromtimestamp(
                            int(last_mod),
                            tz=dt.timezone.utc).isoformat()
                except (TypeError, ValueError, OverflowError):
                    pass
                entry = {
                    "level": level, "user": user,
                    "service": service, "client": client,
                    "client_type": client_type,
                    "auth": auth,
                    "last_modified": ts,
                    "db_path": str(db_path),
                }
                self.entries.append(entry)

                # Classify: only ALLOWED grants for high-risk
                # services to non-Apple clients → flag.
                allowed = (auth == 2 or auth == 1
                           or str(auth) == "1")
                if not allowed:
                    continue
                if service not in self.HIGH_RISK_SERVICES:
                    continue
                client_low = client.lower()
                benign = any(client_low.startswith(p)
                              for p in MAC_BENIGN_LABEL_PREFIXES) \
                    or client_low.startswith("/system/") \
                    or client_low.startswith("/applications/")
                if benign:
                    continue
                service_friendly = self.HIGH_RISK_SERVICES[service]
                self.findings.append(Finding(
                    source="mac.tcc",
                    category="macos.tcc_grant_suspicious",
                    title=(f"TCC grant: '{client}' has "
                           f"'{service_friendly}'"),
                    severity=SEV_HIGH,
                    conclusion=(
                        f"TCC database ({level}-level, "
                        f"{db_path}) has an ALLOWED grant of "
                        f"'{service_friendly}' to client "
                        f"'{client}'. This client is not on the "
                        "Apple / known-vendor list. That category "
                        "(Full Disk Access / Accessibility / "
                        "Screen Recording / Input Monitoring) is "
                        "what a spyware / keylogger / screenshot "
                        "stealer needs — confirm this app is "
                        "expected."),
                    description="TCC.db ALLOWED grant for "
                                "sensitive service.",
                    evidence=entry,
                    timestamp=ts,
                    tags=["T1548", "T1056", "macos", "tcc"]))
        finally:
            con.close()


class MacQuarantineAnalyzer:
    """
    Parses each user's quarantine.sqlite (the macOS equivalent of
    Windows MOTW). Every file downloaded via a browser, torrent,
    AirDrop, etc. has a row. Cross-references origin URL + agent
    name — primary source for Initial Access reconstruction.
    """

    RELATIVE_DB = (
        "Library/Preferences/com.apple.LaunchServices.QuarantineEventsV2"
    )

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        users_root = Path("/Users")
        if not _safe_exists(users_root):
            return self.entries, self.findings
        try:
            users = list(users_root.iterdir())
        except (OSError, PermissionError):
            return self.entries, self.findings
        import sqlite3
        for u in users:
            db = u / self.RELATIVE_DB
            if not _safe_exists(db):
                continue
            try:
                con = sqlite3.connect(
                    f"file:{db}?mode=ro&immutable=1",
                    uri=True, timeout=3)
            except sqlite3.Error:
                continue
            try:
                cur = con.execute(
                    "SELECT LSQuarantineTimeStamp, "
                    "LSQuarantineAgentName, "
                    "LSQuarantineDataURLString, "
                    "LSQuarantineOriginURLString, "
                    "LSQuarantineSenderName, "
                    "LSQuarantineEventIdentifier "
                    "FROM LSQuarantineEvent "
                    "ORDER BY LSQuarantineTimeStamp DESC "
                    "LIMIT 400")
                for row in cur:
                    ts_raw, agent, data_url, origin, \
                        sender, ev_id = row
                    ts = None
                    try:
                        if ts_raw:
                            # Core-Data timestamps: seconds since
                            # 2001-01-01.
                            ts = (dt.datetime(
                                2001, 1, 1, tzinfo=dt.timezone.utc)
                                + dt.timedelta(
                                    seconds=float(ts_raw))
                                ).isoformat()
                    except (TypeError, ValueError, OverflowError):
                        pass
                    entry = {
                        "user": u.name, "timestamp": ts,
                        "agent": agent,
                        "data_url": data_url,
                        "origin_url": origin,
                        "sender": sender,
                        "event_id": ev_id,
                    }
                    self.entries.append(entry)
                    self._classify_quarantine(entry)
            except sqlite3.Error as exc:
                self.logger.debug("quarantine %s: %s", db, exc)
            finally:
                con.close()
        self.logger.info(
            "macOS quarantine: %d events, %d findings",
            len(self.entries), len(self.findings))
        return self.entries, self.findings

    def _classify_quarantine(self, e: Dict[str, Any]) -> None:
        data_url = (e.get("data_url") or "").lower()
        origin = (e.get("origin_url") or "").lower()
        combined = data_url + " " + origin
        agent = (e.get("agent") or "").lower()

        # Script / installer extension arriving from browser = phish
        risky_ext = (".sh", ".py", ".pkg", ".dmg", ".command",
                     ".scpt", ".applescript", ".jar")
        if any(data_url.endswith(ext) for ext in risky_ext):
            if data_url.endswith((".sh", ".command", ".scpt")):
                sev = SEV_HIGH
            else:
                sev = SEV_MED
            self.findings.append(Finding(
                source="mac.quarantine",
                category="delivery.quarantine_risky",
                title=(f"Quarantined risky download: "
                       f"{Path(data_url).name or data_url[:60]}"),
                severity=sev,
                conclusion=(
                    f"User '{e.get('user')}' downloaded "
                    f"'{e.get('data_url')}' via '{e.get('agent')}' "
                    f"(origin: '{e.get('origin_url')}') at "
                    f"{e.get('timestamp')}. Script / installer "
                    "extensions delivered through a browser are "
                    "the top macOS phishing vector."),
                description="Quarantine event for risky download.",
                evidence=e,
                timestamp=e.get("timestamp"),
                tags=["T1189", "T1204", "macos",
                      "initial-access"]))

        # Known paste / anonymous services
        anon = ("anonfiles", "mega.nz", "transfer.sh",
                "file.io", "gofile.io", "catbox.moe",
                "uploadfiles.io", "pastebin", "rentry",
                "ghostbin", "privatebin")
        if any(a in combined for a in anon):
            self.findings.append(Finding(
                source="mac.quarantine",
                category="darknet.quarantine_anon_service",
                title=f"Download from anonymous service "
                      f"(quarantine)",
                severity=SEV_HIGH,
                conclusion=(
                    f"Quarantine records a download from an "
                    f"anonymous file-share / paste service: "
                    f"'{e.get('origin_url')}' -> "
                    f"'{e.get('data_url')}'. These services are "
                    "the dominant macOS malware distribution "
                    "channel (XCSSET, KandyKorn, etc.)."),
                description="Quarantine origin URL on anonymous "
                            "service list.",
                evidence=e,
                timestamp=e.get("timestamp"),
                tags=["T1567.002", "macos"]))


class MacSecurityAnalyzer:
    """
    Status of the three macOS defenses: SIP (System Integrity
    Protection), Gatekeeper, and XProtect. Any of them disabled or
    out-of-date is an attacker-prep or weakening indicator.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.state: Dict[str, Any] = {}
        self.findings: List[Finding] = []

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        self._check_sip()
        self._check_gatekeeper()
        self._check_xprotect()
        return self.state, self.findings

    def _run(self, cmd: List[str], timeout: int = 10
             ) -> Optional[str]:
        try:
            r = subprocess.run(cmd, capture_output=True,
                                text=True, timeout=timeout)
            return (r.stdout or "").strip() or None
        except (subprocess.TimeoutExpired, OSError,
                FileNotFoundError):
            return None

    def _check_sip(self) -> None:
        out = self._run(["csrutil", "status"])
        if not out:
            return
        self.state["sip"] = out
        if "disabled" in out.lower():
            self.findings.append(Finding(
                source="mac.security", category="macos.sip_disabled",
                title="SIP (System Integrity Protection) disabled",
                severity=SEV_CRIT,
                conclusion=(
                    "`csrutil status` reports SIP disabled. "
                    "Without SIP, protected system directories "
                    "can be written to, kernel drivers can be "
                    "loaded unsigned, and the runtime integrity of "
                    "macOS is off. Essentially zero modern macOS "
                    "malware runs without first disabling SIP; "
                    "this state alone is an indicator of "
                    "compromise — or at best, a very unusual "
                    "deliberate configuration."),
                description="csrutil status output.",
                evidence={"csrutil_output": out},
                tags=["T1562.001", "macos"]))

    def _check_gatekeeper(self) -> None:
        out = self._run(["spctl", "--status"])
        if not out:
            return
        self.state["gatekeeper"] = out
        if "disabled" in out.lower() or "no" in out.lower():
            self.findings.append(Finding(
                source="mac.security",
                category="macos.gatekeeper_disabled",
                title="Gatekeeper disabled",
                severity=SEV_HIGH,
                conclusion=(
                    "`spctl --status` reports Gatekeeper "
                    "assessments disabled. Unsigned / unnotarized "
                    "apps now run without warning. Attacker can "
                    "drop and execute arbitrary binaries with no "
                    "user prompt."),
                description="spctl --status output.",
                evidence={"spctl_output": out},
                tags=["T1562.001", "macos"]))

    def _check_xprotect(self) -> None:
        for candidate in (
                Path("/Library/Apple/System/Library/"
                     "CoreServices/XProtect.bundle/Contents/"
                     "Resources/XProtect.plist"),
                Path("/System/Library/CoreServices/XProtect.bundle/"
                     "Contents/Resources/XProtect.plist")):
            if _safe_exists(candidate):
                try:
                    mtime = _iso_from_st(
                        candidate.stat().st_mtime)
                except OSError:
                    mtime = ""
                self.state["xprotect_plist"] = str(candidate)
                self.state["xprotect_mtime"] = mtime
                # If older than 60 days → out-of-date flag
                try:
                    age = (_now_utc()
                            - dt.datetime.fromisoformat(
                                mtime.replace("Z","+00:00"))
                            ).days
                    if age > 60:
                        self.findings.append(Finding(
                            source="mac.security",
                            category="macos.xprotect_outdated",
                            title=(f"XProtect definitions are "
                                   f"{age} days old"),
                            severity=SEV_LOW,
                            conclusion=(
                                "XProtect (macOS's built-in AV "
                                f"signature database) has not been "
                                f"updated in {age} days. Apple "
                                "pushes definitions roughly "
                                "monthly; >60 days is a sign of a "
                                "stale / offline / tampered "
                                "host."),
                            description="XProtect.plist mtime age.",
                            evidence={
                                "path": str(candidate),
                                "mtime": mtime,
                                "age_days": age,
                            },
                            tags=["T1562", "macos"]))
                except (ValueError, TypeError):
                    pass
                break


class MacSSHAnalyzer:
    """
    Walks ~/.ssh/authorized_keys and known_hosts for every user.
    Any new authorized_keys entry on an account is a top-tier
    backdoor — attacker plants their public key and SSHes in.
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        users_root = Path("/Users")
        if not _safe_exists(users_root):
            return self.entries, self.findings
        try:
            user_dirs = list(users_root.iterdir())
        except (OSError, PermissionError):
            user_dirs = []
        user_dirs.append(Path("/var/root"))
        for u in user_dirs:
            auth = u / ".ssh" / "authorized_keys"
            if not _safe_exists(auth):
                continue
            try:
                content = auth.read_text(
                    encoding="utf-8", errors="ignore")
                mtime = _iso_from_st(auth.stat().st_mtime)
            except (OSError, PermissionError):
                continue
            lines = [l for l in content.splitlines()
                     if l.strip() and not l.startswith("#")]
            for key_line in lines:
                parts = key_line.strip().split(" ", 2)
                key_type = parts[0] if parts else ""
                comment = parts[2] if len(parts) >= 3 else ""
                self.entries.append({
                    "user": u.name, "path": str(auth),
                    "key_type": key_type,
                    "comment": comment,
                    "mtime": mtime,
                })
            if lines:
                self.findings.append(Finding(
                    source="mac.ssh",
                    category="persistence.ssh_authorized_keys",
                    title=(f"SSH authorized_keys present for "
                           f"{u.name} ({len(lines)} key(s))"),
                    severity=SEV_MED,
                    conclusion=(
                        f"'{auth}' contains {len(lines)} "
                        "authorized key(s) (last modified "
                        f"{mtime}). Every key in this file can "
                        f"log in as '{u.name}' without a "
                        "password. Attacker-added authorized "
                        "keys are a top-tier backdoor — confirm "
                        "each key comment matches an expected "
                        "admin and that no unknown public keys "
                        "were added."),
                    description="SSH authorized_keys inventory.",
                    evidence={
                        "user": u.name, "path": str(auth),
                        "key_count": len(lines),
                        "mtime": mtime,
                        "keys": [{
                            "type": l.split(" ", 1)[0]
                                    if l.split(" ") else "",
                            "comment": (l.split(" ", 2)[2]
                                         if len(l.split(" ")) >= 3
                                         else ""),
                        } for l in lines[:10]],
                    },
                    timestamp=mtime,
                    tags=["T1098.004", "macos"]))


class MacKextAnalyzer:
    """Inventory of loaded kernel extensions + system extensions.
    Any third-party kext on modern macOS is worth review; user-
    path or unsigned kexts are CRITICAL."""

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.entries: List[Dict[str, Any]] = []
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Dict[str, Any]], List[Finding]]:
        try:
            r = subprocess.run(
                ["kextstat", "-l"], capture_output=True,
                text=True, timeout=15)
            out = (r.stdout or "").splitlines()
        except (subprocess.TimeoutExpired, OSError,
                FileNotFoundError):
            return self.entries, self.findings
        for line in out:
            parts = line.split()
            if len(parts) < 6:
                continue
            bundle_id = parts[5] if len(parts) >= 6 else ""
            if not bundle_id:
                continue
            self.entries.append({
                "bundle_id": bundle_id, "raw": line})
            if bundle_id.lower().startswith(
                    ("com.apple.", "io.apple.", "as.apple.")):
                continue
            # Any non-Apple kext is worth flagging on modern macOS
            self.findings.append(Finding(
                source="mac.kext",
                category="macos.kext_non_apple",
                title=f"Non-Apple kernel extension loaded: "
                      f"{bundle_id}",
                severity=SEV_MED,
                conclusion=(
                    f"Kernel extension '{bundle_id}' is loaded. "
                    "On modern macOS (Big Sur+) third-party kexts "
                    "are rare and increasingly deprecated in "
                    "favor of System Extensions. Confirm this "
                    "kext belongs to a trusted driver / EDR / "
                    "VPN product."),
                description="kextstat non-Apple bundle.",
                evidence={"bundle_id": bundle_id,
                          "raw_line": line},
                tags=["T1547.006", "macos"]))
        self.logger.info(
            "macOS kext: %d loaded, %d findings",
            len(self.entries), len(self.findings))
        return self.entries, self.findings


class MacShellHistoryAnalyzer:
    """Parses ~/.zsh_history and ~/.bash_history for suspicious
    command patterns."""

    BAD_PATTERNS = (
        "curl ", "wget ", "| base64 -d", "| base64 --decode",
        "python -c ", "python3 -c ", "perl -e ", "ruby -e ",
        "osascript -e", "eval \"$(curl", "| sh", "| bash",
        "chmod +x", "sudo -i", " /tmp/", "/var/tmp/",
        "launchctl load", "launchctl bootstrap",
        "kextload", "csrutil disable",
    )

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Any], List[Finding]]:
        users_root = Path("/Users")
        if not _safe_exists(users_root):
            return [], self.findings
        try:
            users = list(users_root.iterdir())
        except (OSError, PermissionError):
            users = []
        for u in users:
            for hist in (".zsh_history", ".bash_history"):
                p = u / hist
                if not _safe_exists(p):
                    continue
                try:
                    content = p.read_text(
                        encoding="utf-8", errors="ignore")
                except (OSError, PermissionError):
                    continue
                for pat in self.BAD_PATTERNS:
                    if pat in content:
                        # Extract the specific line
                        matching_lines = [
                            l for l in content.splitlines()
                            if pat in l][:5]
                        self.findings.append(Finding(
                            source="mac.shell",
                            category="execution.shell_history",
                            title=(f"Shell history of '{u.name}' "
                                   f"has '{pat.strip()}'"),
                            severity=SEV_MED,
                            conclusion=(
                                f"Shell history '{p}' contains "
                                f"{len(matching_lines)} line(s) "
                                f"with the pattern '{pat.strip()}'. "
                                "This pattern is commonly abused "
                                "by attackers / pentesters "
                                "post-foothold."),
                            description="Shell history pattern "
                                        "match.",
                            evidence={
                                "user": u.name, "path": str(p),
                                "pattern": pat,
                                "matching_lines": matching_lines,
                            },
                            tags=["T1059.004", "macos"]))
                        break   # one finding per file is enough
        return [], self.findings


class MacUnifiedLogAnalyzer:
    """Queries the macOS Unified Log via `log show` for high-signal
    security events in the last 24 hours. Bounded by timeout so it
    does not block the whole analyzer on a busy host."""

    PREDICATE = (
        'eventMessage CONTAINS "authentication" '
        'OR eventMessage CONTAINS "sudo" '
        'OR eventMessage CONTAINS "authd" '
        'OR subsystem == "com.apple.securityd" '
        'OR subsystem == "com.apple.authd" '
        'OR subsystem == "com.apple.TCC"'
    )

    def __init__(self, logger: logging.Logger,
                 hours: int = 24):
        self.logger = logger
        self.hours = hours
        self.findings: List[Finding] = []

    def run(self) -> Tuple[List[Any], List[Finding]]:
        try:
            r = subprocess.run(
                ["log", "show", "--style", "compact",
                 "--last", f"{self.hours}h",
                 "--predicate", self.PREDICATE],
                capture_output=True, text=True, timeout=60)
            out = r.stdout or ""
        except (subprocess.TimeoutExpired, OSError,
                FileNotFoundError):
            return [], self.findings
        lines = out.splitlines()
        sudo_fails = sum(1 for l in lines
                          if "sudo" in l.lower()
                          and "incorrect" in l.lower())
        tcc_prompts = sum(1 for l in lines
                           if "TCC" in l and
                           "prompting" in l.lower())
        if sudo_fails >= 5:
            self.findings.append(Finding(
                source="mac.uls",
                category="auth.sudo_brute",
                title=f"{sudo_fails} failed sudo attempts "
                      f"in last {self.hours}h",
                severity=SEV_HIGH,
                conclusion=(
                    f"The Unified Log recorded {sudo_fails} "
                    "incorrect-password sudo attempts in the "
                    f"last {self.hours}h. Cluster of failures = "
                    "local brute-force against an admin account."),
                description="log show sudo fail count.",
                evidence={"failures": sudo_fails,
                          "hours": self.hours},
                tags=["T1110", "macos"]))
        return [], self.findings


class MacOSDispatcher:
    """Orchestrates the full macOS analyzer stack. Called from
    main() when `platform.system() == 'Darwin'`."""

    def __init__(self, args, logger: logging.Logger):
        self.args = args
        self.logger = logger
        self.all_findings: List[Finding] = []
        self.state: Dict[str, Any] = {}

    def run(self) -> Tuple[Dict[str, Any], List[Finding]]:
        self._run_one(MacPersistenceAnalyzer, "persistence")
        self._run_one(MacTCCAnalyzer, "tcc")
        self._run_one(MacQuarantineAnalyzer, "quarantine")
        self._run_one(MacSecurityAnalyzer, "security")
        self._run_one(MacSSHAnalyzer, "ssh")
        self._run_one(MacKextAnalyzer, "kext")
        self._run_one(MacShellHistoryAnalyzer, "shell_history")
        self._run_one(MacUnifiedLogAnalyzer, "uls")
        return self.state, self.all_findings

    def _run_one(self, cls, key: str) -> None:
        try:
            inst = cls(self.logger)
            result = inst.run()
            # Analyzer returns (state, findings) OR ([], findings)
            if isinstance(result, tuple) and len(result) == 2:
                st, finds = result
                self.state[key] = st
                self.all_findings.extend(finds)
        except Exception as exc:
            self.logger.debug(
                "macOS %s failed: %s", key, exc)


# ---------------------------------------------------------------------------
# Orchestrator / CLI.
# ---------------------------------------------------------------------------

def default_evtx(sys_root: Path) -> List[Path]:
    base = sys_root / "System32" / "winevt" / "Logs"
    return [base / x for x in (
        "Security.evtx", "System.evtx", "Application.evtx",
        "Microsoft-Windows-PowerShell%4Operational.evtx",
        "Microsoft-Windows-TaskScheduler%4Operational.evtx",
        "Microsoft-Windows-Sysmon%4Operational.evtx",
        "Microsoft-Windows-CodeIntegrity%4Operational.evtx",
        "Microsoft-Windows-AppLocker%4EXE and DLL.evtx",
        "Microsoft-Windows-AppLocker%4MSI and Script.evtx",
        "Microsoft-Windows-TerminalServices-LocalSessionManager%4Operational.evtx",
        "Microsoft-Windows-Bits-Client%4Operational.evtx",
    )]


def default_hives(sys_root: Path,
                  user_home: Optional[Path]) -> Dict[str, Path]:
    cfg = sys_root / "System32" / "config"
    hives = {
        "system":  cfg / "SYSTEM",
        "software": cfg / "SOFTWARE",
        "amcache": sys_root / "appcompat" / "Programs" / "Amcache.hve",
    }
    if user_home:
        hives["ntuser"] = user_home / "NTUSER.DAT"
    return hives


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="forensic_master_analyzer",
        description=f"{TOOL_NAME} v{TOOL_VERSION}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--memory", type=Path,
                   help="Memory image (.raw / .dmp / .lime).")
    p.add_argument("--live", action="store_true",
                   help="Force live triage (also implied when no "
                        "memory/dumps are supplied).")
    p.add_argument("--dumps", type=Path, nargs="*",
                   help="Explicit dump files to analyze. Defaults to "
                        "auto-discovery of MEMORY.DMP + Minidumps + "
                        "WER + user-mode CrashDumps.")
    p.add_argument("--no-dump-discovery", action="store_true")
    p.add_argument("--evtx", type=Path, nargs="*")
    p.add_argument("--amcache", type=Path)
    p.add_argument("--system-hive", type=Path)
    p.add_argument("--ntuser", type=Path)
    p.add_argument("--mft", type=Path)
    p.add_argument("--prefetch", type=Path,
                   default=Path(r"C:\Windows\Prefetch"))
    p.add_argument("--tasks", type=Path,
                   default=Path(r"C:\Windows\System32\Tasks"))
    p.add_argument("--output", type=Path,
                   default=Path.cwd() / "report.html")
    p.add_argument("--workdir", type=Path,
                   default=Path.cwd() / "fma-workdir")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--no-bootstrap", action="store_true")
    # --- v3.0 additions ---
    p.add_argument("--iocs", type=Path,
                   help="JSON IoC file with ips/domains/hashes/"
                        "filenames/yara rule paths.")
    p.add_argument("--yara-rules", type=Path, nargs="*",
                   help="Extra YARA rule files to compile "
                        "alongside the built-in ruleset.")
    p.add_argument("--min-severity", type=str, default="info",
                   choices=["info", "low", "medium", "high",
                            "critical"],
                   help="Drop findings below this severity from the "
                        "report.")
    p.add_argument("--anonymize", action="store_true",
                   help="Redact usernames / IPs / hostnames from "
                        "the report before it leaves the host.")
    p.add_argument("--no-enrichment", action="store_true",
                   help="Skip file hashing / Authenticode / YARA "
                        "enrichment (faster, less signal).")
    # --- v4.0 additions ---
    p.add_argument("--baseline", type=Path,
                   help="Previous report.json to compare against — "
                        "NEW findings will be annotated.")
    p.add_argument("--vt-api-key", type=str,
                   help="VirusTotal API key (enables hash "
                        "reputation enrichment).")
    p.add_argument("--abuseipdb-key", type=str,
                   help="AbuseIPDB API key (enables IP reputation "
                        "enrichment).")
    p.add_argument("--geoip-db", type=Path,
                   help="Path to MaxMind GeoLite2-City/Country "
                        "mmdb file.")
    p.add_argument("--ntds", type=Path,
                   help="Offline NTDS.dit file to analyze.")
    p.add_argument("--pcap-duration", type=int, default=0,
                   help="Capture N seconds of pcap via pktmon "
                        "during triage (0 = disabled, default).")
    p.add_argument("--pdf", action="store_true",
                   help="Also render the report to PDF via "
                        "headless Chromium / Edge.")
    p.add_argument("--exec-pdf", action="store_true",
                   help="Also emit a 1-page executive summary PDF.")
    p.add_argument("--lang", type=str, default="en",
                   choices=["en", "he"],
                   help="Report language (en, he).")
    return p


_SEV_FROM_NAME = {"info": SEV_INFO, "low": SEV_LOW, "medium": SEV_MED,
                  "high": SEV_HIGH, "critical": SEV_CRIT}


def apply_redaction(findings: List[Finding],
                     metadata: Dict[str, Any]) -> None:
    """Redacts usernames, IPv4s, hostnames, SIDs. In-place mutation."""
    USERNAME_RE = re.compile(
        r"\b(?:[A-Z0-9_-]+\\)?[a-zA-Z][a-zA-Z0-9_.-]{1,30}\b")
    IP_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
    SID_RE = re.compile(r"\bS-1-5-\d+(?:-\d+)*\b")

    def redact_str(s: str) -> str:
        if not isinstance(s, str):
            return s
        s = IP_RE.sub("<IP>", s)
        s = SID_RE.sub("<SID>", s)
        # Username redaction is more aggressive but confined to
        # known label fields (avoid redacting the whole narrative).
        return s

    def redact_evidence(ev):
        if isinstance(ev, dict):
            return {k: redact_evidence(v) for k, v in ev.items()}
        if isinstance(ev, list):
            return [redact_evidence(x) for x in ev]
        if isinstance(ev, str):
            return redact_str(ev)
        return ev

    host = metadata.get("host", "")
    for f in findings:
        f.title = redact_str(f.title)
        f.conclusion = redact_str(f.conclusion)
        f.description = redact_str(f.description)
        f.evidence = redact_evidence(f.evidence)
        if host and host in (f.conclusion or ""):
            f.conclusion = f.conclusion.replace(host, "<HOST>")
    # Redact host/user labels in metadata
    metadata["host"] = "<HOST>"
    metadata["image"] = "<IMAGE>" if metadata.get("image") \
        not in ("live triage", "n/a") else metadata["image"]


def write_custody_manifest(output_path: Path, findings: List[Finding],
                            metadata: Dict[str, Any]) -> Path:
    """Chain-of-custody sidecar file: what was collected, when, and
    the SHA256 of every output artifact."""
    manifest_path = output_path.with_suffix(".manifest.json")
    html_sha = ""
    json_sha = ""
    try:
        if output_path.exists():
            html_sha = hashlib.sha256(
                output_path.read_bytes()).hexdigest()
        json_sibling = output_path.with_suffix(".json")
        if json_sibling.exists():
            json_sha = hashlib.sha256(
                json_sibling.read_bytes()).hexdigest()
    except OSError:
        pass
    manifest = {
        "tool":              f"{TOOL_NAME} v{TOOL_VERSION}",
        "generated_at":      _iso(_now_utc()),
        "collected_on":      metadata.get("host"),
        "collected_by":      os.environ.get("USERNAME")
                              or os.environ.get("USER"),
        "findings_total":    len(findings),
        "threat_score":      metadata.get("threat_score"),
        "artifacts": {
            "report_html":    str(output_path),
            "report_html_sha256": html_sha,
            "report_json":    str(output_path.with_suffix(".json")),
            "report_json_sha256": json_sha,
        },
        "platform": {
            "os":      platform.platform(),
            "node":    platform.node(),
            "python":  sys.version,
        },
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, default=str),
        encoding="utf-8")
    return manifest_path


def main(argv: Optional[List[str]] = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if not args.no_bootstrap:
        bootstrap_dependencies()

    logger = make_logger("FMA", args.verbose)
    logger.info("=== %s v%s ===", TOOL_NAME, TOOL_VERSION)
    args.workdir.mkdir(parents=True, exist_ok=True)
    started = _now_utc()

    # System profile (hostname, OS, MAC, IPs, domain, users) — first
    # thing we do, so every downstream log line is already tagged.
    sys_profile = SystemProfileAnalyzer(logger).run()

    # macOS: dispatch to the macOS-specific analyzer stack. All
    # Windows-only collectors below will no-op cleanly via their
    # `os.name != 'nt'` guards, so the report structure stays
    # platform-agnostic.
    if platform.system() == "Darwin":
        logger.info("macOS host detected — running MacOSDispatcher")
        _, mac_findings = MacOSDispatcher(args, logger).run()
        # Stored temporarily; merged with `all_findings` below.
        _macos_findings = mac_findings
    else:
        _macos_findings = []

    all_findings: List[Finding] = []
    # Merge macOS findings (if this is a Darwin host)
    if _macos_findings:
        all_findings.extend(_macos_findings)
    mem_results: Dict[str, Any] = {}
    evt_events: List[Dict[str, Any]] = []
    reg_results: Dict[str, List[Dict[str, Any]]] = {
        "amcache": [], "shimcache": [], "userassist": []}
    mft_records: List[Dict[str, Any]] = []
    dump_records: List[Dict[str, Any]] = []
    prefetch_entries: List[Dict[str, Any]] = []
    bam_entries: List[Dict[str, Any]] = []
    browser_obj: Optional["BrowserArtifactsAnalyzer"] = None

    # Memory image
    if args.memory:
        m = MemoryAnalyzer(args.memory, args.workdir, logger)
        mem_results, f = m.run()
        all_findings.extend(f)

    # Crash dumps
    dump_paths: List[Path] = []
    if args.dumps:
        dump_paths += [Path(p) for p in args.dumps]
    if not args.no_dump_discovery:
        dump_paths += DumpAnalyzer.auto_discover()
    if dump_paths:
        dump_paths = [p for p in dump_paths
                      if (not args.memory or p != args.memory)]
        da = DumpAnalyzer(dump_paths, args.workdir, logger)
        dump_records, f = da.run()
        all_findings.extend(f)
        logger.info("Crash dumps: %d files, %d records, %d findings",
                    len(dump_paths), len(dump_records),
                    len([x for x in f]))

    # Event logs
    sys_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
    evtx_list = [Path(p) for p in (args.evtx or default_evtx(sys_root))]
    event_overview: Dict[int, Dict[str, Any]] = {}
    if evtx_list:
        el = EventLogAnalyzer(evtx_list, logger)
        evt_events, f = el.run()
        all_findings.extend(f)
        # Serialize sets to lists for JSON-friendly overview.
        # suspicious_samples / benign_samples are already list-of-dict.
        event_overview = {
            eid: {**s,
                  "channels": sorted(s.get("channels", set()))}
            for eid, s in el.event_overview.items()
        }

    # Registry hives
    user_home = Path(os.environ.get("USERPROFILE", "")) \
        if os.name == "nt" else None
    dflt = default_hives(sys_root, user_home)
    hives = {
        "system":  args.system_hive or dflt.get("system"),
        "amcache": args.amcache     or dflt.get("amcache"),
        "ntuser":  args.ntuser      or dflt.get("ntuser"),
    }
    ra = RegistryArtifacts(hives, logger)
    reg_results, f = ra.run()
    all_findings.extend(f)

    # Autoruns (live, expanded: Run keys + RunOnce + Winlogon +
    # AppInit + IFEO + Startup folders)
    autoruns = AutorunsAnalyzer(logger)
    _, f = autoruns.run()
    all_findings.extend(f)

    # Registry fingerprint + delta — detects NEW / CHANGED persistence
    # entries vs the snapshot saved in the workdir. Emits findings
    # only for malicious-shaped changes.
    reg_fp = RegistryFingerprintAnalyzer(args.workdir, logger)
    _, f = reg_fp.run()
    all_findings.extend(f)

    # BAM / DAM execution history (requires SYSTEM hive snapshot)
    bam_entries: List[Dict[str, Any]] = []
    if _safe_exists(hives.get("system")):
        bam = BAMAnalyzer(hives["system"], logger)
        bam_entries, f = bam.run()
        all_findings.extend(f)

    # SRUM presence report (stub; real parsing requires ESE reader)
    srum = SRUMAnalyzer(logger)
    _, f = srum.run()
    all_findings.extend(f)

    # WMI event-subscription persistence (APT-tier)
    wmi = WMIPersistenceAnalyzer(logger)
    _, f = wmi.run()
    all_findings.extend(f)

    # Windows Defender tamper detection
    defender = DefenderAnalyzer(logger)
    _, f = defender.run()
    all_findings.extend(f)

    # Scheduled tasks
    st = ScheduledTasksAnalyzer(args.tasks, logger)
    _, f = st.run()
    all_findings.extend(f)

    # Prefetch
    pf = PrefetchAnalyzer(args.prefetch, logger)
    prefetch_entries, f = pf.run()
    all_findings.extend(f)

    # Live process tree (skipped only when an offline image is sufficient)
    live_snapshot: Dict[str, Any] = {}
    if (not args.memory) or args.live:
        pt = ProcessTreeAnalyzer(logger)
        live_snapshot, f = pt.run()
        all_findings.extend(f)

    # Network inventory (listening + established + DNS cache)
    net_inv = NetworkInventoryAnalyzer(logger)
    net_state, f = net_inv.run()
    all_findings.extend(f)

    # Domain intelligence (membership, Kerberos, cred manager,
    # cached logons, shares, DC visibility, AD recon tooling)
    domain_intel = DomainIntelAnalyzer(logger)
    domain_state, f = domain_intel.run()
    all_findings.extend(f)

    # Darknet / data-leakage indicators — feeds off the browser
    # artifacts collected earlier plus the live network state.
    browser_snapshot: Dict[str, Any] = {}
    if browser_obj is not None:
        browser_snapshot = {
            "history": getattr(browser_obj, "history", []) or [],
            "downloads": getattr(browser_obj, "downloads", []) or [],
        }
    darknet = DarknetLeakAnalyzer(
        logger, browser_state=browser_snapshot,
        net_state=net_state)
    darknet_state, f = darknet.run()
    all_findings.extend(f)

    # MFT
    if args.mft:
        mft = MFTAnalyzer(args.mft, logger)
        mft_records, f = mft.run()
        all_findings.extend(f)

    # -- v3.1 additions: exhaustive Tier-2 collection ---------------
    # MPLog (Defender telemetry)
    mp = MPLogAnalyzer(logger)
    _, f = mp.run()
    all_findings.extend(f)

    # USB history (requires SYSTEM hive for full USBSTOR)
    usb = USBHistoryAnalyzer(hives.get("system"),
                              hives.get("ntuser"), logger)
    _, f = usb.run()
    all_findings.extend(f)

    # COM hijacking
    com = COMHijackAnalyzer(logger)
    _, f = com.run()
    all_findings.extend(f)

    # ETW tampering
    etw = ETWTamperingAnalyzer(logger)
    _, f = etw.run()
    all_findings.extend(f)

    # VSS shadow copies (requires admin)
    vss = VSSAnalyzer(logger)
    _, f = vss.run()
    all_findings.extend(f)

    # LNK / recent-docs
    lnk = LNKAnalyzer(logger)
    _, f = lnk.run()
    all_findings.extend(f)

    # BITS jobs (via bitsadmin)
    bits = BITSAnalyzer(logger)
    _, f = bits.run()
    all_findings.extend(f)

    # Outlook inbox rules / profiles
    outlook = OutlookRulesAnalyzer(logger)
    _, _ = outlook.run()

    # Chromium password-store inventory
    chrome_ps = ChromiumPasswordStoreAnalyzer(logger)
    _, f = chrome_ps.run()
    all_findings.extend(f)

    # Browser artifacts (SQLite)
    try:
        browser_obj = BrowserArtifactsAnalyzer(logger, args.workdir)
        _, f = browser_obj.run()
        all_findings.extend(f)
    except Exception as exc:
        logger.debug("browser artifacts failed: %s", exc)

    # LSA secrets / SAM access indicators (event-based)
    lsa = LSAAccessAnalyzer(evt_events, logger)
    (lsa_f,) = lsa.run()
    all_findings.extend(lsa_f)

    # Sigma rule engine (on parsed Security/Sysmon/PS events)
    sigma = SigmaEngine(None, logger)
    all_findings.extend(sigma.run(evt_events))

    # SRUM body parse (if dissect.esedb is installed)
    srum_body = SRUMBodyAnalyzer(None, logger)
    _, f = srum_body.run()
    all_findings.extend(f)

    # Correlation
    ce = CorrelationEngine(mem_results, evt_events, reg_results,
                           mft_records, dump_records, all_findings,
                           logger)
    all_findings.extend(ce.run())

    # Driver authenticode audit (kernel BYOVD detection)
    try:
        drivers = DriverAuditAnalyzer(logger)
        _, f = drivers.run()
        all_findings.extend(f)
    except Exception as exc:
        logger.debug("Driver audit failed: %s", exc)

    # PE Integrity — verify Authenticode of ~40 critical system
    # binaries. Catches rootkit / bootkit / BYOVD replacement.
    try:
        pe_int = PEIntegrityAnalyzer(logger)
        _, f = pe_int.run()
        all_findings.extend(f)
    except Exception as exc:
        logger.debug("PE integrity failed: %s", exc)

    # Live-process YARA scan — runs bundled rules against every
    # accessible process's memory. Catches in-memory Mimikatz /
    # Cobalt Strike / Meterpreter WITHOUT requiring a dump.
    try:
        live_yara = LiveProcessYaraAnalyzer(
            logger, extra_yara=[Path(p)
                                for p in (args.yara_rules or [])])
        _, f = live_yara.run()
        all_findings.extend(f)
    except Exception as exc:
        logger.debug("Live YARA failed: %s", exc)

    # USN Journal — best-effort (requires admin). Reveals files
    # that were created and deleted inside the journal window.
    try:
        usn = USNJournalAnalyzer(
            "C:", args.workdir, logger)
        _, f = usn.run()
        all_findings.extend(f)
    except Exception as exc:
        logger.debug("USN Journal failed: %s", exc)

    # NTDS.dit offline analysis (if provided and dissect.esedb is
    # available)
    if args.ntds:
        ntds = NTDSAnalyzer(args.ntds, logger)
        _, f = ntds.run()
        all_findings.extend(f)

    # Optional pcap capture (pktmon)
    pcap_path: Optional[Path] = None
    if args.pcap_duration > 0:
        pcap_path = PcapTrigger(args.workdir, args.pcap_duration,
                                 logger).run()

    # Enrichment: hash every referenced file, verify Authenticode,
    # run YARA. This adds the intel-grade information every SOC
    # analyst asks for when triaging a finding.
    if not args.no_enrichment:
        logger.info("Enrichment pass (hash / Authenticode / YARA)...")
        enricher = FindingEnricher(
            logger,
            extra_yara=[Path(p) for p in (args.yara_rules or [])])
        enricher.run(all_findings)

    # Threat-intel enrichment (optional, API-key gated). Resolve
    # keys from CLI → env vars → fma-config.json (script dir).
    _cfg = load_local_config()
    vt_key = (args.vt_api_key
              or os.environ.get("FMA_VT_API_KEY")
              or _cfg.get("vt_api_key"))
    abuseipdb_key = (args.abuseipdb_key
                      or os.environ.get("FMA_ABUSEIPDB_KEY")
                      or _cfg.get("abuseipdb_key"))
    geoip_db = args.geoip_db
    if not geoip_db and _cfg.get("geoip_db"):
        geoip_db = Path(str(_cfg["geoip_db"]))
    if vt_key or abuseipdb_key or geoip_db:
        logger.info(
            "Threat-intel: VT=%s AbuseIPDB=%s GeoIP=%s",
            "yes" if vt_key else "no",
            "yes" if abuseipdb_key else "no",
            "yes" if geoip_db else "no")
        ThreatIntelEnricher(
            logger,
            vt_key=vt_key,
            abuseipdb_key=abuseipdb_key,
            geoip_db=geoip_db).run(all_findings)

    # Baseline/delta annotation
    baseline_delta = (0, 0)
    if args.baseline:
        baseline_delta = BaselineComparator(
            args.baseline, logger).annotate(all_findings)

    # IoC correlation (post-enrichment, so hashes are available).
    ioc_set = IoCSet.load(args.iocs)
    if not ioc_set.is_empty():
        matcher = IoCMatcher(ioc_set, logger)
        all_findings.extend(matcher.run(all_findings))

    # Normalize (dedup + collapse)
    pre_count = len(all_findings)
    all_findings = FindingNormalizer(all_findings).normalize()
    logger.info("Normalization: %d -> %d findings",
                pre_count, len(all_findings))

    # Severity threshold
    min_sev = _SEV_FROM_NAME[args.min_severity]
    if min_sev > SEV_INFO:
        before = len(all_findings)
        all_findings = [f for f in all_findings
                        if f.severity >= min_sev]
        logger.info("Severity filter >=%s: %d -> %d",
                    args.min_severity, before, len(all_findings))

    # Score
    score, band, contribs = compute_threat_score(all_findings)
    logger.info("Threat score: %d (%s)", score, band)

    # Cross-link each per-EID suspicious instance to the findings
    # that share its user / IP / process / timestamp. This is what
    # a forensic analyst needs: "event X at time Y — what else
    # happened around it?"
    correlate_event_instances(event_overview, all_findings)

    metadata = {
        "host":         platform.node(),
        "image":        str(args.memory) if args.memory else
                        ("live triage"),
        "dumps_found":  len(dump_records),
        "evtx_inputs":  ", ".join(p.name for p in evtx_list
                                  if p.exists()) or "(none)",
        "started":      _iso(started),
        "finished":     _iso(_now_utc()),
        "tool":         f"{TOOL_NAME} v{TOOL_VERSION}",
        "workdir":      str(args.workdir),
        "threat_score": f"{score}/100 ({band})",
        "system_profile": sys_profile,
        "live_snapshot":  live_snapshot,
        "network_state":  net_state,
        "domain_state":   domain_state,
        "darknet_state":  darknet_state,
        "lang":           args.lang,
        "baseline_new":   baseline_delta[0],
        "baseline_persisting": baseline_delta[1],
        "pcap_path":      str(pcap_path) if pcap_path else None,
    }
    # Build Super-Timeline across all time-bearing sources.
    timeline = build_super_timeline(
        all_findings, evt_events, bam_entries,
        prefetch_entries, dump_records)

    # Redaction (applied last so the JSON export is redacted too).
    if args.anonymize:
        logger.info("Redaction mode: anonymizing report.")
        apply_redaction(all_findings, metadata)

    rep = ReportGenerator(all_findings, metadata, args.output,
                          event_overview=event_overview,
                          timeline=timeline)
    out_path = rep.render()
    logger.info("Report written: %s", out_path)

    json_path = args.output.with_suffix(".json")
    json_path.write_text(json.dumps({
        "metadata": metadata,
        "findings": [f.as_dict() for f in all_findings],
        "event_overview": {str(k): v
                           for k, v in event_overview.items()},
        "timeline": timeline,
    }, indent=2, default=str), encoding="utf-8")
    logger.info("JSON written:   %s", json_path)

    # Chain-of-custody manifest
    manifest_path = write_custody_manifest(
        args.output, all_findings, metadata)
    logger.info("Custody manifest: %s", manifest_path)

    # PDF export (full report + optional 1-page exec summary)
    if args.pdf or args.exec_pdf:
        pdf_paths = export_pdf(
            args.output, all_findings, metadata, logger,
            full=args.pdf, exec_summary=args.exec_pdf)
        for p in pdf_paths:
            logger.info("PDF written: %s", p)
    return 0


# ---------------------------------------------------------------------------
# PDF export (headless Chromium / Edge).
# ---------------------------------------------------------------------------

def export_pdf(html_path: Path, findings: List[Finding],
                metadata: Dict[str, Any], logger: logging.Logger,
                full: bool = True,
                exec_summary: bool = False) -> List[Path]:
    """Produce PDF via Chromium/Edge `--print-to-pdf`. Returns list
    of written paths."""
    out: List[Path] = []
    exe = None
    # First check PATH
    for cand in ("msedge.exe", "chrome.exe", "brave.exe",
                  "google-chrome"):
        found = shutil.which(cand)
        if found:
            exe = found
            break
    # Then default Windows install locations
    if not exe:
        candidates = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application"
            r"\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application"
            r"\msedge.exe",
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application"
            r"\chrome.exe",
            r"C:\Program Files\BraveSoftware\Brave-Browser"
            r"\Application\brave.exe",
        ]
        for c in candidates:
            if _safe_exists(Path(c)):
                exe = c
                break
    if not exe:
        logger.warning("PDF export skipped — no Chromium/Edge found")
        return out
    logger.info("PDF export: using %s", exe)

    def _to_pdf(src_html: Path, dst_pdf: Path) -> bool:
        try:
            r = subprocess.run(
                [exe, "--headless=new", "--disable-gpu",
                 "--no-sandbox",
                 f"--print-to-pdf={dst_pdf}",
                 "--print-to-pdf-no-header",
                 src_html.as_uri()],
                capture_output=True, timeout=120)
            return r.returncode == 0 and dst_pdf.exists()
        except Exception as exc:
            logger.debug("PDF export failed: %s", exc)
            return False

    if full:
        pdf = html_path.with_suffix(".pdf")
        if _to_pdf(html_path, pdf):
            out.append(pdf)

    if exec_summary:
        exec_html = html_path.with_name(
            html_path.stem + "-exec.html")
        exec_pdf = html_path.with_name(
            html_path.stem + "-exec.pdf")
        write_exec_summary_html(exec_html, findings, metadata)
        if _to_pdf(exec_html, exec_pdf):
            out.append(exec_pdf)

    return out


def write_exec_summary_html(path: Path,
                             findings: List[Finding],
                             metadata: Dict[str, Any]) -> None:
    """Render a 1-page executive summary suitable for print-to-PDF."""
    malicious = [f for f in findings if f.severity >= SEV_HIGH]
    score_str = metadata.get("threat_score", "?")
    host = metadata.get("host", "?")
    sp = metadata.get("system_profile") or {}
    when = metadata.get("finished", "?")
    # Severity color band
    band = score_str.split("(")[-1].rstrip(")")
    band_color = {"CRITICAL": "#c0392b", "HIGH": "#e67e22",
                  "MEDIUM": "#f39c12", "LOW": "#16a085",
                  "CLEAN": "#6c7a89"}.get(band, "#6c7a89")

    top_lines = []
    for f in malicious[:8]:
        color = SEV_COLOR[f.severity]
        top_lines.append(
            f"<li><span class='pill' style='background:{color}'>"
            f"{SEV_LABEL[f.severity]}</span> "
            f"<b>{html.escape(f.title)}</b><br>"
            f"<span style='color:#555;font-size:11px;'>"
            f"{html.escape(f.conclusion)[:260]}</span></li>")
    if not top_lines:
        top_lines.append(
            "<li>No confirmed malicious findings.</li>")

    css = """
    body { font-family: 'Segoe UI', sans-serif; margin: 24px;
           color: #111; }
    h1 { margin: 0 0 6px 0; font-size: 22px; }
    .sub { color: #666; font-size: 12px; margin-bottom: 14px; }
    .score { display: inline-block; padding: 10px 22px;
             border-radius: 10px; color: #fff; font-size: 28px;
             font-weight: 700; margin: 10px 0; }
    table { width: 100%; border-collapse: collapse;
            font-size: 12px; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 5px 8px;
             text-align: left; }
    th { background: #eef1f5; }
    ul { list-style: none; padding: 0; }
    ul li { margin: 8px 0; padding: 8px 12px; border-left: 3px
            solid #888; background: #f7f8fa; border-radius: 4px; }
    .pill { display: inline-block; padding: 2px 8px;
            border-radius: 10px; font-size: 10px;
            color: #fff; font-weight: 700; }
    """
    doc = f"""<!doctype html><html><head><meta charset='utf-8'>
<title>{TOOL_NAME} — Executive Summary</title>
<style>{css}</style></head><body>
<h1>{TOOL_NAME} — Executive Summary</h1>
<div class='sub'>Host: <b>{html.escape(host)}</b> &nbsp;|&nbsp;
  OS: <b>{html.escape(sp.get('os_caption','?'))}
  (build {html.escape(str(sp.get('os_build','?')))})</b>
  &nbsp;|&nbsp; Finished: <b>{html.escape(when)}</b></div>
<div class='score' style='background:{band_color}'>{score_str}</div>
<h3>Top {len(malicious[:8])} Findings</h3>
<ul>{''.join(top_lines)}</ul>
<table>
  <thead><tr><th>Host</th><th>Domain</th><th>Internal IP</th>
    <th>External IP</th><th>Users (local)</th></tr></thead>
  <tbody><tr>
    <td>{html.escape(sp.get('ComputerName','?'))}</td>
    <td>{html.escape(sp.get('Domain','?'))}</td>
    <td>{html.escape(str(next(iter((sp.get('interfaces') or {}).values()), {}).get('ipv4') or ['?'])[:120])}</td>
    <td>{html.escape(sp.get('external_ip','?') or '?')}</td>
    <td>{len(sp.get('local_users') or []) if isinstance(sp.get('local_users'),list) else '?'}</td>
  </tr></tbody>
</table>
<p style='font-size:10px;color:#888;margin-top:14px;'>
  Generated by {TOOL_NAME} v{TOOL_VERSION} on
  {_iso(_now_utc())}.
</p>
</body></html>"""
    path.write_text(doc, encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
